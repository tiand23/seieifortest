public class Sample {
    public void run() {
        do {
                //ndz-del-s
//                // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0396.00:C   EXFMT  OS771D1
//                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
                //ndz-del-e
            dto.setOs771d1( true );
        } while (loopFlag);

        startDateCheck();
        if (Utils.rTrim(dto.getWstdt1()).compareTo("") > 0) {
            indicator.setIn80(true);
        }

        endDateCheck();
        if (dto.getWstdt2().trim().compareTo("") > 0) {
            indicator.setIn81(true);
        }
    }
}
