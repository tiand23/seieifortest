"""Java 文件读写：编码自动探测 + 换行符原样保留(Windows CRLF 安全)。

处理时把文件拆成"无行尾的行列表"，写回时用原换行符重组——
这样补丁应用 / diff 不会因为 CRLF<->LF 把整文件搞脏。
"""
import pathlib

_TRY_ENCODINGS = ["utf-8-sig", "utf-8", "cp932", "shift_jis", "euc-jp", "latin-1"]


def detect_encoding(raw: bytes, configured="auto") -> str:
    if configured and configured != "auto":
        return configured
    try:
        import chardet
        g = chardet.detect(raw)
        if g and g.get("encoding") and (g.get("confidence") or 0) > 0.7:
            return g["encoding"]
    except Exception:
        pass
    for enc in _TRY_ENCODINGS:
        try:
            raw.decode(enc)
            return enc
        except Exception:
            continue
    return "utf-8"


def detect_newline(raw: bytes) -> str:
    if b"\r\n" in raw:
        return "\r\n"
    if b"\r" in raw:
        return "\r"
    return "\n"


class JavaText:
    """一个 java 源文件的可编辑表示。lines = 不含行尾的字符串列表(1-based 行号)。"""

    def __init__(self, path, lines, newline, encoding):
        self.path = pathlib.Path(path)
        self.lines = lines
        self.newline = newline
        self.encoding = encoding

    @classmethod
    def load(cls, path, configured_encoding="auto"):
        p = pathlib.Path(path)
        raw = p.read_bytes()
        enc = detect_encoding(raw, configured_encoding)
        nl = detect_newline(raw)
        text = raw.decode(enc, errors="replace")
        lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        return cls(p, lines, nl, enc)

    def text(self) -> str:
        return self.newline.join(self.lines)

    def save(self, path=None, encoding=None):
        p = pathlib.Path(path) if path else self.path
        enc = encoding or self.encoding
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(self.text().encode(enc, errors="replace"))

    def region(self, line_no, before, after):
        """取命中行前后的局部上下文(1-based, 闭区间)。返回 (start_line, lines)。"""
        start = max(1, line_no - before)
        end = min(len(self.lines), line_no + after)
        return start, self.lines[start - 1:end]
