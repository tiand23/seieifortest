"""通用检测引擎：给任意规则 + 任意 java，找出所有命中位置。
引擎不认识具体规则，只按 rule.detect.method 跑三种通用机制。
"""
import re

_MARKER_WORDS = ("TODO", "FIXME")


def all_marker_lines(lines):
    """文件里所有 TODO/FIXME 注释行。用于统计'命中但无规则'。"""
    out = []
    for i, l in enumerate(lines):
        if any(w in l for w in _MARKER_WORDS):
            out.append((i + 1, l.strip()))
    return out


def detect_rule(rule, lines):
    """返回该规则在 lines 中的命中列表 [{rule_id, line, text}]。"""
    d = rule["detect"]
    method = d["method"]
    occ = []
    if method == "marker":
        regex = re.compile(d["pattern"])
        kinds = d.get("marker_kinds", list(_MARKER_WORDS))
        for i, l in enumerate(lines):
            if any(k in l for k in kinds) and regex.search(l):
                occ.append({"rule_id": rule["id"], "line": i + 1, "text": l.strip()})
    elif method == "pattern":
        regex = re.compile(d["pattern"])
        skip = d.get("skip_if")  # 幂等：已转换过的行跳过
        skip_re = re.compile(skip) if skip else None
        for i, l in enumerate(lines):
            if regex.search(l) and not (skip_re and skip_re.search(l)):
                occ.append({"rule_id": rule["id"], "line": i + 1, "text": l.strip()})
    elif method == "llm":
        # 兜底机制：需要 LLM 在文件里定位，成本高，留给 complete/mine 阶段按需调用。
        pass
    return occ


def detect_all(rules, lines):
    """对所有规则做检测，并算出未被任何规则认领的标记行。"""
    matched = []
    claimed_lines = set()
    for rule in rules:
        occ = detect_rule(rule, lines)
        for o in occ:
            claimed_lines.add(o["line"])
        matched.extend(occ)

    unmatched = []
    for ln, text in all_marker_lines(lines):
        if ln not in claimed_lines:
            unmatched.append({"line": ln, "text": text, "key": _marker_key(text)})
    return {"matched": matched, "unmatched": unmatched}


def _marker_key(text):
    """给未命中标记归类的 key：优先 命令[XXX]，否则取 FIXME/TODO 文案前缀。"""
    m = re.search(r"命令\[[A-Z0-9_-]+\]", text)
    if m:
        return m.group(0)
    m = re.search(r"(FIXME|TODO)\s*(\S+)", text)
    if m:
        return f"{m.group(1)} {m.group(2)}"
    return "(其它)"
