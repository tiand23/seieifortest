"""确定性变换 + 补丁应用。
变换都是"具名操作"，由规则的 transform.type 选择 —— 通用，规则只是数据。
应用顺序：同一文件内按行号从大到小应用，保证行号不串位。
"""
import re

_TODO_HINT_RE = re.compile(r"/\*\s*TODO:Duplicate field \[(?P<expr>[^\]]+)\]\s*\*/")
_WS_RE = re.compile(r"\s+")
_COMPARE_RE = re.compile(
    r"(?P<receiver>"
    r"(?:Utils\.rTrim\((?:[^()]|\([^()]*\))*\)|"
    r"[A-Za-z_][A-Za-z0-9_]*(?:\([^)]*\))?(?:\.[A-Za-z_][A-Za-z0-9_]*(?:\([^)]*\))?)*)"
    r")\.compareTo\((?P<arg>\"(?:[^\"\\]|\\.)*\")\)\s*"
    r"(?P<op>>=|<=|==|!=|>|<)\s*(?P<rhs>-?\d+)"
)


def _indent(line):
    return line[:len(line) - len(line.lstrip())]


def _normalize_code_line(text):
    return _WS_RE.sub(" ", text).strip()


def _is_comment(line):
    return line.lstrip().startswith("//")


def _is_field_decl(line):
    return bool(re.match(r"^\s*(private|protected|public)\b.*;\s*$", line))


def _is_attached_doc_or_annotation(line):
    stripped = line.strip()
    return stripped.startswith("/**") or stripped.startswith("*") or stripped.startswith("*/") or stripped.startswith("@")


def _strip_one_comment_prefix(line):
    return re.sub(r"^(\s*)//", r"\1", line, count=1)


def _find_block_end(lines, start):
    head = lines[start].strip()
    if head == "//ndz-del-s":
        tail = "//ndz-del-e"
    elif head == "//ndz-add-s":
        tail = "//ndz-add-e"
    else:
        return None
    for i in range(start + 1, len(lines)):
        if lines[i].strip() == tail:
            return i
    return None


def _locate_exact_block(lines, block_lines, occ_line=None, marker_offset=0, start_lo=0, start_hi=None):
    if not block_lines:
        return None
    want = [_normalize_code_line(x) for x in block_lines]
    max_start = len(lines) - len(block_lines)
    if max_start < 0:
        return None
    if start_hi is None:
        start_hi = max_start
    else:
        start_hi = min(start_hi, max_start)
    occ_idx = occ_line - 1 if occ_line else None
    for s in range(max(0, start_lo), start_hi + 1):
        e = s + len(block_lines)
        got = [_normalize_code_line(x) for x in lines[s:e]]
        if got != want:
            continue
        if occ_idx is not None:
            anchor = s + marker_offset
            if not (0 <= anchor < e and anchor == occ_idx):
                continue
        return s, e
    return None


def _parse_annotated_segments(after_lines):
    segments = []
    i = 0
    while i < len(after_lines):
        stripped = after_lines[i].strip()
        if stripped in ("//ndz-del-s", "//ndz-add-s"):
            end = _find_block_end(after_lines, i)
            if end is None:
                return None
            block_type = "del" if stripped == "//ndz-del-s" else "add"
            seg = {"type": block_type, "lines": after_lines[i:end + 1]}
            if block_type == "del":
                seg["original_lines"] = [_strip_one_comment_prefix(x) for x in after_lines[i + 1:end]]
            segments.append(seg)
            i = end + 1
            continue
        j = i + 1
        while j < len(after_lines) and after_lines[j].strip() not in (
                "//ndz-del-s", "//ndz-del-e", "//ndz-add-s", "//ndz-add-e"):
            j += 1
        segments.append({"type": "plain", "lines": after_lines[i:j]})
        i = j
    return segments


def _find_occurrence_offset(block_lines, occ_text):
    target = _normalize_code_line(occ_text)
    for i, line in enumerate(block_lines):
        if _normalize_code_line(line.strip()) == target:
            return i
    return None


def apply_example_rule(java, occ, rule):
    """按 skill 里的人工例子精确回放 patch。适合 4.7.6 这类重复人工模式。"""
    examples = rule.get("examples") or []
    for idx, ex in enumerate(examples, start=1):
        after_lines = ex.get("after") or []
        segments = _parse_annotated_segments(after_lines)
        if not segments:
            continue
        del_segments = [seg for seg in segments if seg["type"] == "del" and seg.get("original_lines")]
        if not del_segments:
            continue

        first_block = del_segments[0]["original_lines"]
        marker_offset = _find_occurrence_offset(first_block, occ["text"])
        if marker_offset is None:
            continue

        first_loc = _locate_exact_block(
            java.lines,
            first_block,
            occ_line=occ["line"],
            marker_offset=marker_offset,
            start_lo=max(0, occ["line"] - 1 - len(first_block)),
            start_hi=occ["line"] - 1,
        )
        if not first_loc:
            first_loc = _locate_exact_block(java.lines, first_block, occ_line=occ["line"], marker_offset=marker_offset)
        if not first_loc:
            continue

        last_end = first_loc[1]
        ok = True
        for seg in del_segments[1:]:
            loc = _locate_exact_block(
                java.lines,
                seg["original_lines"],
                start_lo=last_end,
                start_hi=min(len(java.lines), last_end + 200),
            )
            if not loc:
                ok = False
                break
            last_end = loc[1]
        if not ok:
            continue

        java.lines[first_loc[0]:last_end] = after_lines
        return {
            "type": "example_patch",
            "line": occ["line"],
            "applied": True,
            "example_index": idx,
            "block_lines": last_end - first_loc[0],
        }

    return {"type": "example_patch", "line": occ["line"], "applied": False}


def apply_comment_out_block(lines, line_no, transform):
    """注释掉命中行及其后续连续的 //TODO//FIXME 注释行，用 ndz-del 包裹。
    对应设计书 4.7.6 EXFMT 的修正方法。"""
    # TODO 行から、連続する // コメント行を取り込み、FIXME 行を含めて終了する。
    # 途中に RENAME 等の // コメント継続行があっても一緒に取り込む(設計書 4.7.7.4)。
    start = line_no - 1
    end = start
    j = start + 1
    while j < len(lines):
        s = lines[j].lstrip()
        if not s.startswith("//"):
            break
        end = j
        if "FIXME" in lines[j]:   # FIXME がブロックの終端マーカー
            break
        j += 1
    # 設計書および既存ソースの慣例に合わせ、ndz-del-s/e は桁0(インデント無し)、
    # コメント化行は行頭に // を前置する。
    block = lines[start:end + 1]
    new = ["//ndz-del-s"]
    new += ["//" + b for b in block]
    new += ["//ndz-del-e"]
    lines[start:end + 1] = new
    return {"type": "comment_out_block", "line": line_no, "block_lines": len(block)}


def apply_comment_out_attached_block(lines, line_no, transform):
    """注释 TODO/FIXME 块，并可带上紧邻的字段声明/注释。"""
    start = line_no - 1
    if start - 1 >= 0 and _is_field_decl(lines[start - 1]):
        start -= 1
        if start - 1 >= 0 and _is_attached_doc_or_annotation(lines[start - 1]):
            start -= 1

    end = line_no - 1
    j = line_no
    while j < len(lines):
        if not _is_comment(lines[j]):
            break
        end = j
        if "FIXME" in lines[j]:
            break
        j += 1

    block = lines[start:end + 1]
    new = ["//ndz-del-s"] + ["//" + b for b in block] + ["//ndz-del-e"]
    lines[start:end + 1] = new
    return {"type": "comment_out_attached_block", "line": line_no, "block_lines": len(block), "applied": True}


def apply_comment_out_comment_cluster(lines, line_no, transform):
    """命中行所在的连续注释簇整体注释化。用于 RECNO 等 FIXME 命中规则。"""
    start = line_no - 1
    while start - 1 >= 0 and _is_comment(lines[start - 1]):
        start -= 1
    end = line_no - 1
    while end + 1 < len(lines) and _is_comment(lines[end + 1]):
        end += 1
    block = lines[start:end + 1]
    new = ["//ndz-del-s"] + ["//" + b for b in block] + ["//ndz-del-e"]
    lines[start:end + 1] = new
    return {"type": "comment_out_comment_cluster", "line": line_no, "block_lines": len(block), "applied": True}


def apply_regex_replace(lines, line_no, transform):
    """在命中行上做正则替换。对应 5.9 COMP-Trim 这类'套个 rTrim'的模式。"""
    find = transform["find"]
    repl = transform["replace"]
    i = line_no - 1
    new = re.sub(find, repl, lines[i])
    changed = new != lines[i]
    lines[i] = new
    return {"type": "regex_replace", "line": line_no, "changed": changed}


def apply_comp_trim_with_hint(lines, line_no, transform):
    """5.9 中带 Duplicate-field hint 的 compareTo 比较，可确定性改写。"""
    i = line_no - 1
    original = lines[i]
    hint = _TODO_HINT_RE.search(original)
    compare = _COMPARE_RE.search(original)
    if not hint or not compare:
        return {"type": "comp_trim_with_hint", "line": line_no, "applied": False}

    hint_expr = hint.group("expr").strip()
    receiver = compare.group("receiver")
    active = _TODO_HINT_RE.sub("", original, count=1).replace(receiver, f"Utils.rTrim({hint_expr})", 1)
    lines[i:i + 1] = [
        "//ndz-del-s",
        "//" + original,
        "//ndz-del-e",
        "//ndz-add-s",
        active,
        "//ndz-add-e",
    ]
    return {
        "type": "comp_trim_with_hint",
        "line": line_no,
        "applied": True,
        "hint_expr": hint_expr,
    }


def apply_template(lines, line_no, transform):
    """mine 合成的模板替换(占位符)。Phase1 仅占位，mine 落地后启用。"""
    return {"type": "template", "line": line_no, "applied": False, "note": "template 尚未实现"}


_HANDLERS = {
    "comment_out_block": apply_comment_out_block,
    "comment_out_attached_block": apply_comment_out_attached_block,
    "comment_out_comment_cluster": apply_comment_out_comment_cluster,
    "comp_trim_with_hint": apply_comp_trim_with_hint,
    "regex_replace": apply_regex_replace,
    "template": apply_template,
}

_BUILTIN_RULE_HANDLERS = {
    "4.7.31": apply_comment_out_comment_cluster,
    "4.7.4": apply_comment_out_attached_block,
    "5.9": apply_comp_trim_with_hint,
}


def apply_deterministic(java, occurrences_with_rules):
    """occurrences_with_rules: [(occ, rule)]，只处理 transform 存在的。
    返回变更记录列表。会就地修改 java.lines。"""
    # 按行号倒序，避免多行变换串位
    items = sorted(occurrences_with_rules, key=lambda x: x[0]["line"], reverse=True)
    changes = []
    for occ, rule in items:
        t = rule.get("transform")
        if not t:
            continue
        handler = _HANDLERS.get(t["type"])
        if not handler:
            changes.append({"line": occ["line"], "error": f"未知 transform: {t['type']}"})
            continue
        rec = handler(java.lines, occ["line"], t)
        rec["rule_id"] = rule["id"]
        changes.append(rec)
    return changes


def apply_builtin_rule(java, occ, rule):
    """部分规则即使 skill 仍是 llm，也先尝试更安全的内建自动化。"""
    handler = _BUILTIN_RULE_HANDLERS.get(str(rule.get("id")))
    if not handler:
        return None
    rec = handler(java.lines, occ["line"], rule.get("transform") or {})
    rec["rule_id"] = rule["id"]
    return rec
