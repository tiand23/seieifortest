"""LLM 客户端：双 provider。
- openai : 本地 LM Studio / 任何 OpenAI 兼容 /v1/chat/completions
- gemini : 客户环境，经 Vertex AI(project) 或 API Key，使用 google-genai SDK

切换只改 config.yaml 的 llm.provider，引擎代码不变。
"""
import os
import json


class LLMClient:
    def __init__(self, cfg):
        self.cfg = cfg
        self.provider = cfg.get("llm", "provider", default="openai")
        self.temperature = cfg.get("llm", "temperature", default=0.1)
        self.max_tokens = cfg.get("llm", "max_output_tokens", default=4096)

    # ---- 统一入口 ----
    def chat(self, system_prompt, user_prompt, json_mode=True):
        if self.provider == "gemini":
            return self._chat_gemini(system_prompt, user_prompt, json_mode)
        return self._chat_openai(system_prompt, user_prompt, json_mode)

    # ---- 本地 / OpenAI 兼容 ----
    def _chat_openai(self, system_prompt, user_prompt, json_mode):
        import requests
        c = self.cfg.get("llm", "openai", default={})
        payload = {
            "model": c.get("model", "qwen-coder-next"),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": self.temperature,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        headers = {"Content-Type": "application/json",
                   "Authorization": f"Bearer {c.get('api_key', 'lm-studio')}"}
        r = requests.post(c.get("api_url"), headers=headers,
                          data=json.dumps(payload), timeout=300)
        r.raise_for_status()
        content = r.json()["choices"][0]["message"]["content"]
        return json.loads(content) if json_mode else content

    # ---- 客户环境 Gemini (Vertex / API Key) ----
    def _chat_gemini(self, system_prompt, user_prompt, json_mode):
        from google import genai
        from google.genai import types
        g = self.cfg.get("llm", "gemini", default={})
        if g.get("mode") == "vertex":
            client = genai.Client(vertexai=True, project=g.get("project"),
                                  location=g.get("location", "us-central1"))
        else:
            client = genai.Client(api_key=os.getenv(g.get("api_key_env", "GEMINI_API_KEY")))
        model = os.getenv(g.get("model_env", "GEMINI_MODEL")) or g.get("model_default", "gemini-2.5-pro")
        config = types.GenerateContentConfig(
            system_instruction=system_prompt,
            temperature=self.temperature,
            max_output_tokens=self.max_tokens,
            response_mime_type="application/json" if json_mode else "text/plain",
        )
        resp = client.models.generate_content(model=model, contents=user_prompt, config=config)
        text = resp.text
        return json.loads(text) if json_mode else text
