"""LLM 客户端：双 provider + 429 指数退避。
- openai : 本地 LM Studio / 任何 OpenAI 兼容 /v1/chat/completions
- gemini : 客户环境，经 Vertex AI(project) 或 API Key，使用 google-genai SDK

切换只改 config.yaml 的 llm.provider，引擎代码不变。
速率限制(429/RESOURCE_EXHAUSTED)自动指数退避重试。
"""
import os
import re
import json
import time


_RATE_HINTS = ("429", "rate limit", "ratelimit", "resource_exhausted",
               "resourceexhausted", "too many requests", "quota")


def loads_loose(text):
    """宽松 JSON 解析: 去 ```围栏 / 前后噪声 / 截取最外层 {} 或 []。"""
    if isinstance(text, (dict, list)):
        return text
    try:
        return json.loads(text)
    except Exception:
        pass
    t = text.strip()
    t = re.sub(r"^```[a-zA-Z]*\s*", "", t)
    t = re.sub(r"\s*```$", "", t)
    try:
        return json.loads(t)
    except Exception:
        pass
    for op, cl in (("{", "}"), ("[", "]")):
        i, j = t.find(op), t.rfind(cl)
        if 0 <= i < j:
            try:
                return json.loads(t[i:j + 1])
            except Exception:
                continue
    raise ValueError("JSON 解析失败(返回非合法JSON)")


def _is_rate_limit(e):
    s = str(e).lower()
    return any(h in s for h in _RATE_HINTS)


class LLMClient:
    def __init__(self, cfg):
        self.cfg = cfg
        self.provider = cfg.get("llm", "provider", default="openai")
        self.temperature = cfg.get("llm", "temperature", default=0.1)
        self.max_tokens = cfg.get("llm", "max_output_tokens", default=4096)
        self.timeout = cfg.get("llm", "timeout_sec", default=120)
        self.rl_retries = cfg.get("llm", "rate_limit_retries", default=5)
        self.backoff_base = cfg.get("llm", "backoff_base_sec", default=2)
        self._gemini = None  # 缓存 client

    # ---- 统一入口：带 429 指数退避 ----
    def chat(self, system_prompt, user_prompt, json_mode=True):
        last = None
        for attempt in range(self.rl_retries + 1):
            try:
                if self.provider == "gemini":
                    return self._chat_gemini(system_prompt, user_prompt, json_mode)
                return self._chat_openai(system_prompt, user_prompt, json_mode)
            except Exception as e:
                last = e
                if _is_rate_limit(e) and attempt < self.rl_retries:
                    delay = self.backoff_base * (2 ** attempt)  # 2,4,8,16,32...
                    print(f"  [llm] 429/限流, {delay}s 后重试 (第{attempt + 1}次)")
                    time.sleep(delay)
                    continue
                raise
        raise last

    # ---- 本地 / OpenAI 兼容 ----
    def _chat_openai(self, system_prompt, user_prompt, json_mode):
        import requests
        c = self.cfg.get("llm", "openai", default={})
        payload = {
            "model": c.get("model", "qwen-coder-next"),
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": self.temperature,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        headers = {"Content-Type": "application/json",
                   "Authorization": f"Bearer {c.get('api_key', 'lm-studio')}"}
        r = requests.post(c.get("api_url"), headers=headers,
                          data=json.dumps(payload), timeout=self.timeout)
        r.raise_for_status()
        content = r.json()["choices"][0]["message"]["content"]
        return loads_loose(content) if json_mode else content

    # ---- 客户环境 Gemini (Vertex / API Key) ----
    def _gemini_client(self):
        if self._gemini is None:
            from google import genai
            g = self.cfg.get("llm", "gemini", default={})
            if g.get("mode") == "vertex":
                self._gemini = genai.Client(vertexai=True, project=g.get("project"),
                                            location=g.get("location", "us-central1"))
            else:
                self._gemini = genai.Client(api_key=os.getenv(g.get("api_key_env", "GEMINI_API_KEY")))
        return self._gemini

    def _chat_gemini(self, system_prompt, user_prompt, json_mode):
        from google.genai import types
        g = self.cfg.get("llm", "gemini", default={})
        client = self._gemini_client()
        model = os.getenv(g.get("model_env", "GEMINI_MODEL")) or g.get("model_default", "gemini-2.5-pro")
        config = types.GenerateContentConfig(
            system_instruction=system_prompt,
            temperature=self.temperature,
            max_output_tokens=self.max_tokens,
            response_mime_type="application/json" if json_mode else "text/plain",
            http_options=types.HttpOptions(timeout=self.timeout * 1000),  # ms
        )
        resp = client.models.generate_content(model=model, contents=user_prompt, config=config)
        text = resp.text
        return loads_loose(text) if json_mode else text
