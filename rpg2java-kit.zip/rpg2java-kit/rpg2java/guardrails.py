"""LLM 补丁的客观校验。

目标不是替代 validate，而是在 complete 阶段尽早拦住明显错误：
- 5.9: 比较对象/运算符/比较值被改错
- 4.7.31 / 4.7.4: 注释块越界，吞掉无关声明
- 4.7.6: EXFMT 相关补丁改动范围失控
"""
from dataclasses import dataclass, field
import re


_TODO_HINT_RE = re.compile(r"/\*\s*TODO:Duplicate field \[(?P<expr>[^\]]+)\]\s*\*/")
_COMPARE_RE = re.compile(
    r"(?P<receiver>"
    r"(?:Utils\.rTrim\((?:[^()]|\([^()]*\))*\)|"
    r"[A-Za-z_][A-Za-z0-9_]*(?:\([^)]*\))?(?:\.[A-Za-z_][A-Za-z0-9_]*(?:\([^)]*\))?)*)"
    r")\.compareTo\((?P<arg>\"(?:[^\"\\]|\\.)*\")\)\s*"
    r"(?P<op>>=|<=|==|!=|>|<)\s*(?P<rhs>-?\d+)"
)
_NDZ_MARKER_RE = re.compile(r"^\s*//ndz-(?:del|add)-[se]\s*$")


@dataclass
class ValidationResult:
    ok: bool
    errors: list[str] = field(default_factory=list)


def validate_response(skill, occ, context_lines, hit_line_in_context, response):
    """校验 LLM 返回的补丁是否满足基本结构与规则级约束。"""
    errors = _basic_checks(context_lines, hit_line_in_context, response)
    if errors:
        return ValidationResult(False, errors)

    rule_id = str(skill.get("variant_of") or skill.get("id"))
    validator = _RULE_VALIDATORS.get(rule_id)
    if not validator:
        return ValidationResult(True, [])

    more = validator(occ, context_lines, hit_line_in_context, response)
    return ValidationResult(not more, more)


def validate_del_add(skill, occ, context_lines, hit_line, response):
    """del_add 契约校验: LLM 只返回 {del_start, del_end, add_code}, 不逐字echo原文。
    所以这里只校验"范围合理 + add_code 合法", 不要求逐字一致(逐字由 python 生成)。"""
    if not isinstance(response, dict):
        return ValidationResult(False, ["response must be a JSON object."])
    ds, de, add = response.get("del_start"), response.get("del_end"), response.get("add_code")
    errors = []
    if not isinstance(ds, int) or not isinstance(de, int):
        errors.append("del_start/del_end must be integers.")
    if not isinstance(add, list) or any(not isinstance(x, str) for x in add):
        errors.append("add_code must be an array of strings.")
    if errors:
        return ValidationResult(False, errors)

    n = len(context_lines)
    if ds < 1 or de < 1 or ds > n or de > n:
        errors.append("del range must stay inside context_code.")
    if ds > de:
        errors.append("del_start must be <= del_end.")
    if not (ds <= hit_line <= de):
        errors.append("del range must include hit_line_in_context.")
    if ds < max(1, hit_line - 4):
        errors.append("Do not start the deletion too far above the hit line.")
    if de > min(n, hit_line + 12):
        errors.append("Do not extend the deletion too far below the hit line.")
    if de - ds + 1 > 16:
        errors.append("Deletion window too wide (>16 lines).")
    return ValidationResult(not errors, errors)


def _basic_checks(context_lines, hit_line_in_context, response):
    if not isinstance(response, dict):
        return ["response must be a JSON object."]

    start = response.get("start_line")
    end = response.get("end_line")
    repl = response.get("replacement")
    errors = []

    if not isinstance(start, int) or not isinstance(end, int):
        errors.append("start_line/end_line must be integers.")
    if not isinstance(repl, list) or any(not isinstance(x, str) for x in repl):
        errors.append("replacement must be an array of strings.")
    if errors:
        return errors

    if start < 1 or end < 1 or start > len(context_lines) or end > len(context_lines):
        errors.append("start_line/end_line must stay inside context_code.")
    if start > end:
        errors.append("start_line must be <= end_line.")
    if not (start <= hit_line_in_context <= end):
        errors.append("The replacement range must include hit_line_in_context.")
    return errors


def _validate_5_9(_occ, context_lines, hit_line, response):
    original = context_lines[hit_line - 1]
    parsed_original = _parse_compare_line(original)
    if not parsed_original:
        return ["Could not parse the original compareTo expression on the hit line."]

    active_lines = [line for line in response["replacement"] if _is_active_code(line)]
    compare_lines = [line for line in active_lines if ".compareTo(" in line]
    if len(compare_lines) != 1:
        return ["Return exactly one active compareTo line for rule 5.9."]

    parsed_new = _parse_compare_line(compare_lines[0])
    if not parsed_new:
        return ["The active compareTo line is malformed."]

    errors = []
    if parsed_new["arg"] != parsed_original["arg"]:
        errors.append(f'Keep the compareTo literal unchanged: expected {parsed_original["arg"]}.')
    if parsed_new["op"] != parsed_original["op"] or parsed_new["rhs"] != parsed_original["rhs"]:
        errors.append(
            f'Keep the comparison operator/value unchanged: expected {parsed_original["op"]} {parsed_original["rhs"]}.'
        )

    hint = _extract_todo_hint(original)
    expected_expr = hint or parsed_original["receiver"]
    receiver = parsed_new["receiver"]
    if hint:
        wanted = f"Utils.rTrim({expected_expr})"
        if _compact(receiver) != _compact(wanted):
            errors.append(f"Use the Duplicate-field hint as the compare target: expected {wanted}.")
        if "TODO:Duplicate field" in compare_lines[0]:
            errors.append("Remove the TODO:Duplicate field comment from the active line.")
    else:
        allowed = {_compact(parsed_original["receiver"]), _compact(f"Utils.rTrim({parsed_original['receiver']})")}
        if _compact(receiver) not in allowed:
            errors.append("Do not change the compare target to a different expression.")
    return errors


def _validate_4_7_31(_occ, context_lines, hit_line, response):
    start = _scan_comment_start(context_lines, hit_line)
    end = _scan_comment_end(context_lines, hit_line)
    if response["start_line"] != start or response["end_line"] != end:
        return [
            "Wrap exactly the contiguous RECNO comment block around the hit line; do not include unrelated declarations."
        ]
    return _expect_exact_del_block(context_lines[start - 1:end], response["replacement"])


def _validate_4_7_4(_occ, context_lines, hit_line, response):
    end = _scan_fixme_end(context_lines, hit_line)
    allowed_starts = _allowed_dftactgrp_starts(context_lines, hit_line)
    if response["end_line"] != end:
        return ["Stop the DFTACTGRP patch at the FIXME line; do not consume following fields/services."]
    if response["start_line"] not in allowed_starts:
        return ["Only include the TODO/FIXME lines and, at most, the immediately attached field declaration/doc block."]
    return _expect_exact_del_block(
        context_lines[response["start_line"] - 1:response["end_line"]],
        response["replacement"],
    )


def _validate_4_7_6(_occ, context_lines, hit_line, response):
    start = response["start_line"]
    end = response["end_line"]
    removed = end - start + 1
    errors = []
    if start < max(1, hit_line - 4):
        errors.append("Do not start the EXFMT patch too far above the hit line.")
    if end > min(len(context_lines), hit_line + 12):
        errors.append("Do not extend the EXFMT patch too far below the hit line.")
    if removed > 16:
        errors.append("Keep the EXFMT replacement window tight; this patch is too wide.")
    if errors:
        return errors

    del_errors = _expect_del_block_prefix(
        context_lines[start - 1:end],
        response["replacement"],
    )
    if del_errors:
        return del_errors
    return _ensure_active_lines_inside_add_blocks(response["replacement"])


def _parse_compare_line(line):
    match = _COMPARE_RE.search(line)
    if not match:
        return None
    return {
        "receiver": match.group("receiver").strip(),
        "arg": match.group("arg"),
        "op": match.group("op"),
        "rhs": match.group("rhs"),
    }


def _extract_todo_hint(line):
    match = _TODO_HINT_RE.search(line)
    return match.group("expr").strip() if match else None


def _expect_exact_del_block(original_block, replacement):
    expected = ["//ndz-del-s"] + ["//" + line for line in original_block] + ["//ndz-del-e"]
    if replacement != expected:
        return ["Return an exact //ndz-del block for the chosen original lines; do not add unrelated lines."]
    return []


def _expect_del_block_prefix(original_block, replacement):
    """允许 del 块后面再接 add 块，但 del 块本身必须精确覆盖原始片段。"""
    expected_prefix = ["//ndz-del-s"] + ["//" + line for line in original_block] + ["//ndz-del-e"]
    if replacement[:len(expected_prefix)] != expected_prefix:
        return ["The EXFMT patch must start with an exact //ndz-del block over the selected original lines."]
    return []


def _ensure_active_lines_inside_add_blocks(replacement):
    errors = []
    in_add = False
    for line in replacement:
        stripped = line.strip()
        if stripped == "//ndz-add-s":
            if in_add:
                errors.append("Nested //ndz-add-s blocks are not allowed.")
            in_add = True
            continue
        if stripped == "//ndz-add-e":
            if not in_add:
                errors.append("Found //ndz-add-e without a matching //ndz-add-s.")
            in_add = False
            continue
        if _is_ndz_marker(line) or _is_comment_line(line):
            continue
        if not in_add:
            errors.append("Any active code added by EXFMT must be wrapped inside //ndz-add-s/e.")
            break
    if in_add:
        errors.append("Missing closing //ndz-add-e.")
    return errors


def _scan_comment_start(lines, line_no):
    start = line_no
    while start > 1 and _is_comment_line(lines[start - 2]):
        start -= 1
    return start


def _scan_comment_end(lines, line_no):
    end = line_no
    while end < len(lines) and _is_comment_line(lines[end]):
        end += 1
    return end


def _scan_fixme_end(lines, line_no):
    end = line_no
    while end < len(lines):
        if "FIXME" in lines[end - 1]:
            return end
        if not _is_comment_line(lines[end - 1]):
            return end - 1
        end += 1
    return len(lines)


def _allowed_dftactgrp_starts(lines, hit_line):
    starts = {hit_line}
    prev = hit_line - 1
    if prev >= 1 and _is_field_decl(lines[prev - 1]):
        starts.add(prev)
        prev2 = prev - 1
        if prev2 >= 1 and _is_attached_doc_or_annotation(lines[prev2 - 1]):
            starts.add(prev2)
    return starts


def _is_field_decl(line):
    return bool(re.match(r"^\s*(private|protected|public)\b.*;\s*$", line))


def _is_attached_doc_or_annotation(line):
    stripped = line.strip()
    return stripped.startswith("/**") or stripped.startswith("*") or stripped.startswith("*/") or stripped.startswith("@")


def _is_ndz_marker(line):
    return bool(_NDZ_MARKER_RE.match(line))


def _is_comment_line(line):
    return line.lstrip().startswith("//")


def _is_active_code(line):
    stripped = line.strip()
    return bool(stripped) and not stripped.startswith("//")


def _compact(text):
    return re.sub(r"\s+", "", text)


_RULE_VALIDATORS = {
    "4.7.31": _validate_4_7_31,
    "4.7.4": _validate_4_7_4,
    "4.7.6": _validate_4_7_6,
    "5.9": _validate_5_9,
}
