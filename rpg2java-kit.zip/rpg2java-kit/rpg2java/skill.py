"""Skill = 一条规则的可执行形态。

- 来源: mine 从 (规则 + 半成品 + 人工版) 推导，写到 skills/<id>.md (优先)。
        没有 skill 时 complete 回退用 rules/*.yaml。
- 结构: id, title, classify(deterministic|llm), detect, transform(确定性) / prompt(LLM), examples
- skills/<id>.md 格式: YAML frontmatter(元数据) + 正文(LLM 的 prompt)

三路径(config.paths): half_dir 半成品 / human_dir 人工版 / rpg_dir RPG源码
"""
import pathlib
import re
import yaml


# ---------------- 路径解析 ----------------
def _under(path, parent):
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except (ValueError, OSError):
        return False


def iter_half_java(cfg):
    """遍历半成品 java；跳过 human_dir / rpg_dir 下的文件。"""
    half = cfg.path("half_dir")
    human = cfg.path("human_dir")
    rpg = cfg.path("rpg_dir")
    java_list = cfg.get("java_list", default=[]) or []
    if java_list:
        for rel in java_list:
            yield half / rel
        return
    for p in sorted(half.rglob("*.java")):
        if _under(p, human) or (rpg and rpg.exists() and _under(p, rpg)):
            continue
        yield p


def human_path(cfg, java_path):
    return cfg.path("human_dir") / pathlib.Path(java_path).name


def rpg_path(cfg, java_path):
    """java 文件名 → RPG 文件 (默认: 去掉 LogicImpl 后缀 + 大写 + .RPG)。"""
    rpg_dir = cfg.path("rpg_dir")
    if not rpg_dir or not rpg_dir.exists():
        return None
    m = cfg.get("rpg_mapping", default={}) or {}
    stem = pathlib.Path(java_path).stem
    suf = m.get("strip_suffix", "LogicImpl")
    if suf and stem.endswith(suf):
        stem = stem[:-len(suf)]
    name = stem.upper() if m.get("uppercase", True) else stem
    cand = rpg_dir / (name + m.get("extension", ".RPG"))
    return cand if cand.exists() else None


_TOKEN = re.compile(r"[A-Z][A-Z0-9]{3,}")


def rpg_snippet(cfg, java_path, hit_text, around=15):
    """尽力而为: 用命中行里的大写算子名在 RPG 里定位, 返回附近片段。"""
    from .io_util import JavaText
    rp = rpg_path(cfg, java_path)
    if not rp:
        return ""
    rpg = JavaText.load(rp, cfg.encoding)
    tail = hit_text.split("original-code", 1)[-1]
    tokens = [t for t in _TOKEN.findall(tail) if t not in ("TODO", "FIXME", "RPG")]
    for tok in tokens:
        for i, l in enumerate(rpg.lines):
            if tok in l:
                s = max(0, i - 2)
                e = min(len(rpg.lines), i + around)
                return f"(RPG {rp.name} 付近, トークン[{tok}])\n" + "\n".join(rpg.lines[s:e])
    return ""


# ---------------- skill 文件读写 ----------------
def _split_frontmatter(text):
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            return parts[1], parts[2]
    return "", text


def load_skill_file(p):
    p = pathlib.Path(p)
    fm, body = _split_frontmatter(p.read_text(encoding="utf-8"))
    data = yaml.safe_load(fm) or {}
    data["prompt"] = body.strip()
    data["_file"] = p.name
    return data


def load_skills(skills_dir):
    skills_dir = pathlib.Path(skills_dir)
    if not skills_dir.exists():
        return []
    return [load_skill_file(p) for p in sorted(skills_dir.glob("*.md"))]


def write_skill(skills_dir, skill):
    skills_dir = pathlib.Path(skills_dir)
    skills_dir.mkdir(parents=True, exist_ok=True)
    body = skill.get("prompt", "") or ""
    meta = {k: v for k, v in skill.items() if k not in ("prompt",) and not k.startswith("_")}
    fm = yaml.safe_dump(meta, allow_unicode=True, sort_keys=False)
    fid = str(skill["id"]).replace(".", "_")
    p = skills_dir / f"{fid}.md"
    p.write_text(f"---\n{fm}---\n\n{body}\n", encoding="utf-8")
    return p
