"""规则目录加载。每条规则是 rules/*.yaml 里的一段数据。

规则 schema:
  id, title, description
  detect:
    method: marker | pattern | llm
    pattern: <正则>            # marker: 在 TODO/FIXME 注释行上匹配; pattern: 在所有行上匹配
    marker_kinds: [TODO, FIXME]   # 仅 method=marker
    desc_for_llm: <自然语言>      # 仅 method=llm
  classify: deterministic | llm | hybrid
  transform:                    # classify 含 deterministic 时
    type: comment_out_block | regex_replace | template
    ...
  guidance: <给 LLM 的指导>       # classify 含 llm 时
  examples: [{before, after}]    # few-shot / 回归用例
"""
import pathlib
import yaml


def load_rules(rules_dir) -> list:
    rules_dir = pathlib.Path(rules_dir)
    rules = []
    for p in sorted(rules_dir.glob("*.yaml")) + sorted(rules_dir.glob("*.yml")):
        with open(p, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if not data:
            continue
        data["_file"] = p.name
        _validate(data, p)
        rules.append(data)
    return rules


def _validate(rule, p):
    for k in ("id", "detect", "classify"):
        if k not in rule:
            raise ValueError(f"规则 {p.name} 缺少字段: {k}")
    method = rule["detect"].get("method")
    if method not in ("marker", "pattern", "llm"):
        raise ValueError(f"规则 {p.name} detect.method 非法: {method}")
    if rule["classify"] not in ("deterministic", "llm", "hybrid"):
        raise ValueError(f"规则 {p.name} classify 非法: {rule['classify']}")
