"""日本語の作業報告書(Markdown)を生成する。
顧客提出用の成果物。コンソール出力(開発者向け)とは別に、
output/ 配下に 報告書_*.md として書き出す。
"""
import datetime
import difflib
import pathlib


def save_html_diff(out_path, from_lines, to_lines, from_desc, to_desc):
    """左右並列の差分HTMLを出力(Python標準 difflib)。"""
    html = difflib.HtmlDiff(wrapcolumn=100).make_file(
        from_lines, to_lines, from_desc, to_desc, context=True, numlines=3)
    p = pathlib.Path(out_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(html, encoding="utf-8")
    return p


def _now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _save(out_dir, name, text):
    out_dir = pathlib.Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    p = out_dir / name
    p.write_text(text, encoding="utf-8")
    return p


# ---------------- 検出フェーズ ----------------
def render_detect(report: dict) -> str:
    L = []
    L.append("# RPG→Java 手動補完　作業報告書（検出フェーズ）")
    L.append("")
    L.append(f"- 生成日時: {_now()}")
    L.append(f"- 適用ルール: {', '.join(report.get('rules_loaded', [])) or '(なし)'}")
    L.append("")
    for f in report.get("files", []):
        L.append(f"## 対象ファイル: `{f['file']}`")
        L.append("")
        L.append(f"- 行数: {f['lines']} / エンコーディング: {f['encoding']}")
        L.append(f"- ルールヒット合計: **{f['matched_total']}** 件")
        L.append(f"- ルール未整備マーカー: **{f['unmatched_total']}** 件（要ルール追加）")
        L.append("")
        L.append("### ヒットしたルール")
        L.append("")
        L.append("| ルールID | 件数 |")
        L.append("|---|---:|")
        for rid, n in sorted(f["matched"].items(), key=lambda x: -x[1]):
            L.append(f"| {rid} | {n} |")
        if not f["matched"]:
            L.append("| (なし) | 0 |")
        L.append("")
        L.append("### 未対応マーカー（ルール未整備・優先度順）")
        L.append("")
        L.append("| マーカー種別 | 件数 |")
        L.append("|---|---:|")
        for key, n in sorted(f["unmatched"].items(), key=lambda x: -x[1])[:20]:
            L.append(f"| {key} | {n} |")
        L.append("")
    L.append("---")
    L.append("> 件数の多いマーカー種別から優先的にルールを整備することを推奨します。")
    return "\n".join(L)


# ---------------- 補完フェーズ ----------------
def render_complete(changelogs: list) -> str:
    L = []
    L.append("# RPG→Java 手動補完　作業報告書（補完フェーズ）")
    L.append("")
    L.append(f"- 生成日時: {_now()}")
    L.append("")
    tot_det = tot_llm = tot_skip = tot_review = 0
    for c in changelogs:
        det = len(c["deterministic"])
        llm = len(c["llm"])
        skip = len(c["skipped"])
        review = [x for x in c["llm"] if x.get("needs_review")]
        tot_det += det
        tot_llm += llm
        tot_skip += skip
        tot_review += len(review)
        L.append(f"## 対象ファイル: `{c['file']}`")
        L.append("")
        L.append("| 区分 | 件数 | 説明 |")
        L.append("|---|---:|---|")
        L.append(f"| 確定的補完 | {det} | Python による自動置換（LLM不使用） |")
        L.append(f"| LLM補完 | {llm} | 局所コンテキストで LLM が補完 |")
        L.append(f"| スキップ | {skip} | 補完できず（要確認） |")
        L.append(f"| 要人手レビュー | {len(review)} | LLM補完のうち低信頼度 |")
        L.append("")
        if review:
            L.append("### 要人手レビュー箇所")
            L.append("")
            L.append("| 行 | ルールID | 信頼度 | 理由 |")
            L.append("|---:|---|---:|---|")
            for r in review:
                L.append(f"| {r['line']} | {r['rule_id']} | "
                         f"{r.get('confidence')} | {r.get('reason', '')} |")
            L.append("")
    L.append("## 全体サマリ")
    L.append("")
    L.append("| 区分 | 件数 |")
    L.append("|---|---:|")
    L.append(f"| 確定的補完（自動） | {tot_det} |")
    L.append(f"| LLM補完 | {tot_llm} |")
    L.append(f"| スキップ | {tot_skip} |")
    L.append(f"| 要人手レビュー | {tot_review} |")
    total = tot_det + tot_llm + tot_skip
    if total:
        auto = (tot_det + tot_llm) / total * 100
        L.append("")
        L.append(f"- 自動補完率: **{auto:.1f}%** （確定的+LLM / 全体）")
    return "\n".join(L)


# ---------------- 検証フェーズ ----------------
def render_validate(report: dict) -> str:
    L = []
    L.append("# RPG→Java 手動補完　作業報告書（検証フェーズ）")
    L.append("")
    L.append(f"- 生成日時: {_now()}")
    L.append("")
    L.append("> **判定基準**: 「完全一致」と「等価差異（書式・空白のみ相違、ロジック同一）」を合格とし、")
    L.append("> 「ロジック差異」のみ要確認とする。")
    L.append("")
    s = report.get("summary", {})
    L.append(f"## 総合一致率: **{s.get('overall_match_rate')}%**")
    L.append("")
    c = s.get("counts", {})
    L.append("| 区分 | 行数 |")
    L.append("|---|---:|")
    L.append(f"| 完全一致 | {c.get('identical', 0)} |")
    L.append(f"| 等価差異（合格） | {c.get('equivalent', 0)} |")
    L.append(f"| ロジック差異（要確認） | {c.get('logic_diff', 0)} |")
    L.append("")
    for f in report.get("files", []):
        L.append(f"## 対象ファイル: `{f['file']}`  一致率 {f['match_rate']}%")
        L.append("")
        cc = f["counts"]
        L.append(f"- 完全一致 {cc['identical']} / 等価 {cc['equivalent']} / "
                 f"ロジック差異 {cc['logic_diff']}")
        hunks = f.get("logic_diff_hunks", [])
        if hunks:
            L.append("")
            L.append("### ロジック差異箇所（要確認）")
            for h in hunks[:30]:
                L.append("")
                L.append(f"- AI出力 {h['ai_lines']} 行目付近 / 人手版 {h['fixed_lines']} 行目付近")
                L.append("```diff")
                for a in h["ai"]:
                    L.append(f"- {a}")
                for b in h["fixed"]:
                    L.append(f"+ {b}")
                L.append("```")
        L.append("")
    return "\n".join(L)


def save_detect(out_dir, report):
    return _save(out_dir, "報告書_検出.md", render_detect(report))


def save_complete(out_dir, changelogs):
    return _save(out_dir, "報告書_補完.md", render_complete(changelogs))


def save_validate(out_dir, report):
    return _save(out_dir, "報告書_検証.md", render_validate(report))
