"""complete 模式：检测 → 路由 → 应用 → 输出。

规则/skill 来源: 优先 skills/ (mine 推导, 含 prompt); 没有则回退 rules/。
- deterministic: transform → python 直接改, 零 LLM。
- llm: 用 skill 里的 prompt(mine 生成) + 局部代码窗口 + RPG 片段 → LLM 返回补丁。
  绝不整文件塞给 LLM。所有改动按行号从大到小统一应用(避免行号串位)。
"""
import json

from ..io_util import JavaText
from ..rules import load_rules
from ..detect import detect_rule
from ..patch import apply_deterministic, apply_builtin_rule, apply_example_rule
from ..guardrails import validate_response, validate_del_add
from .. import report as report_mod
from .. import skill as skillmod


def _load_skills_or_rules(cfg):
    """优先 skills/(mine 产出); 为空则回退 rules/。统一成 skill dict 列表。"""
    skills = skillmod.load_skills(cfg.path("skills_dir"))
    if skills:
        return skills, "skills"
    return load_rules(cfg.path("rules_dir")), "rules"


def _build_llm_context(cfg, skill, java, occ):
    """对一个需 LLM 的命中点，准备局部代码窗口与 RPG 上下文。"""
    win = skill.get("context") or cfg.get("context_window", default={"before": 25, "after": 25})
    start, ctx = java.region(occ["line"], win.get("before", 25), win.get("after", 25))
    rel = occ["line"] - start + 1
    rpg_ctx = ""
    if skill.get("needs_rpg"):
        rpg_ctx = skillmod.rpg_snippet(cfg, java.path, occ["text"])
    return {"start_line": start, "context_code": ctx, "hit_line_in_context": rel, "rpg_context": rpg_ctx}


def _llm_complete_one(client, skill, llm_ctx, validation_errors=None, previous_attempt=None):
    """对一个需 LLM 的命中点: 用 skill prompt + 局部上下文 调 LLM。"""
    # prompt: skill 自带(mine 生成)。没有 prompt(回退 rules 的 llm 规则)时临时拼一个。
    sys_prompt = skill.get("prompt") or _fallback_prompt(skill)
    if validation_errors:
        bullet = "\n".join(f"- {e}" for e in validation_errors)
        sys_prompt += (
            "\n\n# 前回出力の検証失敗\n"
            f"{bullet}\n"
            "上記の検証条件をすべて満たす JSON のみ再出力すること。"
        )
    user = {
        "hit_line_in_context": llm_ctx["hit_line_in_context"],
        "context_code": llm_ctx["context_code"],
        "rpg_context": llm_ctx["rpg_context"],
    }
    if validation_errors:
        user["validation_errors"] = validation_errors
    if previous_attempt:
        user["previous_attempt"] = previous_attempt
    res = client.chat(sys_prompt, json.dumps(user, ensure_ascii=False), json_mode=True)
    res["_ctx_start"] = llm_ctx["start_line"]
    return res


def _apply_llm_with_retry(client, cfg, skill, java, occ):
    """LLM 生成 → 客观校验 → 不通过则带反馈重试。"""
    llm_ctx = _build_llm_context(cfg, skill, java, occ)
    max_retries = cfg.get("complete", "llm_retry", "max_retries", default=2)
    attempts = []
    validation_errors = None
    previous_attempt = None

    for attempt_no in range(1, max_retries + 2):
        response = _llm_complete_one(
            client,
            skill,
            llm_ctx,
            validation_errors=validation_errors,
            previous_attempt=previous_attempt,
        )
        check = validate_response(
            skill,
            occ,
            llm_ctx["context_code"],
            llm_ctx["hit_line_in_context"],
            response,
        )
        attempts.append({
            "attempt": attempt_no,
            "start_line": response.get("start_line"),
            "end_line": response.get("end_line"),
            "confidence": response.get("confidence"),
            "reason": response.get("reason"),
            "validation_errors": check.errors,
        })
        if check.ok:
            s = response["_ctx_start"] + response["start_line"] - 1
            e = response["_ctx_start"] + response["end_line"] - 1
            java.lines[s - 1:e] = response["replacement"]
            return {
                "applied": True,
                "response": response,
                "attempts": attempts,
            }

        validation_errors = check.errors
        previous_attempt = {
            "start_line": response.get("start_line"),
            "end_line": response.get("end_line"),
            "replacement": response.get("replacement"),
            "confidence": response.get("confidence"),
            "reason": response.get("reason"),
        }

    return {
        "applied": False,
        "attempts": attempts,
        "validation_errors": validation_errors or ["Unknown validation failure."],
    }


def _is_del_add(skill):
    """skill 的人手例子里出现 //ndz-add → 属于"删除画面块+新增代码"型。"""
    for ex in skill.get("examples") or []:
        for line in ex.get("after") or []:
            if "//ndz-add" in line:
                return True
    return False


_DEL_ADD_PROMPT = """\
あなたはRPG→Java移行の補完エンジンです。規則「{id} {title}」を適用します。
これは「画面処理ブロックを削除(無効化)し、新システム(ICS)の代替コードを追加する」タイプです。

# 人手修正の実例(BEFORE=ツール出力 / AFTER=人手版)。同じ方針で判断すること。
{examples}

# 入力(ユーザが JSON で渡す)
{{"hit_line_in_context": int, "context_code": [...], "rpg_context": "..."}}

# あなたの出力(JSONのみ)。元コードを逐語でコメント化する必要はない(それは自動で行う):
{{"del_start": int, "del_end": int, "add_code": ["..."], "confidence": 0.0-1.0, "reason": "..."}}
- del_start/del_end: context_code 内で無効化する画面ブロックの開始/終了行(1始まり)。hit_line を含むこと。
- do{{...}} など対応する閉じ括弧まで含め、括弧バランスを壊さない範囲を選ぶこと。
- del_start は hit_line-4 以上、del_end は hit_line+12 以下、範囲は16行以内。
- add_code: 削除の代わりに挿入する新システムのコード行(有効コード)。無ければ空配列 []。
- 確証が持てない場合は confidence<0.6。
"""


def _del_add_prompt(skill):
    exs = skill.get("examples") or []
    blocks = []
    for i, ex in enumerate(exs[:3], start=1):
        before = "\n".join(ex.get("before") or [])
        after = "\n".join(ex.get("after") or [])
        blocks.append(f"## 例{i}\n[BEFORE]\n{before}\n[AFTER]\n{after}")
    return _DEL_ADD_PROMPT.format(id=skill.get("id"), title=skill.get("title", ""),
                                  examples="\n\n".join(blocks) or "(例なし)")


def _apply_del_add_with_retry(client, cfg, skill, java, occ):
    """del_add 契约: LLM 返回 {del_start,del_end,add_code}, python 拼 //ndz-del + //ndz-add。"""
    llm_ctx = _build_llm_context(cfg, skill, java, occ)
    ctx, hit = llm_ctx["context_code"], llm_ctx["hit_line_in_context"]
    max_retries = cfg.get("complete", "llm_retry", "max_retries", default=2)
    sys_prompt = _del_add_prompt(skill)
    attempts, verrs, prev = [], None, None

    for _ in range(max_retries + 1):
        user = {"hit_line_in_context": hit, "context_code": ctx, "rpg_context": llm_ctx["rpg_context"]}
        if verrs:
            user["validation_errors"] = verrs
        if prev:
            user["previous_attempt"] = prev
        resp = client.chat(sys_prompt, json.dumps(user, ensure_ascii=False), json_mode=True)
        check = validate_del_add(skill, occ, ctx, hit, resp)
        attempts.append({"del_start": resp.get("del_start"), "del_end": resp.get("del_end"),
                         "confidence": resp.get("confidence"), "validation_errors": check.errors})
        if check.ok:
            ds, de = resp["del_start"], resp["del_end"]
            orig = ctx[ds - 1:de]
            block = ["//ndz-del-s"] + ["//" + l for l in orig] + ["//ndz-del-e"]
            if resp.get("add_code"):
                block += ["//ndz-add-s"] + resp["add_code"] + ["//ndz-add-e"]
            s = llm_ctx["start_line"] + ds - 1
            e = llm_ctx["start_line"] + de - 1
            java.lines[s - 1:e] = block
            return {"applied": True, "response": resp, "attempts": attempts, "del_add": True}
        verrs = check.errors
        prev = {k: resp.get(k) for k in ("del_start", "del_end", "add_code", "reason")}

    return {"applied": False, "attempts": attempts,
            "validation_errors": verrs or ["Unknown validation failure."]}


def _fallback_prompt(skill):
    return (f"あなたはRPG→Java移行の補完エンジンです。規則「{skill.get('id')} "
            f"{skill.get('title','')}」に従い、指定行を補完します。"
            f"方針: {skill.get('guidance','')}。"
            '出力はJSONのみ: {"start_line":int,"end_line":int,"replacement":[".."],'
            '"confidence":0-1,"reason":".."}。確証が無ければ confidence<0.6。')


def run(cfg, use_llm=True):
    from ..llm_client import LLMClient
    skills, src = _load_skills_or_rules(cfg)
    out_dir = cfg.path("output_dir")
    client = LLMClient(cfg) if use_llm else None
    changelogs = []
    # 某规则任一变体的例子含 ndz-add → 该规则(所有变体)按 del_add 处理
    def _base(i):
        return str(i).split("__")[0]
    deladd_bases = {_base(sk["id"]) for sk in skills if _is_del_add(sk)}
    print(f"[complete] 规则来源: {src}/ ({len(skills)} 条)  del_add规则: {sorted(deladd_bases) or '无'}")

    for fp in skillmod.iter_half_java(cfg):
        java = JavaText.load(fp, cfg.encoding)
        original_lines = list(java.lines)
        changelog = {"file": fp.name, "deterministic": [], "llm": [], "skipped": []}

        det_items, llm_items = [], []
        for sk in skills:
            for occ in detect_rule(sk, java.lines):
                if sk["classify"] == "deterministic" and sk.get("transform", {}).get("type") in (
                        "comment_out_block", "regex_replace", "template"):
                    det_items.append((occ, sk))
                elif sk["classify"] in ("llm", "hybrid"):
                    llm_items.append((occ, sk))

        # 确定性 + LLM 合并, 按行号从大到小统一应用
        all_items = ([(o, s, "det") for o, s in det_items] +
                     [(o, s, "llm") for o, s in llm_items])
        all_items.sort(key=lambda x: x[0]["line"], reverse=True)
        seen_lines = set()
        for occ, sk, kind in all_items:
            if occ["line"] in seen_lines:   # 同一行被多 skill(如 EXFMT 变体)命中→只处理一次
                continue
            seen_lines.add(occ["line"])
            # 内建确定性处理器(RECNO/DFTACTGRP/5.9): 比 LLM 安全, 优先
            builtin = apply_builtin_rule(java, occ, sk)
            if builtin and builtin.get("applied"):
                changelog["deterministic"].append(builtin)
                continue
            if kind == "det":
                # 确定性规则: 先试精确例子回放, 不行用 transform
                example_patch = apply_example_rule(java, occ, sk)
                if example_patch.get("applied"):
                    example_patch["rule_id"] = sk["id"]
                    changelog["deterministic"].append(example_patch)
                    continue
                changelog["deterministic"].append(apply_deterministic(java, [(occ, sk)])[0])
                continue
            # kind == "llm": 直接走 LLM + guardrails(不再被宽松例子回放截胡)
            if not use_llm:
                changelog["skipped"].append({"rule_id": sk["id"], "line": occ["line"],
                                             "reason": "use_llm=False"})
                continue
            try:
                if _base(sk["id"]) in deladd_bases:
                    res = _apply_del_add_with_retry(client, cfg, sk, java, occ)
                else:
                    res = _apply_llm_with_retry(client, cfg, sk, java, occ)
                if not res["applied"]:
                    changelog["skipped"].append({
                        "rule_id": sk["id"],
                        "line": occ["line"],
                        "reason": "LLM校验失败",
                        "validation_errors": res["validation_errors"],
                        "attempts": len(res["attempts"]),
                    })
                    continue

                r = res["response"]
                retry_count = max(0, len(res["attempts"]) - 1)
                # del_add(EXFMT 这类删画面块+写新逻辑)→ 业务代码不可信 LLM 置信, 一律人工复核
                needs_review = (r.get("confidence") or 0) < 0.8 or res.get("del_add", False)
                changelog["llm"].append({
                    "rule_id": sk["id"],
                    "line": occ["line"],
                    "confidence": r.get("confidence"),
                    "reason": r.get("reason"),
                    "needs_review": needs_review,
                    "retry_count": retry_count,
                    "attempts": res["attempts"],
                    "validated": True,
                })
            except Exception as ex:
                changelog["skipped"].append({"rule_id": sk["id"], "line": occ["line"],
                                             "reason": f"LLM失败: {ex}"})

        stem_dir = out_dir / fp.stem
        java.save(stem_dir / fp.name)
        with open(stem_dir / (fp.stem + ".changelog.json"), "w", encoding="utf-8") as f:
            json.dump(changelog, f, ensure_ascii=False, indent=2)
        report_mod.save_html_diff(
            stem_dir / "diff_vs_original.html", original_lines, java.lines,
            f"{fp.name}（変換ツール出力）", f"{fp.name}（AI補完後）")
        changelogs.append(changelog)

        d, l, s = len(changelog["deterministic"]), len(changelog["llm"]), len(changelog["skipped"])
        print(f"[complete] {fp.name}: 确定性 {d} / LLM {l} / 跳过 {s} → {stem_dir/fp.name}")
        retry_fixed = [x for x in changelog["llm"] if x.get("retry_count", 0) > 0]
        if retry_fixed:
            print(f"           ↻ {len(retry_fixed)} 处经校验反馈后自动重试通过")
        review = [x for x in changelog["llm"] if x.get("needs_review")]
        if review:
            print(f"           ⚠ {len(review)} 处低置信，建议人工复核")

    md = report_mod.save_complete(out_dir, changelogs)
    print(f"[complete] 日本語報告書: {md}")
