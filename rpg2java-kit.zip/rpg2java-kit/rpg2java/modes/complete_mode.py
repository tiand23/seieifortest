"""complete 模式：检测 → 路由 → 应用 → 输出。

规模化设计(应对 30+ 规则/上百改动/5分钟超时/429):
1) 确定性优先：内建 handler / 例子回放 / transform，全程 Python，零 LLM。
2) LLM 仅用于真复杂规则(如 EXFMT)。**同一规则多处打包进一次调用**(批量)，
   **温和并发**(默认3路)，client 层 **429 指数退避**。
3) **断点续跑**：LLM 补丁存 output/<stem>/.progress.json，被杀后重跑跳过已完成。
   (确定性部分每次重算，便宜且确定；只 checkpoint 昂贵的 LLM 结果)
4) 所有补丁最后按行号从大到小统一应用(避免串位)。
"""
import re
import json
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..io_util import JavaText
from ..rules import load_rules
from ..detect import detect_rule
from ..patch import apply_deterministic, apply_builtin_rule, apply_example_rule, _BUILTIN_RULE_HANDLERS
from ..guardrails import validate_response, validate_del_add
from .. import report as report_mod
from .. import skill as skillmod

_BUILTIN = set(_BUILTIN_RULE_HANDLERS)


def _load_skills_or_rules(cfg):
    skills = skillmod.load_skills(cfg.path("skills_dir"))
    if skills:
        return skills, "skills"
    return load_rules(cfg.path("rules_dir")), "rules"


def _base(rid):
    return str(rid).split("__")[0]


def _is_llm_skill(sk):
    """真正要走 LLM 的: classify=llm/hybrid 且没有内建确定性 handler。"""
    return sk.get("classify") in ("llm", "hybrid") and _base(sk["id"]) not in _BUILTIN


def _is_del_add(skill):
    for ex in skill.get("examples") or []:
        for line in ex.get("after") or []:
            if "//ndz-add" in line:
                return True
    return False


# ---------------- prompt ----------------
def _fallback_prompt(skill):
    return (f"あなたはRPG→Java移行の補完エンジンです。規則「{skill.get('id')} "
            f"{skill.get('title','')}」に従い補完します。方針: {skill.get('guidance','')}。")


_DEL_ADD_PROMPT = """\
あなたはRPG→Java移行の補完エンジンです。規則「{id} {title}」を適用します。
画面処理ブロックを削除(無効化)し、新システム(ICS)の代替コードを追加するタイプです。

# 人手修正の実例(BEFORE=ツール出力 / AFTER=人手版)。同じ方針で。
{examples}
"""


def _del_add_prompt(skill):
    blocks = []
    for i, ex in enumerate((skill.get("examples") or [])[:3], 1):
        blocks.append(f"## 例{i}\n[BEFORE]\n" + "\n".join(ex.get("before") or [])
                      + "\n[AFTER]\n" + "\n".join(ex.get("after") or []))
    return _DEL_ADD_PROMPT.format(id=skill.get("id"), title=skill.get("title", ""),
                                  examples="\n\n".join(blocks) or "(例なし)")


# ★ コードはJSONに入れず、区切り形式の生テキストで返させる(JSON破損を根絶)
_BATCH_REPLACE = """

# 入力
ユーザは {"items":[{"id":..,"hit_line_in_context":int,"context_code":[..],"rpg_context":".."}, ...]} を渡す。

# 出力形式(厳守・JSONや```は禁止)
各 item について、次の区切りブロックだけを順に出力する:
<<<PATCH id=（item.idをそのまま） range=（開始行）-（終了行） conf=（0.0〜1.0）>>>
（補完後のコード行をそのまま。エスケープ不要・生のコード。元コードの//コメント化もそのまま書く）
<<<END>>>
- range は item の context_code 内の行番号(1始まり)で、必ず hit_line を含む。
- 説明文・JSON・``` は一切出力しない。ブロックだけ。
"""

_BATCH_DELADD = """

# 入力
ユーザは {"items":[{"id":..,"hit_line_in_context":int,"context_code":[..],"rpg_context":".."}, ...]} を渡す。

# 出力形式(厳守・JSONや```は禁止)
各 item について、次の区切りブロックだけを順に出力する:
<<<PATCH id=（item.idをそのまま） del=（開始行）-（終了行） conf=（0.0〜1.0）>>>
（削除の代わりに挿入する新コード行をそのまま。無ければ何も書かない。生のコード・エスケープ不要）
<<<END>>>
- del は context_code 内の無効化範囲(hit_line を含む、括弧バランスを壊さない)。
- 説明文・JSON・``` は一切出力しない。ブロックだけ。
"""

_PATCH_RE = re.compile(r"<<<PATCH\s+(?P<hdr>[^>]*?)>>>[ \t]*\n(?P<body>.*?)\n?<<<END>>>", re.S)


def _parse_patches(text, deladd):
    """解析区切り形式 → {id: resp}。代码原样,无 JSON 转义问题。"""
    out = {}
    for m in _PATCH_RE.finditer(text or ""):
        kv = dict(re.findall(r"(\w+)=(\S+)", m.group("hdr")))
        rid = kv.get("id")
        if not rid:
            continue
        body = m.group("body")
        lines = body.split("\n") if body else []
        while lines and lines[-1] == "":
            lines.pop()
        try:
            conf = float(kv.get("conf", "0"))
        except Exception:
            conf = 0.0
        mr = re.match(r"(\d+)-(\d+)", kv.get("del" if deladd else "range", ""))
        a, b = (int(mr.group(1)), int(mr.group(2))) if mr else (None, None)
        if deladd:
            out[rid] = {"id": rid, "del_start": a, "del_end": b, "add_code": lines,
                        "confidence": conf, "reason": ""}
        else:
            out[rid] = {"id": rid, "start_line": a, "end_line": b, "replacement": lines,
                        "confidence": conf, "reason": ""}
    return out


def _sys_prompt(skill, deladd):
    base = _del_add_prompt(skill) if deladd else (skill.get("prompt") or _fallback_prompt(skill))
    return base + (_BATCH_DELADD if deladd else _BATCH_REPLACE)


# ---------------- LLM 批量求解 ----------------
def _build_item(cfg, skill, java, occ):
    win = skill.get("context") or cfg.get("context_window", default={"before": 25, "after": 25})
    start, ctx = java.region(occ["line"], win.get("before", 25), win.get("after", 25))
    rpg = skillmod.rpg_snippet(cfg, java.path, occ["text"]) if skill.get("needs_rpg") else ""
    return {"id": f"{skill['id']}#{occ['line']}", "occ": occ, "win_start": start,
            "ctx": ctx, "hit": occ["line"] - start + 1, "rpg": rpg}


def _call_batch(client, sysp, items, deladd):
    user = {"items": [{"id": it["id"], "hit_line_in_context": it["hit"],
                       "context_code": it["ctx"], "rpg_context": it["rpg"]} for it in items]}
    try:
        # json_mode=False: 让模型返回区切りテキスト(代码不进JSON, 不会被破坏)
        text = client.chat(sysp, json.dumps(user, ensure_ascii=False), json_mode=False)
    except Exception as e:
        print(f"  [llm] バッチ失敗(後でリトライ): {e}")
        return {}
    return _parse_patches(text, deladd)


def _validate_and_patch(skill, it, resp, deladd):
    if deladd:
        vr = validate_del_add(skill, it["occ"], it["ctx"], it["hit"], resp)
        if not vr.ok:
            return None, vr.errors
        ds, de = resp["del_start"], resp["del_end"]
        orig = it["ctx"][ds - 1:de]
        block = ["//ndz-del-s"] + ["//" + l for l in orig] + ["//ndz-del-e"]
        if resp.get("add_code"):
            block += ["//ndz-add-s"] + list(resp["add_code"]) + ["//ndz-add-e"]
        return {"abs_start": it["win_start"] + ds - 1, "abs_end": it["win_start"] + de - 1,
                "replacement": block, "rule_id": skill["id"], "line": it["occ"]["line"],
                "confidence": resp.get("confidence"), "reason": resp.get("reason"),
                "needs_review": True}, []
    vr = validate_response(skill, it["occ"], it["ctx"], it["hit"], resp)
    if not vr.ok:
        return None, vr.errors
    return {"abs_start": it["win_start"] + resp["start_line"] - 1,
            "abs_end": it["win_start"] + resp["end_line"] - 1,
            "replacement": list(resp["replacement"]), "rule_id": skill["id"],
            "line": it["occ"]["line"], "confidence": resp.get("confidence"),
            "reason": resp.get("reason"),
            "needs_review": (resp.get("confidence") or 0) < 0.8}, []


def _solve(client, cfg, skill, items, deladd, solved, save_cb):
    bs = cfg.get("complete", "batch_size", default=5)
    conc = cfg.get("complete", "concurrency", default=3)
    max_r = cfg.get("complete", "llm_retry", "max_retries", default=2)
    sysp = _sys_prompt(skill, deladd)
    pending = [it for it in items if it["id"] not in solved["patches"] and it["id"] not in solved["skipped"]]
    feedback = ""
    for _ in range(max_r + 1):
        if not pending:
            break
        sp = sysp + (f"\n# 前回検証NG(修正せよ): {feedback}" if feedback else "")
        chunks = [pending[i:i + bs] for i in range(0, len(pending), bs)]
        still, errs = [], []
        with ThreadPoolExecutor(max_workers=conc) as ex:
            futs = {ex.submit(_call_batch, client, sp, ch, deladd): ch for ch in chunks}
            for fut in as_completed(futs):
                ch = futs[fut]
                try:
                    responses = fut.result()
                except Exception:
                    responses = {}
                for it in ch:
                    resp = responses.get(it["id"])
                    if not resp:
                        still.append(it)
                        continue
                    patch, e = _validate_and_patch(skill, it, resp, deladd)
                    if patch:
                        solved["patches"][it["id"]] = patch
                    else:
                        still.append(it)
                        errs += e
                save_cb()  # 每个 chunk 完成就存盘(细粒度断点)
        pending = still
        feedback = "; ".join(dict.fromkeys(errs))[:300]
    for it in pending:
        solved["skipped"][it["id"]] = {"rule_id": skill["id"], "line": it["occ"]["line"],
                                       "reason": "LLM校验失败(重试耗尽): " + feedback, "needs_review": True}
    save_cb()


# ---------------- 主流程 ----------------
def run(cfg, use_llm=True):
    from ..llm_client import LLMClient
    skills, src = _load_skills_or_rules(cfg)
    out_dir = cfg.path("output_dir")
    client = LLMClient(cfg) if use_llm else None
    deladd_bases = {_base(sk["id"]) for sk in skills if _is_del_add(sk)}
    changelogs = []
    print(f"[complete] 规则来源: {src}/ ({len(skills)} 条)  del_add: {sorted(deladd_bases) or '无'}")

    for fp in skillmod.iter_half_java(cfg):
        java = JavaText.load(fp, cfg.encoding)
        original_lines = list(java.lines)
        stem_dir = out_dir / fp.stem
        stem_dir.mkdir(parents=True, exist_ok=True)
        changelog = {"file": fp.name, "deterministic": [], "llm": [], "skipped": []}

        # ---- 阶段1: 确定性(内建/例子/transform), 全程 Python, 按行号倒序 ----
        det_occ = []
        for sk in skills:
            if not _is_llm_skill(sk):
                for occ in detect_rule(sk, java.lines):
                    det_occ.append((occ, sk))
        for occ, sk in sorted(det_occ, key=lambda x: x[0]["line"], reverse=True):
            b = apply_builtin_rule(java, occ, sk)
            if b and b.get("applied"):
                changelog["deterministic"].append(b)
                continue
            ex = apply_example_rule(java, occ, sk)
            if ex.get("applied"):
                ex["rule_id"] = sk["id"]
                changelog["deterministic"].append(ex)
                continue
            if sk.get("transform"):
                changelog["deterministic"].append(apply_deterministic(java, [(occ, sk)])[0])

        # ---- 阶段2: LLM(批量+并发+续跑), 在 post-det 文件上重新检测 ----
        prog_path = stem_dir / ".progress.json"
        solved = {"patches": {}, "skipped": {}}
        if prog_path.exists():
            try:
                solved = json.loads(prog_path.read_text(encoding="utf-8"))
                solved.setdefault("patches", {})
                solved.setdefault("skipped", {})
            except Exception:
                pass

        def _save():
            prog_path.write_text(json.dumps(solved, ensure_ascii=False), encoding="utf-8")

        # 去重: 同一行被多个变体(同 base 规则)命中 → 只处理一次
        uniq = {}
        for sk in skills:
            if not _is_llm_skill(sk):
                continue
            for occ in detect_rule(sk, java.lines):
                uniq.setdefault((_base(sk["id"]), occ["line"]), (occ, sk))

        if use_llm:
            groups = defaultdict(list)
            for occ, sk in uniq.values():
                groups[sk["id"]].append(occ)
            sk_by_id = {sk["id"]: sk for sk in skills}
            for sid, occs in groups.items():
                sk = sk_by_id[sid]
                items = [_build_item(cfg, sk, java, occ) for occ in occs]
                _solve(client, cfg, sk, items, _base(sid) in deladd_bases, solved, _save)
        else:
            for (_b, line), (occ, sk) in uniq.items():
                changelog["skipped"].append({"rule_id": sk["id"], "line": line,
                                             "reason": "use_llm=False"})

        # ---- 应用所有 LLM 补丁(行号倒序) ----
        for p in sorted(solved["patches"].values(), key=lambda x: x["abs_start"], reverse=True):
            java.lines[p["abs_start"] - 1:p["abs_end"]] = p["replacement"]
            changelog["llm"].append({"rule_id": p["rule_id"], "line": p["line"],
                                     "confidence": p.get("confidence"), "reason": p.get("reason"),
                                     "needs_review": p.get("needs_review")})
        changelog["skipped"].extend(solved["skipped"].values())

        # ---- 输出 ----
        java.save(stem_dir / fp.name)
        with open(stem_dir / (fp.stem + ".changelog.json"), "w", encoding="utf-8") as f:
            json.dump(changelog, f, ensure_ascii=False, indent=2)
        report_mod.save_html_diff(stem_dir / "diff_vs_original.html", original_lines, java.lines,
                                  f"{fp.name}（変換ツール出力）", f"{fp.name}（AI補完後）")
        if prog_path.exists():
            prog_path.unlink()  # 完成 → 清掉断点
        changelogs.append(changelog)

        d, l, s = len(changelog["deterministic"]), len(changelog["llm"]), len(changelog["skipped"])
        print(f"[complete] {fp.name}: 确定性 {d} / LLM {l} / 跳过 {s} → {stem_dir/fp.name}")
        review = [x for x in changelog["llm"] if x.get("needs_review")]
        if review:
            print(f"           ⚠ {len(review)} 处需人工复核")

    md = report_mod.save_complete(out_dir, changelogs)
    print(f"[complete] 日本語報告書: {md}")
