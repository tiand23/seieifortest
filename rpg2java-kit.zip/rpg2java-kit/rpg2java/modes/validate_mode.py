"""validate 模式：AI 输出 vs 人工修改版，语义分级 + 匹配率。
需要人工版 —— 客户环境跑。

差异三级(对应客户'差异不大'的验收口径):
  identical  : 逐字相同
  equivalent : 忽略空白/格式后相同(等价差异，算通过)
  logic_diff : 真不同(需要看，可选 LLM 判等价)
"""
import json
import difflib

from ..io_util import JavaText
from ..diffutil import equal_ignoring_format
from .. import report as report_mod


def run(cfg, use_llm=False):
    out_dir = cfg.path("output_dir")
    fixed_dir = cfg.path("human_dir")
    if not fixed_dir.exists():
        print(f"[validate] 缺人工版目录: {fixed_dir}")
        return

    report = {"files": [], "summary": {}}
    tot = {"identical": 0, "equivalent": 0, "logic_diff": 0}

    for fixed_fp in sorted(fixed_dir.rglob("*.java")):
        ai_fp = out_dir / fixed_fp.stem / fixed_fp.name   # complete の成果物
        if not ai_fp.exists():
            continue
        ai = JavaText.load(ai_fp, cfg.encoding)
        fx = JavaText.load(fixed_fp, cfg.encoding)
        # 人手版との左右差分HTML(java名フォルダに格納)
        report_mod.save_html_diff(
            out_dir / fixed_fp.stem / "diff_vs_human.html", ai.lines, fx.lines,
            f"{fixed_fp.name}（AI補完後）", f"{fixed_fp.name}（人手修正版）")
        sm = difflib.SequenceMatcher(a=ai.lines, b=fx.lines)
        counts = {"identical": 0, "equivalent": 0, "logic_diff": 0}
        hunks = []
        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == "equal":
                counts["identical"] += (i2 - i1)
                continue
            a_blk = "\n".join(ai.lines[i1:i2])
            b_blk = "\n".join(fx.lines[j1:j2])
            if equal_ignoring_format(a_blk, b_blk):
                counts["equivalent"] += max(i2 - i1, j2 - j1)
                level = "equivalent"
            else:
                counts["logic_diff"] += max(i2 - i1, j2 - j1)
                level = "logic_diff"
                hunks.append({"ai_lines": [i1 + 1, i2], "fixed_lines": [j1 + 1, j2],
                              "ai": ai.lines[i1:i2], "fixed": fx.lines[j1:j2]})
        for k in tot:
            tot[k] += counts[k]
        passed = counts["identical"] + counts["equivalent"]
        total = passed + counts["logic_diff"]
        rate = (passed / total * 100) if total else 100.0
        print(f"[validate] {fixed_fp.name}: 一致 {counts['identical']} / "
              f"等价 {counts['equivalent']} / 逻辑差 {counts['logic_diff']}  → 匹配率 {rate:.1f}%")
        report["files"].append({"file": fixed_fp.name, "counts": counts,
                                "match_rate": round(rate, 1), "logic_diff_hunks": hunks})

    passed = tot["identical"] + tot["equivalent"]
    total = passed + tot["logic_diff"]
    report["summary"] = {"counts": tot,
                         "overall_match_rate": round(passed / total * 100, 1) if total else 100.0}
    out = out_dir / "validate_report.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    md = report_mod.save_validate(out_dir, report)
    print(f"\n[validate] 总匹配率(一致+等价): {report['summary']['overall_match_rate']}%")
    print(f"[validate] JSON: {out}")
    print(f"[validate] 日本語報告書: {md}")
