"""detect 模式：每个 java 命中哪些规则 + 哪些标记还没有规则。
本地即可跑，不需要 LLM / 人工版。"""
import json
import pathlib
from collections import Counter

from ..io_util import JavaText
from ..rules import load_rules
from ..detect import detect_all
from .. import report as report_mod


def _iter_java_files(cfg):
    from .. import skill as skillmod
    return skillmod.iter_half_java(cfg)


def run(cfg):
    rules = load_rules(cfg.path("rules_dir"))
    out_dir = cfg.path("output_dir")
    out_dir.mkdir(parents=True, exist_ok=True)
    report = {"rules_loaded": [r["id"] for r in rules], "files": []}

    files = list(_iter_java_files(cfg))
    if not files:
        print(f"[detect] input 目录无 java: {cfg.path('input_dir')}")
        return

    for fp in files:
        java = JavaText.load(fp, cfg.encoding)
        res = detect_all(rules, java.lines)
        by_rule = Counter(o["rule_id"] for o in res["matched"])
        by_unmatched = Counter(u["key"] for u in res["unmatched"])

        print(f"\n=== {fp.name}  ({len(java.lines)} 行, {java.encoding}, "
              f"{'CRLF' if java.newline == chr(13)+chr(10) else 'LF'}) ===")
        print(f"  命中规则({sum(by_rule.values())} 处):")
        for rid, n in by_rule.most_common():
            print(f"    [{rid}] × {n}")
        print(f"  ⚠ 未命中标记({sum(by_unmatched.values())} 处, 需补规则):")
        for key, n in by_unmatched.most_common(15):
            print(f"    {key} × {n}")

        report["files"].append({
            "file": fp.name,
            "lines": len(java.lines),
            "encoding": java.encoding,
            "matched": dict(by_rule),
            "matched_total": sum(by_rule.values()),
            "unmatched": dict(by_unmatched),
            "unmatched_total": sum(by_unmatched.values()),
        })

    out = out_dir / "detect_report.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    md = report_mod.save_detect(out_dir, report)
    print(f"\n[detect] JSON: {out}")
    print(f"[detect] 日本語報告書: {md}")
