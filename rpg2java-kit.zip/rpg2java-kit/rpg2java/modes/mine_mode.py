"""mine 模式：从 (规则 + 半成品 java + 人工版 java) 推导 skill。

算法(通用, 不认识具体规则):
 1. 整文件全局对齐(difflib SequenceMatcher) —— 取代旧的单锚点(对大文件不准)
 2. 每个命中位置 → 找覆盖它的变更块 → 得到真实的【改前 → 改后】
 3. 把所有 diff 归一化后聚类: 形状单一 → deterministic; 多变 → llm
 4. 生成 skill 到 skills/<id>.md
      - deterministic: 携带 transform (简单规则, complete 用 python 直接改)
      - llm: 生成 prompt(规则说明 + 真实 few-shot 例子 + 输出契约 + 置信策略)
"""
import difflib
import re

from ..io_util import JavaText
from ..rules import load_rules
from ..detect import detect_rule
from ..diffutil import normalize
from .. import skill as skillmod


_LLM_PROMPT = """\
あなたはRPG→Java移行の手動補完エンジンです。規則「{id} {title}」を適用します。

# 規則の説明
{guidance}

# 実際の人手修正例（半成品 → 人手修正版）。同じ方針で補完すること。
{examples}

# 入力
ユーザは JSON で {{"hit_line_in_context", "context_code"(配列), "rpg_context"}} を渡す。
context_code の hit_line_in_context 行(マーカー)を中心に、上記例と同じ方針で補完する。
rpg_context があれば、それを根拠に判断する。

# 出力(JSONのみ)
{{"start_line":int,"end_line":int,"replacement":["..."],"confidence":0.0-1.0,"reason":"..."}}
- start_line/end_line は context_code の行番号(1始まり)。
- rpg_context が無く、COMP/命令由来か確証が持てない場合は変更せず confidence<0.6 とし人手レビューへ。
"""

_WS_RE = re.compile(r"\s+")
_EXFMT_TOKEN_RE = re.compile(r"EXFMT\s+([A-Z0-9_]+)")


def _normalize_marker_text(text):
    text = re.sub(r"^\s*//+\s*", "", text)
    return _WS_RE.sub(" ", text).strip()


def _normalize_code_line(text):
    return _WS_RE.sub(" ", text).strip()


def _strip_one_comment_prefix(line):
    return re.sub(r"^(\s*)//", r"\1", line, count=1)


def _find_block_end(lines, start):
    head = lines[start].strip()
    if head == "//ndz-del-s":
        tail = "//ndz-del-e"
    elif head == "//ndz-add-s":
        tail = "//ndz-add-e"
    else:
        return None
    for i in range(start + 1, len(lines)):
        if lines[i].strip() == tail:
            return i
    return None


def _find_human_marker_line(human_lines, occ_text):
    target = _normalize_marker_text(occ_text)
    for i, line in enumerate(human_lines):
        norm = _normalize_marker_text(line)
        if target and target in norm:
            return i
    return None


def _find_enclosing_del_block(human_lines, marker_idx):
    for i in range(marker_idx, -1, -1):
        if human_lines[i].strip() != "//ndz-del-s":
            continue
        end = _find_block_end(human_lines, i)
        if end is not None and i < marker_idx < end:
            return i, end
    return None


def _locate_exact_block(half_lines, before_lines, occ_line, marker_offset=0, radius=80):
    if not before_lines:
        return None
    occ_idx = occ_line - 1
    anchor_start = occ_idx - marker_offset
    candidates = []
    if 0 <= anchor_start <= len(half_lines) - len(before_lines):
        candidates.append(anchor_start)
    start_lo = max(0, occ_idx - radius)
    start_hi = min(len(half_lines) - len(before_lines), occ_idx + radius)
    candidates.extend(s for s in range(start_lo, start_hi + 1) if s != anchor_start)
    want = [_normalize_code_line(x) for x in before_lines]
    for s in candidates:
        e = s + len(before_lines)
        got = [_normalize_code_line(x) for x in half_lines[s:e]]
        if got == want and s <= occ_idx < e:
            return s, e
    return None


def _locate_cropped_block(half_lines, before_lines, occ_line, marker_offset=0):
    """整块对不上时，尝试从命中点附近裁掉前导行后再定位。"""
    for crop_start in range(1, marker_offset + 1):
        sub_before = before_lines[crop_start:]
        sub_marker = marker_offset - crop_start
        located = _locate_exact_block(
            half_lines,
            sub_before,
            occ_line,
            marker_offset=sub_marker,
        )
        if located:
            return crop_start, located
    return None, None


def _block_contains_other_marker(block_lines, occ_text):
    target = _normalize_marker_text(occ_text)
    for line in block_lines:
        norm = _normalize_marker_text(line)
        if ("TODO" in norm or "FIXME" in norm) and target not in norm:
            return True
    return False


def _extract_annotated_after(human_lines, start, end, occ_text, max_lines=120):
    """从人工版中提取当前命中点所属的 ndz patch 聚簇。"""
    out_end = end + 1
    i = out_end
    while i < len(human_lines) and (i - start) < max_lines:
        line = human_lines[i]
        stripped = line.strip()
        if stripped in ("//ndz-del-s", "//ndz-add-s"):
            block_end = _find_block_end(human_lines, i)
            if block_end is None:
                break
            block = human_lines[i:block_end + 1]
            if _block_contains_other_marker(block, occ_text):
                break
            out_end = block_end + 1
            i = out_end
            continue
        prev = human_lines[i - 1].strip() if i - 1 >= start else ""
        nxt = human_lines[i + 1].strip() if i + 1 < len(human_lines) else ""
        if (prev in ("//ndz-del-e", "//ndz-add-e")
                and nxt in ("//ndz-del-s", "//ndz-add-s")
                and stripped):
            out_end = i + 1
            i += 1
            continue
        break
    return human_lines[start:out_end]


def _crop_annotated_after(full_after, before_len, crop_start):
    if crop_start <= 0:
        return full_after
    first_block = full_after[:before_len + 2]
    rest = full_after[before_len + 2:]
    return ["//ndz-del-s"] + first_block[1 + crop_start:-1] + ["//ndz-del-e"] + rest


def _change_from_human_annotations(rule, occ, half_lines, human_lines):
    marker_idx = _find_human_marker_line(human_lines, occ["text"])
    if marker_idx is None:
        return None
    block = _find_enclosing_del_block(human_lines, marker_idx)
    if not block:
        return None
    start, end = block
    before = [_strip_one_comment_prefix(line) for line in human_lines[start + 1:end]]
    marker_offset = marker_idx - (start + 1)
    located = _locate_exact_block(half_lines, before, occ["line"], marker_offset=marker_offset)
    crop_start = 0
    if not located:
        crop_start, located = _locate_cropped_block(
            half_lines, before, occ["line"], marker_offset=marker_offset
        )
    if not located:
        return None
    after = _extract_annotated_after(human_lines, start, end, occ["text"])
    if not after:
        return None
    if crop_start:
        before = before[crop_start:]
        after = _crop_annotated_after(after, end - start - 1, crop_start)
    return {"before": list(before), "after": list(after), "source": "human_ndz", "occ_text": occ["text"]}


def _change_at(opcodes, half_lines, human_lines, line_no):
    """命中行(1-based)を覆う変更ブロックの 改前→改后。equal なら None。"""
    L = line_no - 1
    for tag, i1, i2, j1, j2 in opcodes:
        if i1 <= L < i2:
            if tag == "equal":
                return None
            return {"before": half_lines[i1:i2], "after": human_lines[j1:j2]}
    return None


def _skill_family(rule_or_skill):
    return str(rule_or_skill.get("variant_of") or rule_or_skill.get("id"))


def _skill_file_prefix(rule_id):
    return str(rule_id).replace(".", "_")


def _remove_existing_skill_files(skills_dir, rule_id):
    prefix = _skill_file_prefix(rule_id)
    for p in skills_dir.glob(f"{prefix}*.md"):
        p.unlink()


def _expected_after(rule, before):
    """把 rule.transform 套用到 before 块, 得到"我们的确定性结果"。无 transform → None。"""
    from ..patch import _HANDLERS
    t = rule.get("transform")
    if not t or t.get("type") not in _HANDLERS:
        return None
    lines = list(before)
    occs = detect_rule(rule, lines)
    if not occs:
        return None
    h = _HANDLERS[t["type"]]
    for o in sorted(occs, key=lambda x: x["line"], reverse=True):
        h(lines, o["line"], t)
    return lines


def _transform_reproduces(rule, changes):
    """确定性 transform 能重现人工 after 的件数。无 transform 返回 None。"""
    if not rule.get("transform"):
        return None
    return sum(1 for c in changes
               if _expected_after(rule, c["before"]) == c["after"])


def _build_skill(rule, classify, changes):
    base = {"id": rule["id"], "title": rule.get("title"),
            "classify": classify, "detect": rule["detect"]}
    examples = [{"before": c["before"], "after": c["after"]} for c in changes[:4]]
    if classify == "deterministic":
        if rule.get("transform"):
            base["transform"] = rule["transform"]      # 简单规则: 携带 transform
        else:
            base["transform"] = {"type": "TODO_define",
                                 "note": "一様だが transform 未定義。手動定義要"}
        base["examples"] = examples
        base["prompt"] = ""
        return base
    # llm: 真实例子填进 prompt
    ex_txt = "\n\n".join(
        f"## 例{i+1}\n[BEFORE]\n" + "\n".join(c["before"]) +
        "\n[AFTER]\n" + "\n".join(c["after"]) for i, c in enumerate(changes[:4]))
    base["needs_rpg"] = True
    base["examples"] = examples
    base["prompt"] = _LLM_PROMPT.format(
        id=rule["id"], title=rule.get("title", ""),
        guidance=rule.get("guidance") or rule.get("description") or "(説明なし)",
        examples=ex_txt)
    return base


def _extract_exfmt_variant_key(change):
    text = change.get("occ_text", "")
    m = _EXFMT_TOKEN_RE.search(text)
    return m.group(1) if m else None


def _build_skill_variants(rule, changes):
    """必要时把单条规则拆成多个更窄的 skill。"""
    rid = str(rule["id"])
    if rid != "4.7.6":
        return [_build_skill(rule, "llm", changes)]

    groups = {}
    for ch in changes:
        key = _extract_exfmt_variant_key(ch) or "GENERIC"
        groups.setdefault(key, []).append(ch)

    skills = []
    for key, bucket in sorted(groups.items()):
        sk = _build_skill(rule, "llm", bucket)
        sk["id"] = f"{rid}__{key}"
        sk["variant_of"] = rid
        sk["variant_key"] = key
        sk["title"] = f"{rule.get('title')} [{key}]"
        sk["detect"] = dict(rule["detect"])
        sk["detect"]["pattern"] = rf"命令\[EXFMT\].*{re.escape(key)}"
        skills.append(sk)
    return skills


def run(cfg):
    rules = load_rules(cfg.path("rules_dir"))
    skills_dir = cfg.path("skills_dir")

    pairs = []
    for hp in skillmod.iter_half_java(cfg):
        hu = skillmod.human_path(cfg, hp)
        if hu.exists():
            pairs.append((hp, hu))
    if not pairs:
        print(f"[mine] 未找到(半成品,人工版)配对。human_dir={cfg.path('human_dir')}")
        return

    per_rule = {r["id"]: {"rule": r, "changes": []} for r in rules}
    for hp, hu in pairs:
        half = JavaText.load(hp, cfg.encoding)
        human = JavaText.load(hu, cfg.encoding)
        ops = difflib.SequenceMatcher(a=half.lines, b=human.lines, autojunk=False).get_opcodes()
        for r in rules:
            for occ in detect_rule(r, half.lines):
                ch = _change_from_human_annotations(r, occ, half.lines, human.lines)
                if not ch:
                    ch = _change_at(ops, half.lines, human.lines, occ["line"])
                    if ch:
                        ch["occ_text"] = occ["text"]
                if ch and ch["before"] != ch["after"]:
                    per_rule[r["id"]]["changes"].append(ch)

    gen = 0
    for rid, info in per_rule.items():
        r, changes = info["rule"], info["changes"]
        if not changes:
            print(f"[mine] {rid}: 人工版に変更なし → skip")
            continue
        ok = _transform_reproduces(r, changes)
        thr = cfg.get("mine", "deterministic_threshold", default=0.9)
        if ok is not None and ok / len(changes) >= thr:
            classify = "deterministic"   # transform 多数能重现人工 → 确定性(个别例外交 validate/复核)
        else:
            classify = "llm"
        _remove_existing_skill_files(skills_dir, rid)
        if classify == "llm":
            skills = _build_skill_variants(r, changes)
        else:
            skills = [_build_skill(r, classify, changes)]
        note = f"transform重现 {ok}/{len(changes)}" if ok is not None else "无transform"
        for skill in skills:
            if ok is not None:
                skill["transform_match"] = f"{ok}/{len(changes)}"
            p = skillmod.write_skill(skills_dir, skill)
            gen += 1
            label = skill.get("variant_key") or classify
            print(f"[mine] {rid}: {len(changes)}处, {note} → {label}  ⇒ {p.name}")
    print(f"\n[mine] 生成 {gen} 个 skill → {skills_dir}")
