"""report 模式：汇总 output/ 的结果，生成给客户看的 作業報告書.html + 明細.csv。
以 java 文件为中心：每个文件显示 命中规则(自動補完/AI・状態) + 人手版差分リンク + 要レビュー一覧。
单独跑，不调 LLM。

★ 扩展点：将来「単体テスト」「RPG業務ロジックテスト」等を追加する場合、
  そのモードが output/<file>/sections/*.section.html にHTML断片を書き出せば、
  本レポートのファイル別詳細に自動で取り込まれる(report 側の改修不要)。
"""
import csv
import json
import datetime
import html


def _load(p):
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


def _now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _base(rid):
    return str(rid).split("__")[0]


def _esc(x):
    return html.escape(str(x))


def _gather(out_dir):
    detect = _load(out_dir / "detect_report.json")
    validate = _load(out_dir / "validate_report.json")
    changelogs = {}
    for sub in sorted(out_dir.iterdir()):
        if sub.is_dir():
            for cl in sub.glob("*.changelog.json"):
                d = _load(cl)
                if d:
                    changelogs[d["file"]] = d
    return detect, validate, changelogs


def _file_rules(cl):
    """该文件命中的规则 → 每条规则的 種別(自動補完/AI) + 状態。变体折叠到基础规则。"""
    by = {}
    for x in cl.get("deterministic", []):
        by.setdefault(_base(x.get("rule_id")), {"type": "自動補完(定型)", "status": "完了"})
    for x in cl.get("llm", []):
        r = by.setdefault(_base(x.get("rule_id")), {"type": "AI補完", "status": "完了"})
        r["type"] = "AI補完"
        if x.get("needs_review"):
            r["status"] = "要レビュー"
    for x in cl.get("skipped", []):
        r = by.setdefault(_base(x.get("rule_id")), {"type": "-", "status": "要レビュー(未処理)"})
        r["status"] = "要レビュー(未処理)"
    return [{"id": k, **v} for k, v in sorted(by.items())]


def _extra_sections(out_dir, stem):
    """扩展点：取 output/<stem>/sections/*.section.html 断片(将来のテスト結果等)。"""
    secs = []
    d = out_dir / stem / "sections"
    if d.exists():
        for p in sorted(d.glob("*.section.html")):
            secs.append(p.read_text(encoding="utf-8"))
    return secs


_CSS = """
body{font-family:'Hiragino Kaku Gothic ProN','Meiryo',sans-serif;margin:24px;color:#1a1a1a}
h1{font-size:20px} h2{font-size:16px;border-left:4px solid #2563eb;padding-left:8px;margin-top:28px}
h3{font-size:14px;margin-top:20px;background:#f1f5f9;padding:6px 8px;border-radius:4px}
table{border-collapse:collapse;width:100%;margin:8px 0;font-size:13px}
th,td{border:1px solid #d0d0d0;padding:5px 8px;text-align:left}
th{background:#eef2ff} td.num{text-align:right}
.review{background:#fff7ed}
.note{background:#f8fafc;border:1px solid #e2e8f0;padding:10px;border-radius:6px;font-size:13px}
a{color:#2563eb}
"""


def _html(detect, validate, changelogs, out_dir):
    vmap = {x["file"]: x for x in (validate or {}).get("files", [])}
    L = ["<!DOCTYPE html><html lang='ja'><head><meta charset='utf-8'>",
         f"<title>RPG→Java 手動補完 作業報告書</title><style>{_CSS}</style></head><body>"]
    L.append("<h1>RPG→Java 手動補完　作業報告書</h1>")
    L.append(f"<p>生成日時: {_now()}　/　対象ファイル数: {len(changelogs)}</p>")

    # ===== ファイル別詳細 =====
    L.append("<h2>1. ファイル別詳細</h2>")
    L.append("<p style='font-size:12px;color:#555'>種別: 自動補完(定型)=定型ルールでPythonが機械補完(人手版と一致確認済) / "
             "AI補完=AIが判断して補完(要人手確認)</p>")
    for fname, cl in changelogs.items():
        stem = fname[:-5] if fname.endswith(".java") else fname
        mr = vmap.get(fname, {}).get("match_rate")
        mr_txt = f"（人手版一致率 {mr}%）" if mr is not None else ""
        L.append(f"<h3>{_esc(fname)} {mr_txt}</h3>")

        rules = _file_rules(cl)
        L.append("<table><tr><th>ヒットしたルール</th><th>種別</th><th>状態</th></tr>")
        if rules:
            for r in rules:
                cls = " class='review'" if r["status"] != "完了" else ""
                L.append(f"<tr{cls}><td>{_esc(r['id'])}</td><td>{_esc(r['type'])}</td>"
                         f"<td>{_esc(r['status'])}</td></tr>")
        else:
            L.append("<tr><td colspan='3'>ヒットなし</td></tr>")
        L.append("</table>")

        # 差分リンク
        links = [f"<a href='{_esc(stem)}/diff_vs_original.html'>変換前との差分</a>"]
        if (out_dir / stem / "diff_vs_human.html").exists():
            links.append(f"<a href='{_esc(stem)}/diff_vs_human.html'>人手版との差分</a>")
        L.append("<p>差分: " + " ｜ ".join(links) + "</p>")

        # 扩展点: 将来のテスト結果等
        for sec in _extra_sections(out_dir, stem):
            L.append(sec)

    # ===== 要レビュー一覧 =====
    L.append("<h2>2. 要レビュー一覧（人手確認が必要な箇所）</h2>"
             "<table><tr><th>ファイル</th><th>行</th><th>ルール</th><th>信頼度</th><th>理由</th></tr>")
    cnt = 0
    for fname, cl in changelogs.items():
        for x in cl.get("llm", []):
            if x.get("needs_review"):
                cnt += 1
                L.append(f"<tr class='review'><td>{_esc(fname)}</td><td class='num'>{x.get('line','')}</td>"
                         f"<td>{_esc(x.get('rule_id',''))}</td><td class='num'>{x.get('confidence','')}</td>"
                         f"<td>{_esc(x.get('reason',''))}</td></tr>")
        for x in cl.get("skipped", []):
            cnt += 1
            L.append(f"<tr class='review'><td>{_esc(fname)}</td><td class='num'>{x.get('line','')}</td>"
                     f"<td>{_esc(x.get('rule_id',''))}</td><td>-</td><td>{_esc(x.get('reason',''))}</td></tr>")
    if not cnt:
        L.append("<tr><td colspan='5'>なし</td></tr>")
    L.append("</table>")

    # ===== 注記 =====
    L.append("<h2>3. 注記</h2><div class='note'>"
             "・「自動補完(定型)」は Python の定型処理で、人手版と一致することを確認済み。<br>"
             "・「AI補完」のうち「要レビュー」は AI が下書きした箇所で、人手確認が必要。<br>"
             "・各ファイルの差分は上記リンク(diff_vs_original / diff_vs_human)を参照。"
             "</div></body></html>")
    return "\n".join(L)


def _csv_rows(changelogs):
    rows = []
    for fname, cl in changelogs.items():
        for x in cl.get("deterministic", []):
            rows.append([fname, x.get("line", ""), x.get("rule_id", ""), "自動補完(定型)",
                         "", "", x.get("type", "")])
        for x in cl.get("llm", []):
            rows.append([fname, x.get("line", ""), x.get("rule_id", ""), "AI補完",
                         x.get("confidence", ""), "要" if x.get("needs_review") else "",
                         (x.get("reason") or "")])
        for x in cl.get("skipped", []):
            rows.append([fname, x.get("line", ""), x.get("rule_id", ""), "未処理/スキップ",
                         "", "要", (x.get("reason") or "")])
    return rows


def run(cfg):
    out_dir = cfg.path("output_dir")
    detect, validate, changelogs = _gather(out_dir)
    if not changelogs:
        print("[report] output/ に補完結果がありません。先に complete を実行。")
        return

    (out_dir / "作業報告書.html").write_text(
        _html(detect, validate, changelogs, out_dir), encoding="utf-8")
    with open(out_dir / "明細.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["ファイル", "行", "ルールID", "区分", "信頼度", "要レビュー", "理由/内容"])
        w.writerows(_csv_rows(changelogs))

    review = sum(sum(1 for x in cl.get("llm", []) if x.get("needs_review")) + len(cl.get("skipped", []))
                 for cl in changelogs.values())
    print(f"[report] HTML: {out_dir/'作業報告書.html'}")
    print(f"[report] CSV : {out_dir/'明細.csv'}")
    print(f"[report] {len(changelogs)} ファイル / 要レビュー {review} 件")
