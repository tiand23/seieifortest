"""extract 模式：把 rules_src/*.md 的设计书原文，用 LLM 抽成 rules/*.yaml。

这是一次性预处理(对应客户环境 MCP 抽取的本地替代):
  设计书原文(意味/対応方法/対応例) → LLM 结构化 → rules/<id>.yaml
产物是"草稿",需人工过目修正(尤其 detect 正则);引擎只读 rules/*.yaml。
"""
import re
import yaml

from ..llm_client import LLMClient

_PROMPT = """\
あなたはRPG→Java移行の「変換規則設計書」を構造化するアシスタントです。
与えられた規則原文(意味/対応方法/対応例など)から、次のJSONだけを出力してください。

{
 "id": "規則番号(例 4.7.6)",
 "title": "規則タイトル",
 "description": "意味と対応方法の要約(1-2文,日本語)",
 "detect": {
   "method": "marker または pattern",
   "marker_kinds": ["TODO"],
   "pattern": "正規表現"
 },
 "classify": "deterministic または llm",
 "transform": {"type": "comment_out_block または regex_replace"},
 "guidance": "LLMへの指示(classify=llm時。対応方法を具体的に)",
 "examples": [ {"before": ["行..."], "after": ["行..."]} ]
}

ルール:
- detect.pattern は原文のマーカー(命令[XXX]/キーワード[XXX]等)から作る。正規表現特殊文字はエスケープ(例: 命令\\\\[EXFMT\\\\])。
- 命令/キーワードは通常 TODO 行にあるので marker_kinds は ["TODO"]。
- classify: 対応方法が単純な定型(コメントアウト/単純置換)なら deterministic、判断や新ロジックが要るなら llm(推測でよい。後段mineが実データで再判定する)。
- transform は deterministic の時のみ。コメントアウト系は comment_out_block。該当しなければ省略。
- examples は対応例の【ツール変換後のソースコード】→【修正方法】を行配列で忠実に。無ければ []。
- JSON以外は出力しない。
"""


def _src_files(cfg):
    src = cfg.path("rules_src_dir")
    if not src.exists():
        return []
    return [p for p in sorted(src.glob("*.md")) if p.name.lower() != "readme.md"]


def _pattern_ok(pattern, data, raw):
    """自校验: 正则合法, 且能匹配该规则自己的"対応例"标记行(无例子则退回匹配原文)。"""
    if not pattern:
        return False, "detect.pattern が空。"
    try:
        rx = re.compile(pattern)
    except re.error as e:
        return False, f"正規表現が不正: {e}"
    ex_lines = []
    for ex in data.get("examples") or []:
        ex_lines += [l for l in (ex.get("before") or []) if "TODO" in l or "FIXME" in l]
    if ex_lines:
        if any(rx.search(l) for l in ex_lines):
            return True, ""
        return False, f"pattern が対応例のマーカー行に一致しない。例: {ex_lines[0][:80]}"
    # 例子なし(RECNO等): 原文のどこかに当たればOK
    return (bool(rx.search(raw)), "" if rx.search(raw) else "pattern が原文に一致しない。")


def _extract_one(client, raw, rid, max_retries):
    """抽取 + 自校验 + 限次重试。返回 (data, verified, problem)。"""
    feedback = None
    data = {}
    for _ in range(max_retries + 1):
        user = raw if not feedback else (
            raw + f"\n\n# 前回出力の問題\n{feedback}\ndetect.pattern を修正して全JSONを再出力すること。")
        data = client.chat(_PROMPT, user, json_mode=True)
        pat = (data.get("detect") or {}).get("pattern")
        ok, why = _pattern_ok(pat, data, raw)
        if ok:
            return data, True, None
        feedback = why
    return data, False, feedback


def run(cfg, out_dir=None):
    client = LLMClient(cfg)
    rules_dir = out_dir or cfg.path("rules_dir")
    rules_dir.mkdir(parents=True, exist_ok=True)
    max_retries = cfg.get("complete", "llm_retry", "max_retries", default=2)
    files = _src_files(cfg)
    if not files:
        print(f"[extract] rules_src 无原文: {cfg.path('rules_src_dir')}")
        return

    unverified = []
    for p in files:
        raw = p.read_text(encoding="utf-8")
        rid = p.stem  # ★ id 取自文件名(权威), 不靠 LLM 读文本
        try:
            data, verified, problem = _extract_one(client, raw, rid, max_retries)
        except Exception as ex:
            print(f"[extract] {p.name} LLM失败: {ex}")
            continue
        rule = {"id": rid, "title": data.get("title"),
                "description": data.get("description"),
                "detect": data.get("detect") or {},
                "classify": data.get("classify") or "llm"}
        if data.get("transform"):
            rule["transform"] = data["transform"]
        if data.get("guidance"):
            rule["guidance"] = data["guidance"]
        rule["examples"] = data.get("examples") or []

        head = (f"# 由 extract 从 rules_src/{p.name} 自动抽取\n"
                f"# detect 自校验: {'通过' if verified else '未通过 → ' + str(problem)}\n")
        out = rules_dir / (rid.replace(".", "_") + ".yaml")
        out.write_text(head + yaml.safe_dump(rule, allow_unicode=True, sort_keys=False),
                       encoding="utf-8")
        flag = "✓" if verified else "✗自校验未过"
        print(f"[extract] {p.name} → {out.name}  id={rid} classify={rule['classify']} "
              f"examples={len(rule['examples'])}  {flag}")
        if not verified:
            unverified.append(rid)

    print(f"\n[extract] 完成 {len(files)} 条。")
    if unverified:
        print(f"[extract] ⚠ 仅这 {len(unverified)} 条 detect 自校验未过, 需看一眼: {unverified}")
    else:
        print("[extract] 全部 detect 自校验通过。classify/examples 由后续 mine 用真实 diff 再校准。")
