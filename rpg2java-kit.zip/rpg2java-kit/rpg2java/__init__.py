"""rpg2java-kit 通用引擎。规则即数据，引擎不变。"""
__version__ = "0.1.0"
