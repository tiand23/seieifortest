"""配置加载。所有路径都相对于 kit 根目录解析，跨平台。
支持 .env 文件 + config 内 ${ENV_VAR} 替换(密钥不落 config.yaml)。"""
import os
import re
import pathlib
import yaml

KIT_ROOT = pathlib.Path(__file__).resolve().parent.parent
_ENV_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


def _load_dotenv(path):
    """极简 .env 加载(无依赖)。已存在的环境变量不覆盖。"""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def _expand(obj):
    """递归把字符串里的 ${VAR} 替换成环境变量值。"""
    if isinstance(obj, dict):
        return {k: _expand(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_expand(v) for v in obj]
    if isinstance(obj, str):
        return _ENV_RE.sub(lambda m: os.environ.get(m.group(1), m.group(0)), obj)
    return obj


class Config:
    def __init__(self, data: dict):
        self._d = data

    @classmethod
    def load(cls, path=None):
        _load_dotenv(KIT_ROOT / ".env")
        p = pathlib.Path(path) if path else (KIT_ROOT / "config.yaml")
        with open(p, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        return cls(_expand(data))

    def get(self, *keys, default=None):
        d = self._d
        for k in keys:
            if not isinstance(d, dict) or k not in d:
                return default
            d = d[k]
        return d

    def path(self, name) -> pathlib.Path:
        """把 paths.<name> 解析成绝对路径(相对 kit 根)。"""
        rel = self.get("paths", name, default=name)
        p = pathlib.Path(rel)
        return p if p.is_absolute() else (KIT_ROOT / p)

    @property
    def encoding(self):
        return self.get("encoding", default="auto")
