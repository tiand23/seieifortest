"""diff / 归一化 / 聚类 —— mine 与 validate 共用。

- normalize: 把变量名、字符串字面量、数字替换成占位符，用于判断"形状是否一致"。
- region_diff: 两段代码的行级 diff。
- cluster_shapes: 把多个 diff 按归一化后的形状聚类。
"""
import re
import difflib

_STR = re.compile(r'"(?:[^"\\]|\\.)*"')
_NUM = re.compile(r"\b\d+\b")
_IDENT = re.compile(r"\b[a-z][A-Za-z0-9_]*\b")


def normalize(code: str) -> str:
    """把字面量/标识符抽象成占位符，得到'形状'。"""
    code = _STR.sub("§S§", code)
    code = _NUM.sub("§N§", code)
    code = _IDENT.sub("§ID§", code)
    code = re.sub(r"\s+", " ", code).strip()
    return code


def region_diff(before_lines, after_lines):
    """返回统一 diff 文本(用于人看)与变更行(用于聚类)。"""
    diff = list(difflib.unified_diff(before_lines, after_lines, lineterm="", n=1))
    added = [l[1:] for l in diff if l.startswith("+") and not l.startswith("+++")]
    removed = [l[1:] for l in diff if l.startswith("-") and not l.startswith("---")]
    return {"diff_text": "\n".join(diff), "added": added, "removed": removed}


def shape_of(diff):
    """一个 diff 的归一化形状签名。"""
    rm = " | ".join(normalize(x) for x in diff["removed"])
    ad = " | ".join(normalize(x) for x in diff["added"])
    return f"-[{rm}] +[{ad}]"


def cluster_shapes(diffs):
    """把多个 diff 按形状聚类。返回 {shape: [diff,...]}。"""
    clusters = {}
    for d in diffs:
        clusters.setdefault(shape_of(d), []).append(d)
    return clusters


def equal_ignoring_format(a: str, b: str) -> bool:
    """忽略空白/格式后是否相同(validate 的'等价差异'初判)。"""
    return re.sub(r"\s+", "", a) == re.sub(r"\s+", "", b)
