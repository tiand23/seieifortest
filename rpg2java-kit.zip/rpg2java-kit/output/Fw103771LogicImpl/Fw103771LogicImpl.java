package jp.mufg.tr.cats.os.os771.fw103771.logic;

import jp.co.kobelcosys.ctd.common.batch.constants.SelectSqlPattern;
import java.math.BigDecimal;
import java.util.Arrays;
import jp.co.kobelcosys.ctd.common.utils.Utils;
import java.nio.charset.Charset;
import java.time.format.DateTimeFormatter;
import java.time.LocalTime;
import org.apache.commons.lang3.StringUtils;
import jp.co.kobelcosys.ctd.common.vo.Indicator;
import jp.co.kobelcosys.ctd.common.da.OffsetControl;
import java.math.RoundingMode;
import jp.mufg.tr.cats.os.os771.os771d.dto.Os771dViewDTO;
import jp.mufg.tr.cats.table.fgfll1.entity.Fgfll1;
import jp.mufg.tr.cats.table.fgfll1.dao.Fgfll1DAO;
import jp.mufg.tr.cats.table.cyfile.entity.Cyfile;
import jp.mufg.tr.cats.table.cyfile.dao.CyfileDAO;
import jp.mufg.tr.cats.table.cyfll1.entity.Cyfll1;
import jp.mufg.tr.cats.table.cyfll1.dao.Cyfll1DAO;
import jp.mufg.tr.cats.table.acfile.entity.Acfile;
import jp.mufg.tr.cats.table.acfile.dao.AcfileDAO;
import jp.mufg.tr.cats.table.extnl1.entity.Extnl1;
import jp.mufg.tr.cats.table.extnl1.dao.Extnl1DAO;
import jp.mufg.tr.cats.table.cmfile.entity.Cmfile;
import jp.mufg.tr.cats.table.cmfile.dao.CmfileDAO;
import jp.mufg.tr.cats.table.amfile.entity.Amfile;
import jp.mufg.tr.cats.table.amfile.dao.AmfileDAO;
import jp.mufg.tr.cats.table.refnl4.entity.Refnl4;
import jp.mufg.tr.cats.table.refnl4.dao.Refnl4DAO;
import jp.mufg.tr.cats.table.cdfile.entity.Cdfile;
import jp.mufg.tr.cats.table.cdfile.dao.CdfileDAO;
import jp.mufg.tr.cats.table.cofile.entity.Cofile;
import jp.mufg.tr.cats.table.cofile.dao.CofileDAO;
import jp.mufg.tr.cats.table.tatable.entity.Tatable;
import jp.mufg.tr.cats.table.tatable.dao.TatableDAO;
import jp.mufg.tr.cats.table.tafll1.entity.Tafll1;
import jp.mufg.tr.cats.table.tafll1.dao.Tafll1DAO;
import jp.mufg.tr.cats.table.refnl2.entity.Refnl2;
import jp.mufg.tr.cats.table.refnl2.dao.Refnl2DAO;
import jp.mufg.tr.cats.table.clfile.entity.Clfile;
import jp.mufg.tr.cats.table.clfile.dao.ClfileDAO;
import jp.mufg.tr.cats.table.nufile.entity.Nufile;
import jp.mufg.tr.cats.table.nufile.dao.NufileDAO;
import jp.mufg.tr.cats.table.dmfll3.entity.Dmfll3;
import jp.mufg.tr.cats.table.dmfll3.dao.Dmfll3DAO;
import jp.mufg.tr.cats.table.ttfile.entity.Ttfile;
import jp.mufg.tr.cats.table.ttfile.dao.TtfileDAO;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ttara1;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ttara2;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Parm0;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Parm09;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Parm10;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Parma5;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds001;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds002;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds003;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds004;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds005;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds006;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds007;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds008;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds009;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds010;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds011;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds012;
import jp.mufg.tr.cats.os.os771.fw103771.ds.Ds013;
import jp.mufg.tr.cats.os.os771.fw103771.ds._102301;
import jp.mufg.tr.cats.os.os771.fw103771.ds._102401;
import jp.mufg.tr.cats.os.os771.fw103771.ds._110201;
import jp.mufg.tr.cats.os.os771.fw103771.ds._110501;
import jp.mufg.tr.cats.os.os771.fw103771.ds._110801;
import jp.mufg.tr.cats.os.os771.fw103771.ds._111101;
import jp.mufg.tr.cats.os.os771.fw103771.ds._115701;
import jp.mufg.tr.cats.os.os771.fw103771.ds._117701;
import jp.mufg.tr.cats.os.os771.fw103771.ds._117702;
import jp.mufg.tr.cats.os.os771.fw103771.ds._117703;
import jp.mufg.tr.cats.os.os771.fw103771.ds._1177a1;
import jp.mufg.tr.cats.common.fw102002.vo.Fw102002VO;
import jp.mufg.tr.cats.common.fw102002.service.Fw102002Service;
import jp.mufg.tr.cats.common.fw102003.vo.Fw102003VO;
import jp.mufg.tr.cats.common.fw102003.service.Fw102003Service;
import jp.mufg.tr.cats.common.fw102211.vo.Fw102211VO;
import jp.mufg.tr.cats.common.fw102211.service.Fw102211Service;
import jp.mufg.tr.cats.qcmdexc.service.QcmdexcService;
import jp.mufg.tr.cats.os.os771.fw103771.vo.Fw103771VO;
import jp.co.kobelcosys.ctd.common.vo.Indicator;
import jp.mufg.tr.cats.os.os771.fw103771.dto.Fw103771LogicDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

/**
 * FW103771 ロジック.
 **/
@Service
@Scope("prototype")
public class Fw103771LogicImpl implements Fw103771Logic {
    /** 標識. */
    private Indicator indicator = new Indicator();
    /** 画面初期化フラグ. */
    private boolean ctlDispFlag = false;
    /** LogicDTO. */
    @Autowired
    private Fw103771LogicDTO logicDTO;
    /** 画面VO */
    private Os771dViewDTO dto;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0004.00:FFGFLL1    IF   E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** fgfll1 */
    private Fgfll1 fgfll1 = new Fgfll1();
    /** fgfll1Key */
    private Fgfll1 fgfll1Key = new Fgfll1();
    /** fgfll1Temp */
    private Fgfll1 fgfll1Temp = new Fgfll1();
    /** offsetCtlFgfll1 */
    private OffsetControl offsetCtlFgfll1 = new OffsetControl();
    /** FGFLL1 DAO */
    @Autowired
    private Fgfll1DAO fgfll1DAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0005.00:FCYFILE    IF   E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** cyfile */
    private Cyfile cyfile = new Cyfile();
    /** cyfileKey */
    private Cyfile cyfileKey = new Cyfile();
    /** cyfileTemp */
    private Cyfile cyfileTemp = new Cyfile();
    /** offsetCtlCyfile */
    private OffsetControl offsetCtlCyfile = new OffsetControl();
//ndz-del-s
//    /** CYFILE DAO */
//    @Autowired
//    private CyfileDAO cyfileDAO;
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0006.00:FCYFLL1    IF   E           K DISK
//    //                                  0007.00:F                                     RENAME(CYRECD:CYRECDA)
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** cyfll1 */
    private Cyfll1 cyfll1 = new Cyfll1();
    /** cyfll1Key */
    private Cyfll1 cyfll1Key = new Cyfll1();
    /** cyfll1Temp */
    private Cyfll1 cyfll1Temp = new Cyfll1();
    /** offsetCtlCyfll1 */
    private OffsetControl offsetCtlCyfll1 = new OffsetControl();
    /** CYFLL1 DAO */
    @Autowired
    private Cyfll1DAO cyfll1DAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0008.00:FACFILE    IF   E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** acfile */
    private Acfile acfile = new Acfile();
    /** acfileKey */
    private Acfile acfileKey = new Acfile();
    /** acfileTemp */
    private Acfile acfileTemp = new Acfile();
    /** offsetCtlAcfile */
    private OffsetControl offsetCtlAcfile = new OffsetControl();
    /** ACFILE DAO */
    @Autowired
    private AcfileDAO acfileDAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0009.00:FEXTNL1    IF   E           K DISK
//    //                                  0010.00:F                                     RENAME(ACRECD:ACRECDB)
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** extnl1 */
    private Extnl1 extnl1 = new Extnl1();
    /** extnl1Key */
    private Extnl1 extnl1Key = new Extnl1();
    /** extnl1Temp */
    private Extnl1 extnl1Temp = new Extnl1();
    /** offsetCtlExtnl1 */
    private OffsetControl offsetCtlExtnl1 = new OffsetControl();
    /** EXTNL1 DAO */
    @Autowired
    private Extnl1DAO extnl1DAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0011.00:FCMFILE    IF   E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** cmfile */
    private Cmfile cmfile = new Cmfile();
    /** cmfileKey */
    private Cmfile cmfileKey = new Cmfile();
    /** cmfileTemp */
    private Cmfile cmfileTemp = new Cmfile();
    /** offsetCtlCmfile */
    private OffsetControl offsetCtlCmfile = new OffsetControl();
    /** CMFILE DAO */
    @Autowired
    private CmfileDAO cmfileDAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0012.00:FAMFILE    IF   E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** amfile */
    private Amfile amfile = new Amfile();
    /** amfileKey */
    private Amfile amfileKey = new Amfile();
    /** amfileTemp */
    private Amfile amfileTemp = new Amfile();
    /** offsetCtlAmfile */
    private OffsetControl offsetCtlAmfile = new OffsetControl();
    /** AMFILE DAO */
    @Autowired
    private AmfileDAO amfileDAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0013.00:FREFNL4    IF   E           K DISK
//    //                                  0014.00:F                                     RENAME(AMRECD:AMRECDA)
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** refnl4 */
    private Refnl4 refnl4 = new Refnl4();
    /** refnl4Key */
    private Refnl4 refnl4Key = new Refnl4();
    /** refnl4Temp */
    private Refnl4 refnl4Temp = new Refnl4();
    /** offsetCtlRefnl4 */
    private OffsetControl offsetCtlRefnl4 = new OffsetControl();
    /** REFNL4 DAO */
    @Autowired
    private Refnl4DAO refnl4DAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0015.00:FCDFILE    IF   E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** cdfile */
    private Cdfile cdfile = new Cdfile();
    /** cdfileKey */
    private Cdfile cdfileKey = new Cdfile();
    /** cdfileTemp */
    private Cdfile cdfileTemp = new Cdfile();
    /** offsetCtlCdfile */
    private OffsetControl offsetCtlCdfile = new OffsetControl();
    /** CDFILE DAO */
    @Autowired
    private CdfileDAO cdfileDAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0016.00:FCOFILE    IF   E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** cofile */
    private Cofile cofile = new Cofile();
    /** cofileKey */
    private Cofile cofileKey = new Cofile();
    /** cofileTemp */
    private Cofile cofileTemp = new Cofile();
    /** offsetCtlCofile */
    private OffsetControl offsetCtlCofile = new OffsetControl();
    /** COFILE DAO */
    @Autowired
    private CofileDAO cofileDAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0017.00:FTATABLE   IF   E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** tatable */
    private Tatable tatable = new Tatable();
    /** tatableKey */
    private Tatable tatableKey = new Tatable();
    /** tatableTemp */
    private Tatable tatableTemp = new Tatable();
    /** offsetCtlTatable */
    private OffsetControl offsetCtlTatable = new OffsetControl();
    /** TATABLE DAO */
    @Autowired
    private TatableDAO tatableDAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0018.00:FTAFLL1    IF   E           K DISK
//    //                                  0019.00:F                                     RENAME(TATABLER:TARECDA)
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** tafll1 */
    private Tafll1 tafll1 = new Tafll1();
    /** tafll1Key */
    private Tafll1 tafll1Key = new Tafll1();
    /** tafll1Temp */
    private Tafll1 tafll1Temp = new Tafll1();
    /** offsetCtlTafll1 */
    private OffsetControl offsetCtlTafll1 = new OffsetControl();
    /** TAFLL1 DAO */
    @Autowired
    private Tafll1DAO tafll1DAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0020.00:FREFNL2    IF   E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** refnl2 */
    private Refnl2 refnl2 = new Refnl2();
    /** refnl2Key */
    private Refnl2 refnl2Key = new Refnl2();
    /** refnl2Temp */
    private Refnl2 refnl2Temp = new Refnl2();
    /** offsetCtlRefnl2 */
    private OffsetControl offsetCtlRefnl2 = new OffsetControl();
    /** REFNL2 DAO */
    @Autowired
    private Refnl2DAO refnl2DAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[RECNO] original-code : 0021.00:FCLFILE    UF   E             DISK
//    //                                  0022.00:F                                     RECNO(RRNCL)
//    // FIXME キーワード[RECNO] はツール未対応です
//ndz-del-e
    /** clfile */
    private Clfile clfile = new Clfile();
    /** clfileKey */
    private Clfile clfileKey = new Clfile();
    /** clfileTemp */
    private Clfile clfileTemp = new Clfile();
    /** offsetCtlClfile */
    private OffsetControl offsetCtlClfile = new OffsetControl();
    /** CLFILE DAO */
    @Autowired
    private ClfileDAO clfileDAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0023.00:FNUFILE    UF A E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** nufile */
    private Nufile nufile = new Nufile();
    /** nufileKey */
    private Nufile nufileKey = new Nufile();
    /** nufileTemp */
    private Nufile nufileTemp = new Nufile();
    /** offsetCtlNufile */
    private OffsetControl offsetCtlNufile = new OffsetControl();
    /** NUFILE DAO */
    @Autowired
    private NufileDAO nufileDAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0024.00:FDMFLL3    IF   E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** dmfll3 */
    private Dmfll3 dmfll3 = new Dmfll3();
    /** dmfll3Key */
    private Dmfll3 dmfll3Key = new Dmfll3();
    /** dmfll3Temp */
    private Dmfll3 dmfll3Temp = new Dmfll3();
    /** offsetCtlDmfll3 */
    private OffsetControl offsetCtlDmfll3 = new OffsetControl();
    /** DMFLL3 DAO */
    @Autowired
    private Dmfll3DAO dmfll3DAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0025.00:FTTFILE    O  A E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** ttfile */
    private Ttfile ttfile = new Ttfile();
    /** ttfileKey */
    private Ttfile ttfileKey = new Ttfile();
    /** ttfileTemp */
    private Ttfile ttfileTemp = new Ttfile();
    /** offsetCtlTtfile */
    private OffsetControl offsetCtlTtfile = new OffsetControl();
    /** TTFILE DAO */
    @Autowired
    private TtfileDAO ttfileDAO;
    /** CNSNUM1 */
    private final String CNSNUM1 = "0123456789";
    /** CNSNUM2 */
    private final String CNSNUM2 = "0123456789ABCDEFGHIJKLMNOPQR";
    /** _1177ar */
    private String[] _1177ar = new String[] { "", "SNDBRKMSG MSG('ERROR: OP.NO ARRIVED AT MAXMUM IN THIS TERMINAL.  ') TOMSGQ(WXX) ", "SNDBRKMSG MSG('CAUTION: STOP OS INPUT FROM THIS TERMINAL TODAY   ') TOMSGQ(WXX) " };
    /** wkrefn */
    private Long wkrefn = 0L;
    /** wkusn1 */
    private Integer wkusn1 = 0;
    /** wkusn2 */
    private Integer wkusn2 = 0;
    /** wkstat */
    private String wkstat = "";
    /** wkflg1 */
    private String wkflg1 = "";
    /** wkflg2 */
    private String wkflg2 = "";
    /** wkflg3 */
    private String wkflg3 = "";
    /** wkcode */
    private Integer wkcode = 0;
    /** wksupp */
    private Integer wksupp = 0;
    /** wkvldt */
    private Integer wkvldt = 0;
    /** wkfenm */
    private String wkfenm = "";
    /** wkfefg */
    private String wkfefg = "";
    /** wkcdf3 */
    private String wkcdf3 = "";
    /** wkfcfm */
    private Integer wkfcfm = 0;
    /** wkfcto */
    private Integer wkfcto = 0;
    /** wkact3 */
    private Integer wkact3 = 0;
    /** wkfacc */
    private Integer wkfacc = 0;
    /** wkfacn */
    private String wkfacn = "";
    /** wkdrcr */
    private String wkdrcr = "";
    /** wkac05 */
    private String wkac05 = "";
    /** wkac25 */
    private String wkac25 = "";
    /** wkot61 */
    private String wkot61 = "";
    /** wktacd */
    private Integer wktacd = 0;
    /** wka3ac */
    private Integer wka3ac = 0;
    /** wkb3ac */
    private Integer wkb3ac = 0;
    /** wkc3ac */
    private Integer wkc3ac = 0;
    /** wkd3ac */
    private Integer wkd3ac = 0;
    /** wke4ac */
    private Integer wke4ac = 0;
    /** wkf4ac */
    private Integer wkf4ac = 0;
    /** wknfg1 */
    private String wknfg1 = "";
    /** wknfg2 */
    private String wknfg2 = "";
    /** wknfg3 */
    private String wknfg3 = "";
    /** wkocd4 */
    private Integer wkocd4 = 0;
    /** wkcur4 */
    private Integer wkcur4 = 0;
    /** wkexcd */
    private Integer wkexcd = 0;
    /** wkabbr */
    private String wkabbr = "";
    /** wkname */
    private String wkname = "";
    /** wkamcd */
    private String wkamcd = "";
    /** wkac07 */
    private String wkac07 = "";
    /** wkac24 */
    private String wkac24 = "";
    /** w108o1 */
    private String w108o1 = "";
    /** w108o2 */
    private String w108o2 = "";
    /** w108o3 */
    private Integer w108o3 = 0;
    /** w108o4 */
    private Integer w108o4 = 0;
    /** w108o5 */
    private Integer w108o5 = 0;
    /** w108o6 */
    private Integer w108o6 = 0;
    /** w108o7 */
    private Integer w108o7 = 0;
    /** wknsbc */
    private Integer wknsbc = 0;
    /** wknsbn */
    private String wknsbn = "";
    /** wkcust */
    private Integer wkcust = 0;
    /** wkcnm1 */
    private String wkcnm1 = "";
    /** wkcnm2 */
    private String wkcnm2 = "";
    /** wkcocd */
    private Integer wkcocd = 0;
    /** wkvatc */
    private String wkvatc = "";
    /** wkofcd */
    private String wkofcd = "";
    /** wkofnm */
    private String wkofnm = "";
    /** wkoffm */
    private Integer wkoffm = 0;
    /** wkofto */
    private Integer wkofto = 0;
    /** wkofam */
    private BigDecimal wkofam = BigDecimal.ZERO;
    /** wkofac */
    private Integer wkofac = 0;
    /** wkofan */
    private String wkofan = "";
    /** wkonos */
    private String wkonos = "";
    /** wkoncy */
    private String wkoncy = "";
    /** wkonac */
    private String wkonac = "";
    /** wkonab */
    private String wkonab = "";
    /** wkonae */
    private Integer wkonae = 0;
    /** wkonan */
    private String wkonan = "";
    /** wkonbc */
    private Integer wkonbc = 0;
    /** wkonbn */
    private String wkonbn = "";
    /** wkolrf */
    private Long wkolrf = 0L;
    /** wkoapn */
    private String wkoapn = "";
    /** wkocst */
    private Integer wkocst = 0;
    /** wkoctb */
    private String wkoctb = "";
    /** wkocn1 */
    private String wkocn1 = "";
    /** wkocn2 */
    private String wkocn2 = "";
    /** wkovat */
    private String wkovat = "";
    /** wkoarf */
    private String wkoarf = "";
    /** wkorat */
    private BigDecimal wkorat = BigDecimal.ZERO;
    /** wkospr */
    private BigDecimal wkospr = BigDecimal.ZERO;
    /** wkocc1 */
    private String wkocc1 = "";
    /** wkocc2 */
    private String wkocc2 = "";
    /** wkormk */
    private String wkormk = "";
    /** wkothe */
    private String wkothe = "";
    /** wkoflg */
    private String wkoflg = "";
    /** wkprfg */
    private String wkprfg = "";
    /** wktime */
    private Integer wktime = 0;
    /** wkcoos */
    private String wkcoos = "";
    /** _123wk1 */
    private Integer _123wk1 = 0;
    /** _124wk1 */
    private Integer _124wk1 = 0;
    /** _127ot */
    private String _127ot = "";
    /** _127in1 */
    private Long _127in1 = 0L;
    /** _127in2 */
    private Integer _127in2 = 0;
    /** _127in3 */
    private Integer _127in3 = 0;
    /** wktted */
    private Integer wktted = 0;
    /** rrncl */
    private Integer rrncl = 0;
    /** _1177a2 */
    private BigDecimal _1177a2 = BigDecimal.ZERO;
    /** wkidxmov */
    private Integer wkidxmov = 0;
    /** wkidxmov2 */
    private Integer wkidxmov2 = 0;
    /** wkidxfor1 */
    private Integer wkidxfor1 = 0;
    /** wkidxfor2 */
    private Integer wkidxfor2 = 0;
    /** wkidxfor3 */
    private Integer wkidxfor3 = 0;
    /** wkidxfor4 */
    private Integer wkidxfor4 = 0;
    /** wkidxfor5 */
    private Integer wkidxfor5 = 0;
    /** wkidxfor6 */
    private Integer wkidxfor6 = 0;
    /** wkidxfor7 */
    private Integer wkidxfor7 = 0;
    /** wkidxfor8 */
    private Integer wkidxfor8 = 0;
    /** wkidxfor9 */
    private Integer wkidxfor9 = 0;
    /** wkidxfor10 */
    private Integer wkidxfor10 = 0;
    /** wkidxfor11 */
    private Integer wkidxfor11 = 0;
    /** wkidxfor12 */
    private Integer wkidxfor12 = 0;
    /** wkidxfor13 */
    private Integer wkidxfor13 = 0;
    /** wkcatvar */
    private String wkcatvar = "";
    /** wkcatvarlen */
    private Integer wkcatvarlen = 0;
    /** wkcatblank */
    private String wkcatblank = "";
    /** ttara1 */
    private Ttara1 ttara1 = new Ttara1();
    /** ttara2 */
    private Ttara2 ttara2 = new Ttara2();
    /** parm0 */
    private Parm0 parm0 = new Parm0();
    /** parm09 */
    private Parm09 parm09 = new Parm09();
    /** parm10 */
    private Parm10 parm10 = new Parm10();
    /** parma5 */
    private Parma5 parma5 = new Parma5();
    /** ds001 */
    private Ds001 ds001 = new Ds001();
    /** ds002 */
    private Ds002 ds002 = new Ds002();
    /** ds003 */
    private Ds003 ds003 = new Ds003();
    /** ds004 */
    private Ds004 ds004 = new Ds004();
    /** ds005 */
    private Ds005 ds005 = new Ds005();
    /** ds006 */
    private Ds006 ds006 = new Ds006();
    /** ds007 */
    private Ds007 ds007 = new Ds007();
    /** ds008 */
    private Ds008 ds008 = new Ds008();
    /** ds009 */
    private Ds009 ds009 = new Ds009();
    /** ds010 */
    private Ds010 ds010 = new Ds010();
    /** ds011 */
    private Ds011 ds011 = new Ds011();
    /** ds012 */
    private Ds012 ds012 = new Ds012();
    /** ds013 */
    private Ds013 ds013 = new Ds013();
    /** _102301 */
    private _102301 _102301 = new _102301();
    /** _102401 */
    private _102401 _102401 = new _102401();
    /** _110201 */
    private _110201 _110201 = new _110201();
    /** _110501 */
    private _110501 _110501 = new _110501();
    /** _110801 */
    private _110801 _110801 = new _110801();
    /** _111101 */
    private _111101 _111101 = new _111101();
    /** _115701 */
    private _115701 _115701 = new _115701();
    /** _117701 */
    private _117701 _117701 = new _117701();
    /** _117702 */
    private _117702 _117702 = new _117702();
    /** _117703 */
    private _117703 _117703 = new _117703();
//ndz-del-s
//    /** _1177a1 */
//    private _1177a1 _1177a1 = new _1177a1();
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[DFTACTGRP] original-code : 0001.00:H DATEDIT(*MDY-)
//    // FIXME キーワード[DFTACTGRP] はツール未対応です
//ndz-del-e
    /** FW102002 パラメータVO */
    private Fw102002VO fw102002VO = new Fw102002VO();
    /** FW102002 Service */
    @Autowired
    private Fw102002Service fw102002Service;
    /** FW102003 パラメータVO */
    private Fw102003VO fw102003VO = new Fw102003VO();
    /** FW102003 Service */
    @Autowired
    private Fw102003Service fw102003Service;
    /** FW102211 パラメータVO */
    private Fw102211VO fw102211VO = new Fw102211VO();
    /** FW102211 Service */
    @Autowired
    private Fw102211Service fw102211Service;
    /** QCMDEXC Service */
    @Autowired
    private QcmdexcService qcmdexcService;
    /** FW103771 パラメータVO */
    private Fw103771VO fw103771VO = new Fw103771VO();
    private final String DATEDIT = "Unsupported(/* FIXME 定数[*MDY-] はツール未対応です */)";

    /**
     * デフォルトコンストラクタ.
     */
    public Fw103771LogicImpl() {
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void init(Os771dViewDTO dto) {
        setMemberVariables(dto);
        // TODO 手動変換の対応が必要です
        // FIXME 初期化処理をここに移行してください
                        
                        
        // 画面表示前にメンバ変数データを保持
        setLogicDTO();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void main(Os771dViewDTO dto)  {
        setMemberVariables(dto);
        _initCtlDispFlag();
                        
        // ==========================================================================================
        // End of Parmeter definitions.
        // ==========================================================================================
        // ****************************************************
        // PREPARATION  < PLIST >                   *
        // ****************************************************
        // ****************************************************
        // WORK  AREA  < DEFN >                     *
        // ****************************************************
        // ****************************************************
        // PREPARATION  < KLIST >                   *
        // ****************************************************
        // TATABLE
        // TAFLL1
        // AMFILE
        // CDFILE
        // NUFILE
        // DMFILE
        // ****************************************************
        // PROGRAM  MAIN  ROUTINE                   *
        // ****************************************************
        _2sintl();    // INIT
        indicator.setIn70(false);
        do {
            _2sint1();    // DSP INIT 1
            indicator.setIn71(false);
            do {
                // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0396.00:C                   EXFMT     OS771D1
                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
                dto.setOs771d1(true);
                exfmt();
                if (indicator.getInKC() == true) {
                    break;    // CMD3 PGM END

                }
                if (indicator.getInKA() == true) {
                    indicator.setIn71(true);    // CMD1 CLEAR

                }
                if (indicator.getIn71() == false) {
                    _2schk0();    // TR & REF CHECK

                }
                if (indicator.getIn99() == false) {
                    indicator.setIn71(true);    // NOT ERROR

                }
            }
            while (!(indicator.getIn71() == true));
            if (indicator.getInKC() == true) {
                break;    // CMD3 PGM END

            }
            if (indicator.getInKA() == false) {
                if (dto.getWstrcd().equals(60)) {
                    dto.setWstrnm("INSERT ");
                    _2str60();    // INSERT PROCESS
                } else if (dto.getWstrcd().equals(61)) {
                    dto.setWstrnm("CHANGE ");
                    _2str61();    // CHANGE PROCESS
                } else if (dto.getWstrcd().equals(62)) {
                    dto.setWstrnm("DELETE ");
                    _2str62();    // DELETE PROCESS
                } else if (dto.getWstrcd().equals(63)) {
                    dto.setWstrnm("CANCEL ");
                    _2str63();    // CANCEL PROCESS
                }

            }
        }
        while (!(indicator.getIn70() == true));
        indicator.setInLR(true);
        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[RETURN] original-code : 0427.00:C                   RETURN
        // FIXME 命令[RETURN] は手動変換が必要です



        // 画面表示前にメンバ変数データを保持
        setLogicDTO();
    }
    // ****************************************************
    // INITIAL  PROCESS                         *
    // ****************************************************
    private void _2sintl() {
        Arrays.fill(indicator.getIn(), 1, 100, false);
        clearOs771d1();
        clearOs771d2();
        clearOs771d3();
        dto.setWsbrno(Utils.evaluateNumber(3, 0, parm0.getPabrno()).intValue());    // BRNO SET
        dto.setWstody(Utils.evaluateNumber(6, 0, parm0.getPaetod()).intValue());    // DATE SET
        if (Utils.rTrim(parm0.getPaofsh()).equals(Utils.rTrim("0"))) {    // OFFSHORE CODE
            wkprfg = Utils.movel(wkprfg, 1, "0", 1);
            cdfile.setCdkey1(Utils.movel(cdfile.getCdkey1(), 3, "173", 3));
            cdfileKey = new Cdfile();
            cdfileKey.setCdkey1(cdfile.getCdkey1());
            cdfileDAO.setReadCriteria(cdfileKey, SelectSqlPattern.GE, this.getClass().getSimpleName());
            offsetCtlCdfile.offsetClear();
            while (indicator.getIn80() == false) {
                cdfileKey = new Cdfile();
                cdfileKey.setCdkey1(cdfile.getCdkey1());
                cdfileTemp = cdfileDAO.select(cdfileKey, offsetCtlCdfile.getOffsetAndIncrement(), SelectSqlPattern.EQ, this.getClass().getSimpleName());
                if (cdfileTemp == null) {
                    indicator.setIn80(true);
                } else {
                    indicator.setIn80(false);
                    cdfile = cdfileTemp;
                }
                if (indicator.getIn80() == false) {
                    if (Utils.rTrim(cdfile.getCdflg1()).equals(Utils.rTrim("T"))) {
                        wkprfg = Utils.movel(wkprfg, 1, "1", 1);
                        indicator.setIn80(true);

                    }

                }
            }
            if (Utils.rTrim(wkprfg).equals(Utils.rTrim("0"))) {
                indicator.setIn11(true);    // *PROTECT*
                dto.setWsoscd(Utils.movel(dto.getWsoscd(), 1, "0", 1));
                dto.setWsnsos(Utils.movel(dto.getWsnsos(), 1, "0", 1));

            }

        }
        if (!Utils.rTrim(parm0.getPavatc()).equals(Utils.rTrim("1"))) {    // VAT CODE
            indicator.setIn12(true);    // *PROTECT*

        }

    }

    // ****************************************************
    // DISPLAY (1)  INITIAL  PROCESS            *
    // ****************************************************
    private void _2sint1() {
        dto.setWstrcd(0);    // TR CODE CLEAR
        ds007.setWsrefn(0L);
        ds007.setWsrefn(0l);    // REF.NO  CLEAR
        wktime = new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue();    // TIME GET

    }

    // ****************************************************
    // TR & REF.NO  CHECK  ROUTINE              *
    // ****************************************************
    private void _2schk0() {
        Arrays.fill(indicator.getIn(), 20, 100, false);
        // **  < A >  TR CODE  CHECK  ***
        if (!dto.getWstrcd().equals(60) && !dto.getWstrcd().equals(61) && !dto.getWstrcd().equals(62) && !dto.getWstrcd().equals(63)) {
            if (indicator.getIn99() == false) {
                indicator.setIn61(true);

            }
            indicator.setIn21(true);    // *UOS7480*
            indicator.setIn61(true);
            indicator.setIn99(true);

        }
        // **  < B >  REF.NO CHECK   ***
        wkusn1 = 0;
        wkusn1 = 0;
        wkusn2 = 0;
        wkusn2 = 0;
        wkstat = " ";
        if (dto.getWstrcd().equals(60)) {
            if (!ds007.getWsrefn().equals(0l)) {
                if (indicator.getIn99() == false) {
                    indicator.setIn61(true);

                }
                indicator.setIn22(true);    // *UOS5401*
                indicator.setIn99(true);

            }

        }
        if (!dto.getWstrcd().equals(60)) {
            if (ds007.getWsrefn().equals(0l)) {
                if (indicator.getIn99() == false) {
                    indicator.setIn62(true);

                }
                indicator.setIn22(true);    // *UOS7709*
                indicator.setIn99(true);

            }
            fgfll1.setFgrefn(0L);
            fgfll1.setFgrefn(Utils.evaluateNumber(11, 0, ds007.getWsrefn()).longValue());
            fgfll1Key = new Fgfll1();
            fgfll1Key.setFgrefn(fgfll1.getFgrefn());
            fgfll1Temp = fgfll1DAO.selectFirstMatching(fgfll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
            offsetCtlFgfll1.offsetClear();
            if (fgfll1Temp != null) {
                indicator.setIn80(false);
                fgfll1 = fgfll1Temp;
            } else {
                indicator.setIn80(true);
            }
            if (indicator.getIn80() == true) {
                if (indicator.getIn99() == false) {
                    indicator.setIn63(true);

                }
                indicator.setIn22(true);    // *UOS6621*
                indicator.setIn99(true);
            } else {
                if (dto.getWstrcd().equals(61)) {
                    if (!Utils.rTrim(fgfll1.getFgstat()).equals(Utils.rTrim("0")) && !Utils.rTrim(fgfll1.getFgstat()).equals(Utils.rTrim("6"))) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn64(true);

                        }
                        indicator.setIn22(true);    // *UOS8632*
                        indicator.setIn99(true);

                    }

                }
                if (dto.getWstrcd().equals(62)) {
                    if (!Utils.rTrim(fgfll1.getFgstat()).equals(Utils.rTrim("0"))) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn65(true);

                        }
                        indicator.setIn22(true);    // *UOS8633*
                        indicator.setIn99(true);

                    }

                }
                if (dto.getWstrcd().equals(63)) {
                    if (!Utils.rTrim(fgfll1.getFgstat()).equals(Utils.rTrim("6"))) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn66(true);

                        }
                        indicator.setIn22(true);    // *UOS8634*
                        indicator.setIn99(true);

                    }

                }

            }

        }
        wkusn1 = 0;
        wkusn1 = Utils.evaluateNumber(7, 0, fgfll1.getFgusn1()).intValue();
        wkusn2 = 0;
        wkusn2 = Utils.evaluateNumber(5, 0, fgfll1.getFgusn2()).intValue();
        wkstat = Utils.movel(wkstat, 1, fgfll1.getFgstat(), 1);

    }

    // ****************************************************
    // INSERT  PROCESS  ROUTINE  (TR=60)        *
    // ****************************************************
    private void _2str60() {
        indicator.setIn72(false);
//ndz-del-s
//        do {
//            _2sint2();    // DSP INIT 2
//            indicator.setIn73(false);
//            do {
//                // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0570.00:C                   EXFMT     OS771D2
//                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                dto.setOs771d2(true);
//                exfmt();
//                ds003.setWkhms1(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 1
//ndz-del-e
//ndz-add-s
//ndz-del-s
//        indicator.setIn72(false);
//        do {
//            _2sint2();    // DSP INIT 2
//            indicator.setIn73(false);
//            do {
//                // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0570.00:C                   EXFMT     OS771D2
//                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                dto.setOs771d2(true);
//                exfmt();
//ndz-del-e
                ds003.setWkhms1(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 1
//ndz-del-s
//                dto.setWsactn("  ");    // OK,NO AREA
//                if (indicator.getInKC() == true) {
//                    break;    // CMD3 PGM END

//                }
//                if (indicator.getInKA() == true) {
//                    break;    // CMD1 CLEAR

//                }
//ndz-del-e
//ndz-add-e
                dto.setWsactn("  ");    // OK,NO AREA
                if (indicator.getInKC() == true) {
                    break;    // CMD3 PGM END

                }
                if (indicator.getInKA() == true) {
                    break;    // CMD1 CLEAR

                }
                _2schk1();    // ITEM CHECK 1
                if (indicator.getIn99() == false) {
                    _2schk2();    // ITEM CHECK 2

                }
                if (indicator.getIn99() == false) {
                    _2rfaut();    // REF.NO AUTO CNT

                }
                if (indicator.getIn99() == false) {
                    _2opaut();    // OP.NO AUTO CNT

                }
                if (indicator.getIn99() == false) {    // NOT ERROR
                    cdfile.setCdkey1("   ");
                    cdfile.setCdkey2("       ");
                    cdfile.setCdkey1(Utils.movel(cdfile.getCdkey1(), 3, "195", 3));
                    cdfile.setCdkey2(Utils.movel(cdfile.getCdkey2(), 7, dto.getWsfecd(), 4));
                    cdfileKey = new Cdfile();
                    cdfileKey.setCdkey1(cdfile.getCdkey1());
                    cdfileKey.setCdkey2(cdfile.getCdkey2());
                    cdfileTemp = cdfileDAO.selectFirstMatching(cdfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
                    offsetCtlCdfile.offsetClear();
                    if (cdfileTemp != null) {
                        indicator.setIn80(false);
                        cdfile = cdfileTemp;
                    } else {
                        indicator.setIn80(true);
                    }
                    if (Utils.rTrim(cdfile.getCdflg2()).equals(Utils.rTrim("1"))) {
                        indicator.setIn54(true);

                    }
                    ds004.setWkhms2(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 2
//ndz-del-s
//ndz-del-s
//                    // // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[WRITE] original-code : 0598.00:C                   WRITE     OS771D2
////ndz-del-e
//                    // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                    dto.setOs771d2(true);
//                    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0599.00:C                   EXFMT     OS771D3                                      'OK' OR 'NO'
//                    // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                    dto.setOs771d3(true);
//                    dto.setOs771d3Readonly(false);
//                    exfmt();    // 'OK' OR 'NO'
//ndz-del-e
                    if (Utils.rTrim(dto.getWsactn()).equals(Utils.rTrim("OK"))) {
                        _2ttset();    // TTFILE ITEM SET
                        _2pchk2();    // PROCESS CHECK 2
                        if (indicator.getIn99() == false) {
                            _2ttout();    // TTFILE OUTPUT

                        }
                        if (indicator.getIn99() == false) {
                            indicator.setIn73(true);    // DO LOOP END

                        }
                    } else {
                        Arrays.fill(indicator.getIn(), 20, 100, false);

                    }

                }
            }
            while (!(indicator.getIn73() == true));
            if (indicator.getInKC() == true) {
                indicator.setIn72(true);    // CMD3 PGM END

            }
        }
        while (!(indicator.getIn72() == true));

    }

    // ****************************************************
    // CHANGE  PROCESS  ROUTINE  (TR=61)        *
    // ****************************************************
    private void _2str61() {
        indicator.setIn72(false);
//ndz-del-s
//        do {
//            _2sint2();    // DSP INIT 2
//            indicator.setIn73(false);
//            do {
//                // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0633.00:C                   EXFMT     OS771D2
//                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                dto.setOs771d2(true);
//                exfmt();
//                ds003.setWkhms1(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 1
//ndz-del-e
//ndz-add-s
//ndz-del-s
//        indicator.setIn72(false);
//        do {
//            _2sint2();    // DSP INIT 2
//            indicator.setIn73(false);
//            do {
//                // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0633.00:C                   EXFMT     OS771D2
//                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                dto.setOs771d2(true);
//                exfmt();
//ndz-del-e
                ds003.setWkhms1(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 1
//ndz-del-s
//                dto.setWsactn("  ");    // OK,NO AREA
//                if (indicator.getInKC() == true) {
//                    break;    // CMD3 PGM END

//                }
//                if (indicator.getInKA() == true) {
//                    break;    // CMD1 CLEAR

//                }
//ndz-del-e
//ndz-add-e
                dto.setWsactn("  ");    // OK,NO AREA
                if (indicator.getInKC() == true) {
                    break;    // CMD3 PGM END

                }
                if (indicator.getInKA() == true) {
                    break;    // CMD1 CLEAR

                }
                _2schk1();    // ITEM CHECK 1
                if (indicator.getIn99() == false) {
                    _2schk2();    // ITEM CHECK 2

                }
                if (indicator.getIn99() == false) {
                    _2opaut();    // OP.NO AUTO CNT

                }
                if (indicator.getIn99() == false) {    // NOT ERROR
                    cdfile.setCdkey1("   ");
                    cdfile.setCdkey2("       ");
                    cdfile.setCdkey1(Utils.movel(cdfile.getCdkey1(), 3, "195", 3));
                    cdfile.setCdkey2(Utils.movel(cdfile.getCdkey2(), 7, dto.getWsfecd(), 4));
                    cdfileKey = new Cdfile();
                    cdfileKey.setCdkey1(cdfile.getCdkey1());
                    cdfileKey.setCdkey2(cdfile.getCdkey2());
                    cdfileTemp = cdfileDAO.selectFirstMatching(cdfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
                    offsetCtlCdfile.offsetClear();
                    if (cdfileTemp != null) {
                        indicator.setIn80(false);
                        cdfile = cdfileTemp;
                    } else {
                        indicator.setIn80(true);
                    }
                    if (Utils.rTrim(cdfile.getCdflg2()).equals(Utils.rTrim("1"))) {
                        indicator.setIn54(true);

                    }
                    ds004.setWkhms2(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 2
//ndz-del-s
//ndz-del-s
//                    // // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[WRITE] original-code : 0660.00:C                   WRITE     OS771D2
////ndz-del-e
//                    // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                    dto.setOs771d2(true);
//                    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0661.00:C                   EXFMT     OS771D3                                      'OK' OR 'NO'
//                    // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                    dto.setOs771d3(true);
//                    dto.setOs771d3Readonly(false);
//                    exfmt();    // 'OK' OR 'NO'
//ndz-del-e
                    if (Utils.rTrim(dto.getWsactn()).equals(Utils.rTrim("OK"))) {
                        _2ttset();    // TTFILE ITEM SET
                        _2ttout();    // TTFILE OUTPUT
                        if (indicator.getIn99() == false) {
                            indicator.setIn73(true);    // DO LOOP END

                        }
                    } else {
                        Arrays.fill(indicator.getIn(), 20, 100, false);

                    }

                }
            }
            while (!(indicator.getIn73() == true));
            if (indicator.getIn73() == true) {
                indicator.setIn72(true);

            }
            if (indicator.getInKC() == true) {
                indicator.setIn72(true);    // CMD3 PGM END

            }
        }
        while (!(indicator.getIn72() == true));

    }

    // ****************************************************
    // DELETE  PROCESS  ROUTINE  (TR=62)        *
    // ****************************************************
    private void _2str62() {
        indicator.setIn72(false);
        do {
            _2sint2();    // DSP INIT 2
            indicator.setIn73(false);
            do {
//ndz-del-s
//ndz-del-s
//                // // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[WRITE] original-code : 0695.00:C                   WRITE     OS771D2
////ndz-del-e
//                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                dto.setOs771d2(true);
//                // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0696.00:C                   EXFMT     OS771D4
//                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                dto.setOs771d4(true);
//                dto.setOs771d4Readonly(false);
//                exfmt();
//ndz-del-e
//ndz-add-s
//ndz-del-s
                // // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[WRITE] original-code : 0695.00:C                   WRITE     OS771D2
//ndz-del-e
                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
                dto.setOs771d2(true);
                // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0696.00:C                   EXFMT     OS771D4
                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
                dto.setOs771d4(true);
                dto.setOs771d4Readonly(false);
                exfmt();
//ndz-del-e
                ds003.setWkhms1(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 1
//ndz-del-s
                dto.setWsactn("  ");    // OK,NO AREA
                if (indicator.getInKC() == true) {
                    break;    // CMD3 PGM END

                }
//ndz-del-e
//ndz-add-e
                ds003.setWkhms1(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 1
                dto.setWsactn("  ");    // OK,NO AREA
                if (indicator.getInKC() == true) {
                    break;    // CMD3 PGM END

                }
                if (indicator.getIn99() == false) {
                    _2opaut();    // OP.NO AUTO CNT

                }
                if (indicator.getIn99() == false) {    // NOT ERROR
                    ds004.setWkhms2(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 2
//ndz-del-s
//ndz-del-s
//                    // // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[WRITE] original-code : 0708.00:C                   WRITE     OS771D2
////ndz-del-e
//                    // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                    dto.setOs771d2(true);
//                    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0709.00:C                   EXFMT     OS771D3                                      'OK' OR 'NO'
//                    // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                    dto.setOs771d3(true);
//                    dto.setOs771d3Readonly(false);
//                    exfmt();    // 'OK' OR 'NO'
//ndz-del-e
                    if (Utils.rTrim(dto.getWsactn()).equals(Utils.rTrim("OK"))) {
                        _2ttset();    // TTFILE ITEM SET
                        _2ttout();    // TTFILE OUTPUT
                        if (indicator.getIn99() == false) {
                            indicator.setIn73(true);    // DO LOOP END

                        }

                    }

                }
            }
            while (!(indicator.getIn73() == true));
            if (indicator.getIn73() == true) {
                indicator.setIn72(true);

            }
            if (indicator.getInKC() == true) {
                indicator.setIn72(true);    // CMD3 PGM END

            }
        }
        while (!(indicator.getIn72() == true));

    }

    // ****************************************************
    // CANCEL  PROCESS  ROUTINE  (TR=63)        *
    // ****************************************************
    private void _2str63() {
        indicator.setIn72(false);
        do {
            _2sint2();    // DSP INIT 2
            indicator.setIn73(false);
            do {
//ndz-del-s
//ndz-del-s
//                // // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[WRITE] original-code : 0741.00:C                   WRITE     OS771D2
////ndz-del-e
//                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                dto.setOs771d2(true);
//                // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0742.00:C                   EXFMT     OS771D4
//                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                dto.setOs771d4(true);
//                dto.setOs771d4Readonly(false);
//                exfmt();
//ndz-del-e
//ndz-add-s
//ndz-del-s
                // // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[WRITE] original-code : 0741.00:C                   WRITE     OS771D2
//ndz-del-e
                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
                dto.setOs771d2(true);
                // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0742.00:C                   EXFMT     OS771D4
                // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
                dto.setOs771d4(true);
                dto.setOs771d4Readonly(false);
                exfmt();
//ndz-del-e
                ds003.setWkhms1(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 1
//ndz-del-s
                dto.setWsactn("  ");    // OK,NO AREA
                if (indicator.getInKC() == true) {
                    break;    // CMD3 PGM END

                }
//ndz-del-e
//ndz-add-e
                ds003.setWkhms1(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 1
                dto.setWsactn("  ");    // OK,NO AREA
                if (indicator.getInKC() == true) {
                    break;    // CMD3 PGM END

                }
                if (indicator.getIn99() == false) {
                    _2opaut();    // OP.NO AUTO CNT

                }
                if (indicator.getIn99() == false) {    // NOT ERROR
                    ds004.setWkhms2(new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue());    // PROCESS TIME 2
//ndz-del-s
//ndz-del-s
//                    // // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[WRITE] original-code : 0754.00:C                   WRITE     OS771D2
////ndz-del-e
//                    // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                    dto.setOs771d2(true);
//                    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[EXFMT] original-code : 0755.00:C                   EXFMT     OS771D3                                      'OK' OR 'NO'
//                    // FIXME 画面イベントと業務ロジックの紐付けなど、画面表示系の手修正が必要です
//                    dto.setOs771d3(true);
//                    dto.setOs771d3Readonly(false);
//                    exfmt();    // 'OK' OR 'NO'
//ndz-del-e
                    if (Utils.rTrim(dto.getWsactn()).equals(Utils.rTrim("OK"))) {
                        _2ttset();    // TTFILE ITEM SET
                        _2ttout();    // TTFILE OUTPUT
                        if (indicator.getIn99() == false) {
                            indicator.setIn73(true);    // DO LOOP END

                        }

                    }

                }
            }
            while (!(indicator.getIn73() == true));
            if (indicator.getIn73() == true) {
                indicator.setIn72(true);

            }
            if (indicator.getInKC() == true) {
                indicator.setIn72(true);    // CMD3 PGM END

            }
        }
        while (!(indicator.getIn72() == true));

    }

    // ****************************************************
    // DISPLAY (2)  INITIAL  PROCESS            *
    // ****************************************************
    private void _2sint2() {
        Arrays.fill(indicator.getIn(), 20, 100, false);
        dto.setWsopno("      ");
        ds008.setWsrefo("            ");
        if (indicator.getIn11() == false) {
            dto.setWsoscd(" ");

        }
        dto.setWscycd("   ");
        dto.setWsvdt1("  ");
        dto.setWsvdt2("  ");
        dto.setWsvdt3("   ");
        dto.setWsfecd("    ");
        dto.setWsfenm("               ");
        dto.setWsfcf1("  ");
        dto.setWsfcf2("  ");
        dto.setWsfcf3("   ");
        dto.setWsfct1("  ");
        dto.setWsfct2("  ");
        dto.setWsfct3("   ");
        dto.setWsamnt(Utils.evaluateNumber(15, 2, 0));
        dto.setWsacno(0);
        dto.setWsacnm("                    ");
        if (indicator.getIn11() == false) {
            dto.setWsnsos(" ");

        }
        dto.setWsnscy("   ");
        dto.setWsnsac("          ");
        dto.setWsnsab(0);
        dto.setWsnsan("                    ");
        dto.setWsnsbk("                  ");
        dto.setWslref(0l);
        dto.setWsapno("              ");
        dto.setWscust("                  ");
        dto.setWsvatc(" ");
        dto.setWsacrf(" ");
        dto.setWsrate(Utils.evaluateNumber(9, 7, 0));
        dto.setWssprd(Utils.evaluateNumber(9, 7, 0));
        dto.setWsccd1(" ");
        dto.setWsccd2(" ");
        ds011.setWsrmks("                                                            ");
        dto.setWsthei("               ");
        ds012.setWsflag("          ");
        _117702.set_1177o1(0);
        _117702.set_1177o1(0);
        ds001.setWkopno(0);
        ds001.setWkopno(0);
        ds002.setWkrefo(0L);
        ds002.setWkrefo(0l);
        wkrefn = 0L;
        wkrefn = 0l;
        wkofcd = "    ";
        wkofnm = "               ";
        wkoffm = 0;
        wkoffm = 0;
        wkofto = 0;
        wkofto = 0;
        wkofam = BigDecimal.ZERO;
        wkofam = Utils.evaluateNumber(15, 2, 0);
        wkofac = 0;
        wkofac = 0;
        wkofan = "                    ";
        wkonos = " ";
        wkoncy = "   ";
        wkonac = "          ";
        wkonab = "  ";
        wkonae = 0;
        wkonae = 0;
        wkonan = "                    ";
        wkonbc = 0;
        wkonbc = 0;
        wkonbn = "                  ";
        wkolrf = 0L;
        wkolrf = 0l;
        wkoapn = "              ";
        wkocst = 0;
        wkocst = 0;
        wkoctb = "                  ";
        wkocn1 = "                                        ";
        wkocn2 = "                                        ";
        wkovat = " ";
        wkoarf = " ";
        wkorat = BigDecimal.ZERO;
        wkorat = Utils.evaluateNumber(9, 7, 0);
        wkospr = BigDecimal.ZERO;
        wkospr = Utils.evaluateNumber(9, 7, 0);
        wkocc1 = " ";
        wkocc2 = " ";
        wkormk = "                                                            ";
        wkothe = "               ";
        wkoflg = "          ";
        if (!dto.getWstrcd().equals(60)) {
            ds008.setWoref3(0);
            ds008.setWoref3(Utils.evaluateNumber(3, 0, ds007.getWnref3()).intValue());
            ds008.setWoref1(Utils.movel(ds008.getWoref1(), 1, "-", 1));
            ds008.setWoref8(0);
            ds008.setWoref8(Utils.evaluateNumber(8, 0, ds007.getWnref8()).intValue());

        }
        dto.setWsstat("      ");
        indicator.setIn10(false);    // NOT DSP STATUS
        Arrays.fill(indicator.getIn(), 13, 15, false);    // NOT PROTECT
        if (dto.getWstrcd().equals(61)) {
            indicator.setIn13(true);    // PROTECT
            if (!Utils.rTrim(wkstat).equals(Utils.rTrim("0"))) {
                indicator.setIn14(true);    // PROTECT

            }

        }
        if (!dto.getWstrcd().equals(60)) {
            _2srset();    // SCREEN ITEM SET

        }

    }

    // ****************************************************
    // SCREEN ITEM CHECK PROCESS                *
    // ****************************************************
    private void _2schk1() {
        Arrays.fill(indicator.getIn(), 20, 100, false);
        // **  <01> OP.NO CHECK  ***
        // NO CHECK
        // **  <02> CUR CHECK  ***
        if (dto.getWstrcd().equals(60)) {
            wkflg1 = " ";
            wkflg2 = " ";
            wkflg3 = " ";
            wkcode = 0;
            wkcode = 0;
            wksupp = 0;
            wksupp = 0;
            cdfile.setCdkey1("   ");
            cdfile.setCdkey2("       ");
            cdfile.setCdkey1(Utils.movel(cdfile.getCdkey1(), 3, "173", 3));
            cdfile.setCdkey2(Utils.movel(cdfile.getCdkey2(), 7, dto.getWsoscd(), 1));
            cdfileKey = new Cdfile();
            cdfileKey.setCdkey1(cdfile.getCdkey1());
            cdfileKey.setCdkey2(cdfile.getCdkey2());
            cdfileTemp = cdfileDAO.selectFirstMatching(cdfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
            offsetCtlCdfile.offsetClear();
            if (cdfileTemp != null) {
                indicator.setIn80(false);
                cdfile = cdfileTemp;
            } else {
                indicator.setIn80(true);
            }
            if (indicator.getIn80() == true && indicator.getIn99() == false) {
                indicator.setIn61(true);

            }
            if (indicator.getIn80() == true) {
                indicator.setIn23(true);    // *UOS5500*
                indicator.setIn99(true);

            }
            cyfll1Key = new Cyfll1();
            cyfll1Key.setCyname(dto.getWscycd());
            cyfll1Temp = cyfll1DAO.selectFirstMatching(cyfll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
            offsetCtlCyfll1.offsetClear();
            if (cyfll1Temp != null) {
                indicator.setIn80(false);
                cyfll1 = cyfll1Temp;
            } else {
                indicator.setIn80(true);
            }
            if (indicator.getIn80() == true && indicator.getIn99() == false) {
                indicator.setIn61(true);

            }
            if (indicator.getIn80() == true) {
                indicator.setIn24(true);    // *UOS1120*
                indicator.setIn99(true);

            }
            if (indicator.getIn23() == false) {
                wkflg1 = Utils.movel(wkflg1, 1, cdfile.getCdflg1(), 1);

            }
            if (indicator.getIn23() == false) {
                wkflg2 = Utils.movel(wkflg2, 1, cdfile.getCdflg2(), 1);

            }
            if (indicator.getIn23() == false) {
                wkflg3 = Utils.movel(wkflg3, 1, cdfile.getCdflg3(), 1);

            }
            if (indicator.getIn24() == false) {
                wkcode = 0;
                wkcode = Utils.evaluateNumber(3, 0, /* TODO:Duplicate field [cyfll1.getCycode()]*/cyfile.getCycode()).intValue();

            }
            if (indicator.getIn24() == false) {
                wksupp = 0;
                wksupp = Utils.evaluateNumber(1, 0, /* TODO:Duplicate field [cyfll1.getCysupp()]*/cyfile.getCysupp()).intValue();

            }

        }
        // **  <03> VAL.DATE CHECK  ***
        if (dto.getWstrcd().equals(60)) {
            wkvldt = 0;
            wkvldt = 0;
            parm09.setPbcomm(Utils.movel(parm09.getPbcomm(), 180, fw103771VO.getParm0(), 180));
            parm09.setPbdat1(Utils.movel(parm09.getPbdat1(), 2, dto.getWsvdt1(), 2));
            parm09.setPbdat2(Utils.movel(parm09.getPbdat2(), 2, dto.getWsvdt2(), 2));
            parm09.setPbdat3(Utils.movel(parm09.getPbdat3(), 3, dto.getWsvdt3(), 3));
            parm09.setPbcycd(0);
            parm09.setPbcycd(Utils.evaluateNumber(3, 0, wkcode).intValue());
            this.fw102002VO.setPcparm(parm09.toString());
            this.fw102002Service.doMain(this.fw102002VO);
            parm09.setData(this.fw102002VO.getPcparm());
            if (Utils.rTrim(parm09.getPbrtcd()).equals(Utils.rTrim("E"))) {
                if (indicator.getIn99() == false) {
                    indicator.setIn61(true);

                }
                indicator.setIn25(true);    // *UOS4901*
                indicator.setIn99(true);
            } else {
                wkvldt = 0;
                wkvldt = Utils.evaluateNumber(7, 0, parm09.getPbdymd()).intValue();

            }
            if (Utils.rTrim(parm09.getPbrtcd()).equals(Utils.rTrim("H"))) {
                indicator.setIn20(true);    // *WARNING*
                indicator.setIn51(true);

            }

        }
        // **  <04> FEE CODE CHECK  ***
        if (dto.getWstrcd().equals(60) || indicator.getIn14() == false) {
            dto.setWsfenm("               ");
            wkfenm = "                    ";
            wkfefg = " ";
            wkcdf3 = " ";    // *ADD MTB-1463
            if (Utils.rTrim(dto.getWsfecd()).equals(Utils.rTrim("    "))) {
                if (indicator.getIn99() == false) {
                    indicator.setIn61(true);

                }
                indicator.setIn26(true);    // *UOS8635*
                indicator.setIn99(true);
            } else {
                cdfile.setCdkey1("   ");
                cdfile.setCdkey2("       ");
                cdfile.setCdkey1(Utils.movel(cdfile.getCdkey1(), 3, "195", 3));
                cdfile.setCdkey2(Utils.movel(cdfile.getCdkey2(), 7, dto.getWsfecd(), 4));
                cdfileKey = new Cdfile();
                cdfileKey.setCdkey1(cdfile.getCdkey1());
                cdfileKey.setCdkey2(cdfile.getCdkey2());
                cdfileTemp = cdfileDAO.selectFirstMatching(cdfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
                offsetCtlCdfile.offsetClear();
                if (cdfileTemp != null) {
                    indicator.setIn80(false);
                    cdfile = cdfileTemp;
                } else {
                    indicator.setIn80(true);
                }
                if (indicator.getIn80() == true && indicator.getIn99() == false) {
                    indicator.setIn62(true);

                }
                if (indicator.getIn80() == true) {
                    indicator.setIn26(true);    // *UOS8636*
                    indicator.setIn99(true);

                }
                if (indicator.getIn26() == false) {
                    dto.setWsfenm(Utils.movel(dto.getWsfenm(), 15, cdfile.getCdnam1(), 20));

                }
                if (indicator.getIn26() == false) {
                    wkfenm = Utils.movel(wkfenm, 20, cdfile.getCdnam1(), 20);

                }
                if (indicator.getIn26() == false) {
                    wkfefg = Utils.movel(wkfefg, 1, cdfile.getCdflg1(), 1);

                }
                if (indicator.getIn26() == false) {
                    wkcdf3 = Utils.movel(wkcdf3, 1, cdfile.getCdflg3(), 1);    // *ADD MTB-1463

                }

            }

        }
        // **  <05> FEE CAL.FM CHECK  ***
        if (dto.getWstrcd().equals(60) || dto.getWstrcd().equals(61)) {
            wkfcfm = 0;
            wkfcfm = 0;
            if (!Utils.rTrim(dto.getWsfcf1()).equals(Utils.rTrim("  ")) || !Utils.rTrim(dto.getWsfcf2()).equals(Utils.rTrim("  ")) || !Utils.rTrim(dto.getWsfcf3()).equals(Utils.rTrim("   "))) {
                parm09.setPbcomm(Utils.movel(parm09.getPbcomm(), 180, fw103771VO.getParm0(), 180));
                parm09.setPbdat1(Utils.movel(parm09.getPbdat1(), 2, dto.getWsfcf1(), 2));
                parm09.setPbdat2(Utils.movel(parm09.getPbdat2(), 2, dto.getWsfcf2(), 2));
                parm09.setPbdat3(Utils.movel(parm09.getPbdat3(), 3, dto.getWsfcf3(), 3));
                parm09.setPbcycd(0);
                parm09.setPbcycd(Utils.evaluateNumber(3, 0, wkcode).intValue());
                this.fw102002VO.setPcparm(parm09.toString());
                this.fw102002Service.doMain(this.fw102002VO);
                parm09.setData(this.fw102002VO.getPcparm());
                if (Utils.rTrim(parm09.getPbrtcd()).equals(Utils.rTrim("E"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn27(true);    // *UOS4901*
                    indicator.setIn99(true);
                } else {
                    wkfcfm = 0;
                    wkfcfm = Utils.evaluateNumber(7, 0, parm09.getPbdymd()).intValue();

                }
                if (Utils.rTrim(parm09.getPbrtcd()).equals(Utils.rTrim("H"))) {
                    indicator.setIn20(true);    // *WARNING*
                    indicator.setIn52(true);

                }

            }

        }
        // **  <06> FEE CAL.TO CHECK  ***
        if (dto.getWstrcd().equals(60) || dto.getWstrcd().equals(61)) {
            wkfcto = 0;
            wkfcto = 0;
            if (!Utils.rTrim(dto.getWsfct1()).equals(Utils.rTrim("  ")) || !Utils.rTrim(dto.getWsfct2()).equals(Utils.rTrim("  ")) || !Utils.rTrim(dto.getWsfct3()).equals(Utils.rTrim("   "))) {
                parm09.setPbcomm(Utils.movel(parm09.getPbcomm(), 180, fw103771VO.getParm0(), 180));
                parm09.setPbdat1(Utils.movel(parm09.getPbdat1(), 2, dto.getWsfct1(), 2));
                parm09.setPbdat2(Utils.movel(parm09.getPbdat2(), 2, dto.getWsfct2(), 2));
                parm09.setPbdat3(Utils.movel(parm09.getPbdat3(), 3, dto.getWsfct3(), 3));
                parm09.setPbcycd(0);
                parm09.setPbcycd(Utils.evaluateNumber(3, 0, wkcode).intValue());
                this.fw102002VO.setPcparm(parm09.toString());
                this.fw102002Service.doMain(this.fw102002VO);
                parm09.setData(this.fw102002VO.getPcparm());
                if (Utils.rTrim(parm09.getPbrtcd()).equals(Utils.rTrim("E"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn28(true);    // *UOS4901*
                    indicator.setIn99(true);
                } else {
                    wkfcto = 0;
                    wkfcto = Utils.evaluateNumber(7, 0, parm09.getPbdymd()).intValue();

                }
                if (Utils.rTrim(parm09.getPbrtcd()).equals(Utils.rTrim("H"))) {
                    indicator.setIn20(true);    // *WARNING*
                    indicator.setIn53(true);

                }

            }

        }
        // **  <07> FEE AMOUNT CHECK  ***
        if (dto.getWstrcd().equals(60) || indicator.getIn14() == false) {
            if (dto.getWsamnt().compareTo(BigDecimal.valueOf(0)) == 0) {
                if (indicator.getIn99() == false) {
                    indicator.setIn61(true);

                }
                indicator.setIn29(true);    // *UOS3802*
                indicator.setIn99(true);
            } else {
                _110201.set_1102i1(0);
                _110201.set_1102i1(Utils.evaluateNumber(1, 0, wksupp).intValue());
                _110201.set_1102i2(BigDecimal.ZERO);
                _110201.set_1102i2(Utils.evaluateNumber(15, 2, dto.getWsamnt()));
                _1102();
                if (Utils.rTrim(_110201.get_1102ot()).equals(Utils.rTrim("1"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn62(true);

                    }
                    indicator.setIn29(true);    // *UOS3600*
                    indicator.setIn99(true);

                }

            }

        }
        // **  <08> FEE A/C CHECK  ***
        if (dto.getWstrcd().equals(60) || indicator.getIn14() == false) {
            dto.setWsacnm("                    ");
            wkact3 = 0;
            wkact3 = 0;
            wkfacc = 0;
            wkfacc = 0;
            wkfacn = "                    ";
            wkac05 = " ";
            wkac25 = " ";
            wkot61 = " ";
            wka3ac = 0;
            wka3ac = 0;
            wkb3ac = 0;
            wkb3ac = 0;
            wkc3ac = 0;
            wkc3ac = 0;
            wkd3ac = 0;
            wkd3ac = 0;
            wke4ac = 0;
            wke4ac = 0;
            wkf4ac = 0;
            wkf4ac = 0;
            if (dto.getWsacno().equals(0)) {
                if (indicator.getIn99() == false) {
                    indicator.setIn61(true);

                }
                indicator.setIn30(true);    // *UOS3614*
                indicator.setIn99(true);
            } else {
                _102401.set_124in("          ");
                _102401.set_124in(Utils.movel(_102401.get_124in(), 10, dto.getWsacno(), 7, 0));
                _124();
                if (!Utils.rTrim(_102401.get_124ot()).equals(Utils.rTrim(" "))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn62(true);

                    }
                    indicator.setIn30(true);    // *UOS0020*
                    indicator.setIn99(true);

                }
                if (Utils.rTrim(/* TODO:Duplicate field [extnl1.getAccd08()]*/acfile.getAccd08()).equals(Utils.rTrim("1"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn63(true);

                    }
                    indicator.setIn30(true);    // *UOS0021*
                    indicator.setIn99(true);

                }
                if (indicator.getIn30() == false) {
                    /* TODO:Duplicate field [tafll1.setTalsno()]*/tatable.setTalsno(Utils.movel(/* TODO:Duplicate field [tafll1.getTalsno()]*/tatable.getTalsno(), 4, "416 ", 4));
                    /* TODO:Duplicate field [tafll1.setTatype()]*/tatable.setTatype(Utils.movel(/* TODO:Duplicate field [tafll1.getTatype()]*/tatable.getTatype(), 1, "8", 1));
                    /* TODO:Duplicate field [tafll1.setTaaccd()]*/tatable.setTaaccd(0);
                    /* TODO:Duplicate field [tafll1.setTaaccd()]*/tatable.setTaaccd(Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [extnl1.getAcincd()]*/acfile.getAcincd()).intValue());
                    /* TODO:Duplicate field [tafll1.setTaact1()]*/tatable.setTaact1("  ");
                    /* TODO:Duplicate field [tafll1.setTaact2()]*/tatable.setTaact2("  ");
                    /* TODO:Duplicate field [tafll1.setTaact3()]*/tatable.setTaact3("  ");
                    /* TODO:Duplicate field [tafll1.setTacd01()]*/tatable.setTacd01(Utils.movel(/* TODO:Duplicate field [tafll1.getTacd01()]*/tatable.getTacd01(), 1, "2", 1));
                    tatableKey = new Tatable();
                    tatableKey.setTalsno(/* TODO:Duplicate field [tafll1.getTalsno()]*/tatable.getTalsno());
                    tatableKey.setTatype(/* TODO:Duplicate field [tafll1.getTatype()]*/tatable.getTatype());
                    tatableKey.setTaaccd(/* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd());
                    tatableKey.setTaact1(/* TODO:Duplicate field [tafll1.getTaact1()]*/tatable.getTaact1());
                    tatableKey.setTaact2(/* TODO:Duplicate field [tafll1.getTaact2()]*/tatable.getTaact2());
                    tatableKey.setTaact3(/* TODO:Duplicate field [tafll1.getTaact3()]*/tatable.getTaact3());
                    tatableKey.setTacd01(/* TODO:Duplicate field [tafll1.getTacd01()]*/tatable.getTacd01());
                    tatableTemp = tatableDAO.selectFirstMatching(tatableKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
                    offsetCtlTatable.offsetClear();
                    if (tatableTemp != null) {
                        indicator.setIn81(false);
                        tatable = tatableTemp;
                    } else {
                        indicator.setIn81(true);
                    }
                    if (indicator.getIn81() == false) {
                        wktacd = 0;
                        wktacd = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd()).intValue();

                    }
                    /* TODO:Duplicate field [tafll1.setTalsno()]*/tatable.setTalsno(Utils.movel(/* TODO:Duplicate field [tafll1.getTalsno()]*/tatable.getTalsno(), 4, "416 ", 4));
                    /* TODO:Duplicate field [tafll1.setTatype()]*/tatable.setTatype(Utils.movel(/* TODO:Duplicate field [tafll1.getTatype()]*/tatable.getTatype(), 1, "9", 1));
                    /* TODO:Duplicate field [tafll1.setTaaccd()]*/tatable.setTaaccd(0);
                    /* TODO:Duplicate field [tafll1.setTaaccd()]*/tatable.setTaaccd(Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [extnl1.getAcincd()]*/acfile.getAcincd()).intValue());
                    /* TODO:Duplicate field [tafll1.setTaact1()]*/tatable.setTaact1("  ");
                    /* TODO:Duplicate field [tafll1.setTaact2()]*/tatable.setTaact2("  ");
                    /* TODO:Duplicate field [tafll1.setTaact3()]*/tatable.setTaact3("  ");
                    /* TODO:Duplicate field [tafll1.setTacd01()]*/tatable.setTacd01(Utils.movel(/* TODO:Duplicate field [tafll1.getTacd01()]*/tatable.getTacd01(), 1, "2", 1));
                    tatableKey = new Tatable();
                    tatableKey.setTalsno(/* TODO:Duplicate field [tafll1.getTalsno()]*/tatable.getTalsno());
                    tatableKey.setTatype(/* TODO:Duplicate field [tafll1.getTatype()]*/tatable.getTatype());
                    tatableKey.setTaaccd(/* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd());
                    tatableKey.setTaact1(/* TODO:Duplicate field [tafll1.getTaact1()]*/tatable.getTaact1());
                    tatableKey.setTaact2(/* TODO:Duplicate field [tafll1.getTaact2()]*/tatable.getTaact2());
                    tatableKey.setTaact3(/* TODO:Duplicate field [tafll1.getTaact3()]*/tatable.getTaact3());
                    tatableKey.setTacd01(/* TODO:Duplicate field [tafll1.getTacd01()]*/tatable.getTacd01());
                    tatableTemp = tatableDAO.selectFirstMatching(tatableKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
                    offsetCtlTatable.offsetClear();
                    if (tatableTemp != null) {
                        indicator.setIn82(false);
                        tatable = tatableTemp;
                    } else {
                        indicator.setIn82(true);
                    }
                    if (indicator.getIn82() == false) {
                        wktacd = 0;
                        wktacd = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTatacd()]*/tatable.getTatacd()).intValue();

                    }
                    if (indicator.getIn81() == true && indicator.getIn82() == true) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn63(true);

                        }
                        indicator.setIn30(true);    // *UOS0021*
                        indicator.setIn99(true);

                    }

                }
                if (indicator.getIn30() == false) {
                    dto.setWsacnm(Utils.movel(dto.getWsacnm(), 20, /* TODO:Duplicate field [extnl1.getAcname()]*/acfile.getAcname(), 20));

                }
                if (indicator.getIn30() == false) {
                    wkact3 = 0;
                    wkact3 = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [extnl1.getAcincd()]*/acfile.getAcincd()).intValue();

                }
                if (indicator.getIn30() == false) {
                    wkfacc = 0;
                    wkfacc = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [extnl1.getAcexcd()]*/acfile.getAcexcd()).intValue();

                }
                if (indicator.getIn30() == false) {
                    wkfacn = Utils.movel(wkfacn, 20, /* TODO:Duplicate field [extnl1.getAcname()]*/acfile.getAcname(), 20);

                }
                if (indicator.getIn30() == false) {
                    wkdrcr = Utils.movel(wkdrcr, 1, /* TODO:Duplicate field [extnl1.getAcdrcr()]*/acfile.getAcdrcr(), 1);

                }
                if (indicator.getIn30() == false) {
                    wkac05 = Utils.movel(wkac05, 1, /* TODO:Duplicate field [extnl1.getAccd05()]*/acfile.getAccd05(), 1);

                }
                if (indicator.getIn30() == false) {
                    wkac25 = Utils.movel(wkac25, 1, /* TODO:Duplicate field [extnl1.getAccd25()]*/acfile.getAccd25(), 1);

                }
                if (indicator.getIn30() == false) {
                    wkot61 = Utils.movel(wkot61, 1, /* TODO:Duplicate field [extnl1.getAcot61()]*/acfile.getAcot61(), 1);

                }
                if (indicator.getIn30() == false) {
                    _2acget();    // ACCURAL A/C GET

                }

            }

        }
        // **  <09> SB CODE CHECK  ***
        // NO CHECK
        // **  <10> NOSTRO CUR CHECK  ***
        if (dto.getWstrcd().equals(60) || indicator.getIn14() == false) {
            if (!Utils.rTrim(dto.getWsnsos()).equals(Utils.rTrim(" "))) {
                wknfg1 = " ";
                wknfg2 = " ";
                wknfg3 = " ";
                cdfile.setCdkey1("   ");
                cdfile.setCdkey2("       ");
                cdfile.setCdkey1(Utils.movel(cdfile.getCdkey1(), 3, "173", 3));
                cdfile.setCdkey2(Utils.movel(cdfile.getCdkey2(), 7, dto.getWsnsos(), 1));
                cdfileKey = new Cdfile();
                cdfileKey.setCdkey1(cdfile.getCdkey1());
                cdfileKey.setCdkey2(cdfile.getCdkey2());
                cdfileTemp = cdfileDAO.selectFirstMatching(cdfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
                offsetCtlCdfile.offsetClear();
                if (cdfileTemp != null) {
                    indicator.setIn80(false);
                    cdfile = cdfileTemp;
                } else {
                    indicator.setIn80(true);
                }
                if (indicator.getIn80() == true && indicator.getIn99() == false) {
                    indicator.setIn61(true);

                }
                if (indicator.getIn80() == true) {
                    indicator.setIn32(true);    // *UOS5500*
                    indicator.setIn99(true);

                }
                if (indicator.getIn32() == false) {
                    wknfg1 = Utils.movel(wknfg1, 1, cdfile.getCdflg1(), 1);

                }
                if (indicator.getIn32() == false) {
                    wknfg2 = Utils.movel(wknfg2, 1, cdfile.getCdflg2(), 1);

                }
                if (indicator.getIn32() == false) {
                    wknfg3 = Utils.movel(wknfg3, 1, cdfile.getCdflg3(), 1);

                }

            }

        }
        dto.setWsnscy(Utils.movel(dto.getWsnscy(), 3, dto.getWscycd(), 3));
        wkocd4 = Utils.move(wkocd4, 1, 0, dto.getWsnsos(), 1).intValue();
        wkcur4 = 0;
        wkcur4 = Utils.evaluateNumber(3, 0, wkcode).intValue();
        // **  <11> NOSTRO A/C CHECK  ***
        if (dto.getWstrcd().equals(60) || indicator.getIn14() == false) {
            dto.setWsnsan("                    ");
            w108o1 = " ";
            w108o2 = " ";
            w108o3 = 0;
            w108o3 = 0;
            w108o4 = 0;
            w108o4 = 0;
            w108o5 = 0;
            w108o5 = 0;
            w108o6 = 0;
            w108o6 = 0;
            w108o7 = 0;
            w108o7 = 0;
            wkexcd = 0;
            wkexcd = 0;
            wkabbr = "          ";
            wkname = "                    ";
            wkamcd = " ";
            wkac07 = " ";
            wkac24 = " ";
            ds009.setWkrefb(0L);
            ds009.setWkrefb(0l);
            if (!Utils.rTrim(dto.getWsnsac()).equals(Utils.rTrim("          "))) {
                _110801.set_1108i1(Utils.movel(_110801.get_1108i1(), 10, dto.getWsnsac(), 10));
                _110801.set_1108i2(0);
                _110801.set_1108i2(Utils.evaluateNumber(3, 0, dto.getWsnsab()).intValue());
                _110801.set_1108i3("0");
                _1108();
                w108o1 = _110801.get_1108o1();
                if (Utils.rTrim(_110801.get_1108o1()).equals(Utils.rTrim("1")) || Utils.rTrim(_110801.get_1108o1()).equals(Utils.rTrim("2")) || Utils.rTrim(_110801.get_1108o1()).equals(Utils.rTrim("3")) || Utils.rTrim(_110801.get_1108o1()).equals(Utils.rTrim("4")) || Utils.rTrim(_110801.get_1108o1()).equals(Utils.rTrim("6"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn33(true);    // *UOS1909*
                    indicator.setIn99(true);

                }
                if (Utils.rTrim(_110801.get_1108o1()).equals(Utils.rTrim("5"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn62(true);

                    }
                    indicator.setIn33(true);    // *UOS1910*
                    indicator.setIn99(true);

                }
                if (Utils.rTrim(_110801.get_1108o1()).equals(Utils.rTrim("7")) || Utils.rTrim(_110801.get_1108o1()).equals(Utils.rTrim("8"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn63(true);

                    }
                    indicator.setIn33(true);    // *UOS1911*
                    indicator.setIn99(true);

                }
                if (indicator.getIn33() == false) {
                    dto.setWsnsan(Utils.movel(dto.getWsnsan(), 20, /* TODO:Duplicate field [extnl1.getAcname()]*/acfile.getAcname(), 20));
                    wkexcd = 0;
                    wkexcd = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [extnl1.getAcexcd()]*/acfile.getAcexcd()).intValue();
                    wkabbr = Utils.movel(wkabbr, 10, /* TODO:Duplicate field [extnl1.getAcabbr()]*/acfile.getAcabbr(), 10);
                    wkname = Utils.movel(wkname, 20, /* TODO:Duplicate field [extnl1.getAcname()]*/acfile.getAcname(), 20);
                    wkamcd = Utils.movel(wkamcd, 1, /* TODO:Duplicate field [extnl1.getAcamcd()]*/acfile.getAcamcd(), 1);
                    wkac07 = Utils.movel(wkac07, 1, /* TODO:Duplicate field [extnl1.getAccd07()]*/acfile.getAccd07(), 1);
                    wkac24 = Utils.movel(wkac24, 1, /* TODO:Duplicate field [extnl1.getAccd24()]*/acfile.getAccd24(), 1);
                    w108o1 = Utils.movel(w108o1, 1, _110801.get_1108o1(), 1);
                    w108o2 = Utils.movel(w108o2, 1, _110801.get_1108o2(), 1);
                    w108o3 = 0;
                    w108o3 = Utils.evaluateNumber(7, 0, _110801.get_1108o3()).intValue();
                    w108o4 = 0;
                    w108o4 = Utils.evaluateNumber(3, 0, _110801.get_1108o4()).intValue();
                    w108o5 = 0;
                    w108o5 = Utils.evaluateNumber(1, 0, _110801.get_1108o5()).intValue();
                    w108o6 = 0;
                    w108o6 = Utils.evaluateNumber(3, 0, _110801.get_1108o6()).intValue();
                    w108o7 = 0;
                    w108o7 = Utils.evaluateNumber(7, 0, _110801.get_1108o7()).intValue();
                    if (Utils.rTrim(w108o2).equals(Utils.rTrim("2"))) {
                        ds009.setWkrefb(0L);
                        ds009.setWkrefb(Utils.evaluateNumber(11, 0, /* TODO:Duplicate field [refnl4.getAmrefb()]*/amfile.getAmrefb()).longValue());
                    } else {
                        dto.setWsnsac(Utils.movel(dto.getWsnsac(), 10, /* TODO:Duplicate field [extnl1.getAcabbr()]*/acfile.getAcabbr(), 10));

                    }
                    if (Utils.rTrim(dto.getWsnsbk()).equals(Utils.rTrim("                  "))) {
                        if (Utils.rTrim(w108o2).equals(Utils.rTrim("2"))) {
                            if (Utils.rTrim(wkamcd).equals(Utils.rTrim("3"))) {
                                cmfileKey = new Cmfile();
                                cmfileKey.setCmcust(w108o7);
                                cmfileTemp = cmfileDAO.selectFirstMatching(cmfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
                                offsetCtlCmfile.offsetClear();
                                if (cmfileTemp != null) {
                                    indicator.setIn80(false);
                                    cmfile = cmfileTemp;
                                } else {
                                    indicator.setIn80(true);
                                }
                                if (indicator.getIn80() == false) {
                                    dto.setWsnsbk(Utils.movel(dto.getWsnsbk(), 18, cmfile.getCmctab(), 18));

                                }

                            }

                        }

                    }
                    if (Utils.rTrim(dto.getWscust()).equals(Utils.rTrim("                  "))) {
                        if (Utils.rTrim(w108o2).equals(Utils.rTrim("2"))) {
                            if (Utils.rTrim(wkamcd).equals(Utils.rTrim("2")) || Utils.rTrim(wkamcd).equals(Utils.rTrim("4"))) {
                                cmfileKey = new Cmfile();
                                cmfileKey.setCmcust(w108o7);
                                cmfileTemp = cmfileDAO.selectFirstMatching(cmfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
                                offsetCtlCmfile.offsetClear();
                                if (cmfileTemp != null) {
                                    indicator.setIn80(false);
                                    cmfile = cmfileTemp;
                                } else {
                                    indicator.setIn80(true);
                                }
                                if (indicator.getIn80() == false) {
                                    dto.setWscust(Utils.movel(dto.getWscust(), 18, cmfile.getCmctab(), 18));

                                }

                            }

                        }

                    }

                }

            }

        }
        // **  <12> NOSTR BK CHECK  ***
        if (dto.getWstrcd().equals(60) || indicator.getIn14() == false) {
            wknsbc = 0;
            wknsbc = 0;
            wknsbn = "                  ";
            if (!Utils.rTrim(dto.getWsnsbk()).equals(Utils.rTrim("                  "))) {
                _102301.set_123in1(Utils.movel(_102301.get_123in1(), 18, dto.getWsnsbk(), 18));
                _102301.set_123in2(Utils.movel(_102301.get_123in2(), 1, "B", 1));
                _123();
                if (Utils.rTrim(_102301.get_123ot()).equals(Utils.rTrim("1"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn34(true);    // *UOS1200*
                    indicator.setIn99(true);

                }
                if (Utils.rTrim(_102301.get_123ot()).equals(Utils.rTrim("2"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn62(true);

                    }
                    indicator.setIn34(true);    // *UOS1902*
                    indicator.setIn99(true);

                }
                if (indicator.getIn34() == false) {
                    dto.setWsnsbk(Utils.movel(dto.getWsnsbk(), 18, cmfile.getCmctab(), 18));

                }
                if (indicator.getIn34() == false) {
                    wknsbc = 0;
                    wknsbc = Utils.evaluateNumber(7, 0, cmfile.getCmcust()).intValue();

                }
                if (indicator.getIn34() == false) {
                    wknsbn = Utils.movel(wknsbn, 18, cmfile.getCmctab(), 18);

                }

            }

        }
        // **  <13> LINK REF. CHECK  ***
        if (dto.getWstrcd().equals(60) || indicator.getIn14() == false) {
            ds010.setWklref(0L);
            ds010.setWklref(0l);
            if (!dto.getWslref().equals(0l)) {
                ds010.setWklref(0L);
                ds010.setWklref(Utils.evaluateNumber(11, 0, dto.getWslref()).longValue());

            }

        }
        // **  <14> LINK AP.NO CHECK  ***
        if (dto.getWstrcd().equals(60) || indicator.getIn14() == false) {
            if (!Utils.rTrim(dto.getWsapno()).equals(Utils.rTrim("              "))) {

            }

        }
        // **  <15> CUSTOMER CHECK  ***
        if (dto.getWstrcd().equals(60) || indicator.getIn14() == false) {
            wkcust = 0;
            wkcust = 0;
            wkcnm1 = "                                        ";
            wkcnm2 = "                                        ";
            wkcocd = 0;
            wkcocd = 0;
            if (!Utils.rTrim(dto.getWscust()).equals(Utils.rTrim("                  "))) {
                _102301.set_123in1(Utils.movel(_102301.get_123in1(), 18, dto.getWscust(), 18));
                _102301.set_123in2(Utils.movel(_102301.get_123in2(), 1, "E", 1));
                _123();
                if (Utils.rTrim(_102301.get_123ot()).equals(Utils.rTrim("1"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn37(true);    // *UOS1200*
                    indicator.setIn99(true);

                }
                if (indicator.getIn37() == false) {
                    dto.setWscust(Utils.movel(dto.getWscust(), 18, cmfile.getCmctab(), 18));
                    wkcust = 0;
                    wkcust = Utils.evaluateNumber(7, 0, cmfile.getCmcust()).intValue();
                    wkcnm1 = Utils.movel(wkcnm1, 40, cmfile.getCmnam1(), 40);
                    wkcnm2 = Utils.movel(wkcnm2, 40, cmfile.getCmnam2(), 40);
                    wkcocd = 0;
                    wkcocd = Utils.evaluateNumber(3, 0, cmfile.getCmcocd()).intValue();

                }

            }

        }
        // **  <16> VAT CHECK  ***
        // NO CHECK
        // **  <17> ACCRUAL FG CHECK  ***
        if (dto.getWstrcd().equals(60) || dto.getWstrcd().equals(61)) {
            if (!Utils.rTrim(dto.getWsacrf()).equals(Utils.rTrim(" ")) && !Utils.rTrim(dto.getWsacrf()).equals(Utils.rTrim("1"))) {
                if (indicator.getIn99() == false) {
                    indicator.setIn61(true);

                }
                indicator.setIn39(true);    // *UOS8637*
                indicator.setIn99(true);

            }

        }
        // **  <18> RATE CHECK  ***
        // NO CHECK
        // **  <19> SPREAD CHECK  ***
        // NO CHECK
        // **  <20> FEE.CL.CD1 CHECK  ***
        // NO CHECK
        // **  <21> FEE.CL.CD2 CHECK  ***
        // NO CHECK
        // **  <22> PARTICULAR CHECK  ***
        // NO CHECK
        // **  <23> THEIR CHECK  ***
        // NO CHECK
        // **  <24> FLAG CHECK  ***
        // NO CHECK

    }

    // ****************************************************
    // COMBINATION  CHECK  PROCESS              *
    // ****************************************************
    private void _2schk2() {
        indicator.setIn69(true);
        for (wkidxfor1 = 1; wkidxfor1 <= 1 ; wkidxfor1++) {
            // **  < 1 >  VAL.DATE & FEE CAL.FM & FEE CAL.TO & FEE A/C CHECK  ***
            if (wka3ac.equals(0) && wkb3ac.equals(0) && wkc3ac.equals(0) && wkd3ac.equals(0) && wke4ac.equals(0) && wkf4ac.equals(0)) {
                if (!wkfcfm.equals(0)) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn27(true);    // *UOS8638*
                    indicator.setIn30(true);
                    indicator.setIn99(true);

                }
                if (!wkfcto.equals(0)) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn28(true);    // *UOS8639*
                    indicator.setIn30(true);
                    indicator.setIn99(true);

                }

            }
            if (indicator.getIn99() == false) {
                if (!wkfcfm.equals(0) && wkvldt <= wkfcfm) {
                    if (wkb3ac.equals(0) && wkd3ac.equals(0) || wkf4ac.equals(0)) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn62(true);

                        }
                        indicator.setIn25(true);    // *UOS8640*
                        indicator.setIn27(true);
                        indicator.setIn30(true);
                        indicator.setIn99(true);

                    }

                }

            }
            if (indicator.getIn99() == false) {
                if (!wkfcto.equals(0) && wkfcto <= wkvldt) {
                    if (wka3ac.equals(0) && wkc3ac.equals(0) || wke4ac.equals(0)) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn63(true);

                        }
                        indicator.setIn25(true);    // *UOS8641*
                        indicator.setIn28(true);
                        indicator.setIn30(true);
                        indicator.setIn99(true);

                    }

                }

            }
            if (indicator.getIn99() == false) {
                if (!wkfcfm.equals(0) && !wkfcto.equals(0) && wkfcfm < wkvldt && wkvldt < wkfcto) {
                    if (wkb3ac.equals(0) && wkd3ac.equals(0) || wkf4ac.equals(0) || wka3ac.equals(0) && wkc3ac.equals(0) || wke4ac.equals(0)) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn64(true);

                        }
                        indicator.setIn25(true);    // *UOS8642*
                        Arrays.fill(indicator.getIn(), 27, 29, true);
                        indicator.setIn30(true);
                        indicator.setIn99(true);

                    }

                }

            }
            if (indicator.getIn99() == true) {
                break;

            }
            // **  < 2 >  FEE CAL.FM & FEE CAL.TO CHECK  ***
            if (!wkfcfm.equals(0) && wkfcto.equals(0) || wkfcfm.equals(0) && !wkfcto.equals(0)) {
                if (indicator.getIn99() == false) {
                    indicator.setIn65(true);

                }
                Arrays.fill(indicator.getIn(), 27, 29, true);    // *UOS8643*
                indicator.setIn99(true);

            }
            if (!wkfcfm.equals(0) && !wkfcto.equals(0)) {
                if (wkfcfm >= wkfcto) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn66(true);

                    }
                    Arrays.fill(indicator.getIn(), 27, 29, true);    // *UOS8644*
                    indicator.setIn99(true);

                }

            }
            if (indicator.getIn99() == true) {
                break;

            }
            // **  < 3 >  CUR & FEE A/C CHECK  ***
            if (Utils.rTrim(wkac05).equals(Utils.rTrim(" ")) || Utils.rTrim(wkac05).equals(Utils.rTrim("2"))) {
                if (Utils.rTrim(wkflg1).equals(Utils.rTrim("T"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn23(true);    // *UOS8645*
                    indicator.setIn30(true);
                    indicator.setIn99(true);

                }

            }
            if (Utils.rTrim(wkac05).equals(Utils.rTrim("1"))) {
                if (!Utils.rTrim(wkflg3).equals(Utils.rTrim("1")) && !Utils.rTrim(wkflg3).equals(Utils.rTrim(" "))) {    // * ADD M-1431 *
                    if (indicator.getIn99() == false) {
                        indicator.setIn62(true);

                    }
                    indicator.setIn23(true);    // *UOS8646*
                    indicator.setIn30(true);
                    indicator.setIn99(true);

                }

            }
            if (indicator.getIn99() == true) {
                break;

            }
            // **  < 4 >  SB CODE CHECK  ***
            // **  < 5 >  SB CODE & NOSTRO CUR & NOSTRO A/C & NOSTRO BK CHECK  ***
            if (Utils.rTrim(dto.getWsnsos()).equals(Utils.rTrim(" "))) {
                if (indicator.getIn99() == false) {
                    indicator.setIn64(true);

                }
                Arrays.fill(indicator.getIn(), 31, 33, true);    // *UOS9244*
                indicator.setIn99(true);

            }
            if (Utils.rTrim(dto.getWsnsac()).equals(Utils.rTrim("          "))) {
                if (indicator.getIn99() == false) {
                    indicator.setIn64(true);

                }
                indicator.setIn31(true);    // *UOS9244*
                indicator.setIn33(true);
                indicator.setIn99(true);

            }
            if (indicator.getIn99() == true) {
                break;

            }
            // **  < 6 >  NOSTRO CUR & NOSTRO A/C & NOSTRO BK & CUSTOMER CHECK  ***
            if (Utils.rTrim(w108o1).equals(Utils.rTrim(" "))) {
                if (!Utils.rTrim(dto.getWsnsac()).equals(Utils.rTrim("          ")) || !Utils.rTrim(dto.getWsnsbk()).equals(Utils.rTrim("                  "))) {
                    _110501.set_1105i1(Utils.move(_110501.get_1105i1(), 1, 0, dto.getWsnsos(), 1).intValue());
                    _110501.set_1105i2(0);
                    _110501.set_1105i2(Utils.evaluateNumber(3, 0, wkcode).intValue());
                    _110501.set_1105i3(0);
                    _110501.set_1105i3(Utils.evaluateNumber(7, 0, w108o3).intValue());
                    _110501.set_1105i4(0);
                    _110501.set_1105i4(Utils.evaluateNumber(3, 0, w108o4).intValue());
                    _110501.set_1105i5(0);
                    _110501.set_1105i5(Utils.evaluateNumber(7, 0, wkcust).intValue());
                    _110501.set_1105i6(0);
                    _110501.set_1105i6(Utils.evaluateNumber(7, 0, wknsbc).intValue());
                    _110501.set_1105i7(Utils.movel(_110501.get_1105i7(), 1, wkamcd, 1));
                    _110501.set_1105i8(Utils.movel(_110501.get_1105i8(), 1, wkac07, 1));
                    _110501.set_1105i9(Utils.movel(_110501.get_1105i9(), 1, wkac24, 1));
                    _110501.set_1105ia(0);
                    _110501.set_1105ia(Utils.evaluateNumber(1, 0, w108o5).intValue());
                    _110501.set_1105ib(0);
                    _110501.set_1105ib(Utils.evaluateNumber(3, 0, w108o6).intValue());
                    _110501.set_1105ic(0);
                    _110501.set_1105ic(Utils.evaluateNumber(7, 0, w108o7).intValue());
                    _110501.set_1105id(Utils.movel(_110501.get_1105id(), 1, w108o2, 1));
                    _1105();
                    if (Utils.rTrim(_110501.get_1105o1()).equals(Utils.rTrim("1")) || Utils.rTrim(_110501.get_1105o1()).equals(Utils.rTrim("2"))) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn61(true);

                        }
                        Arrays.fill(indicator.getIn(), 33, 35, true);    // *UOS1903*
                        indicator.setIn37(true);
                        indicator.setIn99(true);

                    }
                    if (Utils.rTrim(_110501.get_1105o1()).equals(Utils.rTrim("3"))) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn62(true);

                        }
                        Arrays.fill(indicator.getIn(), 33, 35, true);    // *UOS1904*
                        indicator.setIn37(true);
                        indicator.setIn99(true);

                    }
                    if (Utils.rTrim(_110501.get_1105o1()).equals(Utils.rTrim("4"))) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn63(true);

                        }
                        Arrays.fill(indicator.getIn(), 33, 35, true);    // *UOS1905*
                        indicator.setIn37(true);
                        indicator.setIn99(true);

                    }
                    if (Utils.rTrim(_110501.get_1105o1()).equals(Utils.rTrim("5")) || Utils.rTrim(_110501.get_1105o1()).equals(Utils.rTrim("6")) || Utils.rTrim(_110501.get_1105o1()).equals(Utils.rTrim("7")) || Utils.rTrim(_110501.get_1105o1()).equals(Utils.rTrim("8"))) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn64(true);

                        }
                        Arrays.fill(indicator.getIn(), 33, 35, true);    // *UOS1906*
                        indicator.setIn37(true);
                        indicator.setIn99(true);

                    }

                }

            }
            if (indicator.getIn99() == true) {
                break;

            }
            // **  < 7 >  FEE CODE & LINK REF. & LINK AP.NO CHECK  ***
            if (!dto.getWslref().equals(0l) && !Utils.rTrim(dto.getWsapno()).equals(Utils.rTrim("              "))) {
                if (indicator.getIn99() == false) {
                    indicator.setIn61(true);

                }
                Arrays.fill(indicator.getIn(), 35, 37, true);    // *UOS8647*
                indicator.setIn99(true);

            }
            if (indicator.getIn99() == false) {
                if (Utils.rTrim(wkfefg).equals(Utils.rTrim(" "))) {
                    if (dto.getWslref().equals(0l) && Utils.rTrim(dto.getWsapno()).equals(Utils.rTrim("              "))) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn62(true);

                        }
                        indicator.setIn26(true);    // *UOS8648*
                        Arrays.fill(indicator.getIn(), 35, 37, true);
                        indicator.setIn99(true);

                    }

                }

            }
            if (indicator.getIn99() == true) {
                break;

            }
            // **  < 8 >  FEE A/C & CUSTOMER & VAT CHECK  ***
            wkvatc = Utils.movel(wkvatc, 1, dto.getWsvatc(), 1);
            if (Utils.rTrim(parm0.getPavatc()).equals(Utils.rTrim("1")) && Utils.rTrim(wkot61).equals(Utils.rTrim("2"))) {
                _111101.set_1111i1(Utils.movel(_111101.get_1111i1(), 1, wkac25, 1));
                _111101.set_1111i2(0);
                _111101.set_1111i2(Utils.evaluateNumber(3, 0, wkcocd).intValue());
                _111101.set_1111i3(Utils.movel(_111101.get_1111i3(), 1, dto.getWsvatc(), 1));
                _1111();
                if (Utils.rTrim(_111101.get_1111ot()).equals(Utils.rTrim("1"))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn30(true);    // *UOS6306*
                    indicator.setIn38(true);
                    indicator.setIn99(true);

                }
                wkvatc = Utils.movel(wkvatc, 1, _111101.get_1111o1(), 1);
                dto.setWsvatc(Utils.movel(dto.getWsvatc(), 1, _111101.get_1111o1(), 1));

            }
            if (indicator.getIn99() == true) {
                break;

            }
            // **  < 9 >  FEE CAL.FM & FEE CAL.TO & FEE A/C & ACCRUAL FG CHECK  ***
            if (Utils.rTrim(wkac05).equals(Utils.rTrim("1"))) {
                if (!Utils.rTrim(dto.getWsacrf()).equals(Utils.rTrim(" "))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn62(true);

                    }
                    indicator.setIn30(true);    // *UOS8649*
                    indicator.setIn39(true);
                    indicator.setIn99(true);

                }

            }
            if (indicator.getIn99() == false) {
                if (wkfcfm.equals(0) && wkfcto.equals(0)) {
                    if (!Utils.rTrim(dto.getWsacrf()).equals(Utils.rTrim(" "))) {
                        if (indicator.getIn99() == false) {
                            indicator.setIn67(true);

                        }
                        Arrays.fill(indicator.getIn(), 27, 29, true);    // *UOS8650*
                        indicator.setIn39(true);
                        indicator.setIn99(true);

                    }

                }

            }
            // **  < 10 >  FEE CODE & ACCRUAL FG CHECK  ***
            if (Utils.rTrim(wkcdf3).equals(Utils.rTrim("1"))) {
                if (!Utils.rTrim(dto.getWsacrf()).equals(Utils.rTrim(" "))) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn39(true);    // *UOS8696*
                    indicator.setIn99(true);

                }

            }
        }

    }

    // ****************************************************
    // REF.NO AUTO COUNT UP PROCESS  ( REF.NO ) *
    // ****************************************************
    private void _2rfaut() {
        if (ds002.getWkrefo().equals(0l)) {
            do {
                nufile.setNucod1(0);
                nufile.setNucod1(Utils.evaluateNumber(5, 0, 91).intValue());
                nufile.setNucod2(0);
                nufile.setNucod2(Utils.evaluateNumber(5, 0, 990).intValue());
                nufileKey = new Nufile();
                nufileKey.setNucod1(nufile.getNucod1());
                nufileKey.setNucod2(nufile.getNucod2());
//ndz-del-s
                // // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CHAIN] original-code : 1722.00:C     KEYNU         CHAIN     NURECD                             80
                // //                                  0360.00:C     KEYNU         KLIST
                // //                                  0361.00:C                   KFLD                    NUCOD1
                // //                                  0362.00:C                   KFLD                    NUCOD2
                // // FIXME [NUFILE]テーブルに悲観ロックが必要な可能性があります。必要な場合は最後の引数に「LockModeType.PESSIMISTIC_READ」を追加してください
                // nufileTemp = nufileDAO.selectFirstMatching(nufileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
//ndz-del-e
                offsetCtlNufile.offsetClear();
                if (nufileTemp != null) {
                    indicator.setIn80(false);
                    nufile = nufileTemp;
                } else {
                    indicator.setIn80(true);
                }
                if (indicator.getIn80() == true) {
                    if (indicator.getIn99() == false) {
                        indicator.setIn61(true);

                    }
                    indicator.setIn22(true);    // *UOS6621*
                    indicator.setIn99(true);
                } else {
                    if (nufile.getNunumb().equals(Utils.parseLong(99999999))) {
                        nufile.setNunumb(0L);
                        nufile.setNunumb(0l);
                    } else {
                        nufile.setNunumb(Utils.evaluateNumber(11, 0, nufile.getNunumb() + 1).longValue());

                    }
                    ds002.setWkref8(0);
                    ds002.setWkref8(Utils.evaluateNumber(8, 0, nufile.getNunumb()).intValue());
//ndz-del-s
                    // // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[UPDATE] original-code : 1738.00:C                   UPDATE    NURECD
                    // // FIXME [NUFILE]テーブルに悲観ロックが必要な可能性があります。必要な場合は手動変換で対応してください
                    // nufileDAO.update(nufile);
//ndz-del-e
                    fgfll1.setFgrefn(0L);
                    fgfll1.setFgrefn(Utils.evaluateNumber(11, 0, ds002.getWkrf11()).longValue());
                    fgfll1Key = new Fgfll1();
                    fgfll1Key.setFgrefn(fgfll1.getFgrefn());
                    fgfll1Temp = fgfll1DAO.selectFirstMatching(fgfll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
                    offsetCtlFgfll1.offsetClear();
                    if (fgfll1Temp != null) {
                        indicator.setIn81(false);
                        fgfll1 = fgfll1Temp;
                    } else {
                        indicator.setIn81(true);
                    }
                    if (indicator.getIn81() == true) {
                        ds002.setWkrefo(0L);
                        ds002.setWkrefo(Utils.evaluateNumber(11, 0, ds002.getWkrf11()).longValue());
                        ds008.setWoref3(0);
                        ds008.setWoref3(Utils.evaluateNumber(3, 0, ds002.getWkref3()).intValue());
                        ds008.setWoref1(Utils.movel(ds008.getWoref1(), 1, "-", 1));
                        ds008.setWoref8(0);
                        ds008.setWoref8(Utils.evaluateNumber(8, 0, ds002.getWkref8()).intValue());
                        wkrefn = 0L;
                        wkrefn = Utils.evaluateNumber(11, 0, ds002.getWkrefo()).longValue();

                    }

                }
            }
            while (!(!ds002.getWkrefo().equals(0l)));

        }

    }

    // ****************************************************
    // OP.NO AUTO COUNT UP PROCESS  ( OP.NO )   *
    // ****************************************************
    private void _2opaut() {
        if (_117702.get_1177o1().equals(0)) {
            do {
                _117702.set_1177i1(Utils.movel(_117702.get_1177i1(), 3, parm0.getPawsid(), 3));
                _1177();
                dto.setWsopno(Utils.move(dto.getWsopno(), 6, _117702.get_1177o1(), 6, 0));
                ds001.setWkopno(0);
                ds001.setWkopno(Utils.evaluateNumber(6, 0, _117702.get_1177o1()).intValue());
            }
            while (!(!_117702.get_1177o1().equals(0)));
        } else {
            dto.setWsopno(Utils.move(dto.getWsopno(), 6, _117702.get_1177o1(), 6, 0));
            ds001.setWkopno(0);
            ds001.setWkopno(Utils.evaluateNumber(6, 0, _117702.get_1177o1()).intValue());

        }

    }

    // ****************************************************
    // TTFILE  FIELD  SET  PROCESS              *
    // ****************************************************
    private void _2ttset() {
        ttfile = new Ttfile();
        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CLEAR] original-code : 1804.00:C                   CLEAR                   TTARA1
        // FIXME DSクラスの初期化は手動対応が必要です。
        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CLEAR] original-code : 1805.00:C                   CLEAR                   TTARA2
        // FIXME DSクラスの初期化は手動対応が必要です。
        /* TODO:Duplicate field [refnl2.setTtbrno()]*/ttfile.setTtbrno(0);
        /* TODO:Duplicate field [refnl2.setTtbrno()]*/ttfile.setTtbrno(Utils.evaluateNumber(3, 0, parm0.getPabrno()).intValue());
        /* TODO:Duplicate field [refnl2.setTtckno()]*/ttfile.setTtckno(0);
        /* TODO:Duplicate field [refnl2.setTtckno()]*/ttfile.setTtckno(Utils.evaluateNumber(5, 0, parm0.getPackno()).intValue());
        /* TODO:Duplicate field [refnl2.setTtcpu1()]*/ttfile.setTtcpu1(0);
        /* TODO:Duplicate field [refnl2.setTtcpu1()]*/ttfile.setTtcpu1(Utils.evaluateNumber(7, 0, parm0.getPatody()).intValue());
        /* TODO:Duplicate field [refnl2.setTtcpu2()]*/ttfile.setTtcpu2(0);
        /* TODO:Duplicate field [refnl2.setTtcpu2()]*/ttfile.setTtcpu2(Utils.evaluateNumber(5, 0, ds001.getWkopn1()).intValue());
        /* TODO:Duplicate field [refnl2.setTtcpu3()]*/ttfile.setTtcpu3(0);
        /* TODO:Duplicate field [refnl2.setTtcpu3()]*/ttfile.setTtcpu3(Utils.evaluateNumber(1, 0, ds001.getWkopn2()).intValue());
        /* TODO:Duplicate field [refnl2.setTtwsid()]*/ttfile.setTtwsid(Utils.movel(/* TODO:Duplicate field [refnl2.getTtwsid()]*/ttfile.getTtwsid(), 3, parm0.getPawsid(), 3));
        /* TODO:Duplicate field [refnl2.setTtusid()]*/ttfile.setTtusid(Utils.movel(/* TODO:Duplicate field [refnl2.getTtusid()]*/ttfile.getTtusid(), 2, parm0.getPausid(), 2));
        /* TODO:Duplicate field [refnl2.setTtusn1()]*/ttfile.setTtusn1(0);
        /* TODO:Duplicate field [refnl2.setTtusn1()]*/ttfile.setTtusn1(0);
        /* TODO:Duplicate field [refnl2.setTtusn2()]*/ttfile.setTtusn2(0);
        /* TODO:Duplicate field [refnl2.setTtusn2()]*/ttfile.setTtusn2(0);
        /* TODO:Duplicate field [refnl2.setTtostp()]*/ttfile.setTtostp(0);
        /* TODO:Duplicate field [refnl2.setTtostp()]*/ttfile.setTtostp(Utils.evaluateNumber(3, 0, 771).intValue());
        /* TODO:Duplicate field [refnl2.setTttrcd()]*/ttfile.setTttrcd(0);
        /* TODO:Duplicate field [refnl2.setTttrcd()]*/ttfile.setTttrcd(Utils.evaluateNumber(3, 0, dto.getWstrcd()).intValue());
        /* TODO:Duplicate field [refnl2.setTtcanf()]*/ttfile.setTtcanf(Utils.movel(/* TODO:Duplicate field [refnl2.getTtcanf()]*/ttfile.getTtcanf(), 1, parm0.getPacd01(), 1));
        /* TODO:Duplicate field [refnl2.setTtzprf()]*/ttfile.setTtzprf(Utils.movel(/* TODO:Duplicate field [refnl2.getTtzprf()]*/ttfile.getTtzprf(), 1, "0", 1));
        /* TODO:Duplicate field [refnl2.setTtconf()]*/ttfile.setTtconf(" ");
        /* TODO:Duplicate field [refnl2.setTtcal1()]*/ttfile.setTtcal1(" ");
        /* TODO:Duplicate field [refnl2.setTtcal2()]*/ttfile.setTtcal2(" ");
        /* TODO:Duplicate field [refnl2.setTtcal3()]*/ttfile.setTtcal3(" ");
        /* TODO:Duplicate field [refnl2.setTtcal4()]*/ttfile.setTtcal4(" ");
        /* TODO:Duplicate field [refnl2.setTthash()]*/ttfile.setTthash(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTthash()]*/ttfile.setTthash(Utils.evaluateNumber(15, 2, dto.getWsamnt()));
        /* TODO:Duplicate field [refnl2.setTtindt()]*/ttfile.setTtindt(0);
        /* TODO:Duplicate field [refnl2.setTtindt()]*/ttfile.setTtindt(Utils.evaluateNumber(7, 0, parm0.getPatody()).intValue());
        ds005.setWksec1(Utils.evaluateNumber(15, 0, ds003.getWkh01() * 3600).longValue());
        ds005.setWksecw(Utils.evaluateNumber(15, 0, ds003.getWkm01() * 60).longValue());
        ds005.setWksec1(Utils.evaluateNumber(15, 0, ds005.getWksec1() + ds005.getWksecw()).longValue());
        ds005.setWksec1(Utils.evaluateNumber(15, 0, ds005.getWksec1() + ds003.getWks01()).longValue());
        ds005.setWksec2(Utils.evaluateNumber(15, 0, ds004.getWkh02() * 3600).longValue());
        ds005.setWksecw(Utils.evaluateNumber(15, 0, ds004.getWkm02() * 60).longValue());
        ds005.setWksec2(Utils.evaluateNumber(15, 0, ds005.getWksec2() + ds005.getWksecw()).longValue());
        ds005.setWksec2(Utils.evaluateNumber(15, 0, ds005.getWksec2() + ds004.getWks02()).longValue());
        /* TODO:Duplicate field [refnl2.setTtprtm()]*/ttfile.setTtprtm(Utils.evaluateNumber(3, 0, ds005.getWksec2() - ds005.getWksec1()).intValue());
        /* TODO:Duplicate field [refnl2.setTtvldt()]*/ttfile.setTtvldt(0);
        /* TODO:Duplicate field [refnl2.setTtvldt()]*/ttfile.setTtvldt(Utils.evaluateNumber(7, 0, wkvldt).intValue());
        /* TODO:Duplicate field [refnl2.setTtdat1()]*/ttfile.setTtdat1(0);
        /* TODO:Duplicate field [refnl2.setTtdat1()]*/ttfile.setTtdat1(0);
        /* TODO:Duplicate field [refnl2.setTtdat2()]*/ttfile.setTtdat2(0);
        /* TODO:Duplicate field [refnl2.setTtdat2()]*/ttfile.setTtdat2(0);
        /* TODO:Duplicate field [refnl2.setTtdat3()]*/ttfile.setTtdat3(0);
        /* TODO:Duplicate field [refnl2.setTtdat3()]*/ttfile.setTtdat3(0);
        /* TODO:Duplicate field [refnl2.setTtocd1()]*/ttfile.setTtocd1(0);
        /* TODO:Duplicate field [refnl2.setTtocd1()]*/ttfile.setTtocd1(0);
        /* TODO:Duplicate field [refnl2.setTtcur1()]*/ttfile.setTtcur1(0);
        /* TODO:Duplicate field [refnl2.setTtcur1()]*/ttfile.setTtcur1(0);
        /* TODO:Duplicate field [refnl2.setTtdra1()]*/ttfile.setTtdra1(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtdra1()]*/ttfile.setTtdra1(Utils.evaluateNumber(15, 2, 0));
        /* TODO:Duplicate field [refnl2.setTtcra1()]*/ttfile.setTtcra1(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtcra1()]*/ttfile.setTtcra1(Utils.evaluateNumber(15, 2, 0));
        /* TODO:Duplicate field [refnl2.setTtocd2()]*/ttfile.setTtocd2(0);
        /* TODO:Duplicate field [refnl2.setTtocd2()]*/ttfile.setTtocd2(0);
        /* TODO:Duplicate field [refnl2.setTtcur2()]*/ttfile.setTtcur2(0);
        /* TODO:Duplicate field [refnl2.setTtcur2()]*/ttfile.setTtcur2(0);
        /* TODO:Duplicate field [refnl2.setTtdra2()]*/ttfile.setTtdra2(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtdra2()]*/ttfile.setTtdra2(Utils.evaluateNumber(15, 2, 0));
        /* TODO:Duplicate field [refnl2.setTtcra2()]*/ttfile.setTtcra2(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtcra2()]*/ttfile.setTtcra2(Utils.evaluateNumber(15, 2, 0));
        /* TODO:Duplicate field [refnl2.setTtocd3()]*/ttfile.setTtocd3(Utils.movel(/* TODO:Duplicate field [refnl2.getTtocd3()]*/ttfile.getTtocd3(), 1, 0, dto.getWsoscd(), 1).intValue());
        /* TODO:Duplicate field [refnl2.setTtcur3()]*/ttfile.setTtcur3(0);
        /* TODO:Duplicate field [refnl2.setTtcur3()]*/ttfile.setTtcur3(Utils.evaluateNumber(3, 0, wkcode).intValue());
        /* TODO:Duplicate field [refnl2.setTtact3()]*/ttfile.setTtact3(0);
        /* TODO:Duplicate field [refnl2.setTtact3()]*/ttfile.setTtact3(Utils.evaluateNumber(7, 0, wkact3).intValue());
        /* TODO:Duplicate field [refnl2.setTtcst3()]*/ttfile.setTtcst3(0);
        /* TODO:Duplicate field [refnl2.setTtcst3()]*/ttfile.setTtcst3(0);
        /* TODO:Duplicate field [refnl2.setTtacb3()]*/ttfile.setTtacb3(0);
        /* TODO:Duplicate field [refnl2.setTtacb3()]*/ttfile.setTtacb3(0);
        if (dto.getWstrcd().equals(63)) {
            if (Utils.rTrim(wkdrcr).equals(Utils.rTrim("1"))) {
                /* TODO:Duplicate field [refnl2.setTtdrc3()]*/ttfile.setTtdrc3(Utils.movel(/* TODO:Duplicate field [refnl2.getTtdrc3()]*/ttfile.getTtdrc3(), 1, "2", 1));

            }
            if (Utils.rTrim(wkdrcr).equals(Utils.rTrim("2"))) {
                /* TODO:Duplicate field [refnl2.setTtdrc3()]*/ttfile.setTtdrc3(Utils.movel(/* TODO:Duplicate field [refnl2.getTtdrc3()]*/ttfile.getTtdrc3(), 1, "1", 1));

            }
        } else {
            /* TODO:Duplicate field [refnl2.setTtdrc3()]*/ttfile.setTtdrc3(Utils.movel(/* TODO:Duplicate field [refnl2.getTtdrc3()]*/ttfile.getTtdrc3(), 1, wkdrcr, 1));

        }
        /* TODO:Duplicate field [refnl2.setTtamt3()]*/ttfile.setTtamt3(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtamt3()]*/ttfile.setTtamt3(Utils.evaluateNumber(15, 2, dto.getWsamnt()));
        /* TODO:Duplicate field [refnl2.setTtocd4()]*/ttfile.setTtocd4(0);
        /* TODO:Duplicate field [refnl2.setTtocd4()]*/ttfile.setTtocd4(Utils.evaluateNumber(1, 0, wkocd4).intValue());
        /* TODO:Duplicate field [refnl2.setTtcur4()]*/ttfile.setTtcur4(0);
        /* TODO:Duplicate field [refnl2.setTtcur4()]*/ttfile.setTtcur4(Utils.evaluateNumber(3, 0, wkcur4).intValue());
        /* TODO:Duplicate field [refnl2.setTtact4()]*/ttfile.setTtact4(0);
        /* TODO:Duplicate field [refnl2.setTtact4()]*/ttfile.setTtact4(Utils.evaluateNumber(7, 0, w108o3).intValue());
        if (Utils.rTrim(wkamcd).equals(Utils.rTrim(" "))) {
            /* TODO:Duplicate field [refnl2.setTtcst4()]*/ttfile.setTtcst4(0);
            /* TODO:Duplicate field [refnl2.setTtcst4()]*/ttfile.setTtcst4(0);
        } else {
            if (Utils.rTrim(wkamcd).equals(Utils.rTrim("3"))) {
                /* TODO:Duplicate field [refnl2.setTtcst4()]*/ttfile.setTtcst4(0);
                /* TODO:Duplicate field [refnl2.setTtcst4()]*/ttfile.setTtcst4(Utils.evaluateNumber(7, 0, wknsbc).intValue());
            } else {
                /* TODO:Duplicate field [refnl2.setTtcst4()]*/ttfile.setTtcst4(0);
                /* TODO:Duplicate field [refnl2.setTtcst4()]*/ttfile.setTtcst4(Utils.evaluateNumber(7, 0, wkcust).intValue());

            }

        }
        /* TODO:Duplicate field [refnl2.setTtacb4()]*/ttfile.setTtacb4(0);
        /* TODO:Duplicate field [refnl2.setTtacb4()]*/ttfile.setTtacb4(Utils.evaluateNumber(3, 0, w108o4).intValue());
        if (Utils.rTrim(/* TODO:Duplicate field [refnl2.getTtdrc3()]*/ttfile.getTtdrc3()).equals(Utils.rTrim("1"))) {
            /* TODO:Duplicate field [refnl2.setTtdrc4()]*/ttfile.setTtdrc4("2");
        } else {
            /* TODO:Duplicate field [refnl2.setTtdrc4()]*/ttfile.setTtdrc4("1");

        }
        /* TODO:Duplicate field [refnl2.setTtamt4()]*/ttfile.setTtamt4(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtamt4()]*/ttfile.setTtamt4(Utils.evaluateNumber(15, 2, dto.getWsamnt()));
        _2blnck();    // BALANCE CHECK
        /* TODO:Duplicate field [refnl2.setTtocd5()]*/ttfile.setTtocd5(0);
        /* TODO:Duplicate field [refnl2.setTtocd5()]*/ttfile.setTtocd5(Utils.evaluateNumber(1, 0, parma5.getP5ofc5()).intValue());
        /* TODO:Duplicate field [refnl2.setTtcur5()]*/ttfile.setTtcur5(0);
        /* TODO:Duplicate field [refnl2.setTtcur5()]*/ttfile.setTtcur5(Utils.evaluateNumber(3, 0, parma5.getP5cur5()).intValue());
        /* TODO:Duplicate field [refnl2.setTtact5()]*/ttfile.setTtact5(0);
        /* TODO:Duplicate field [refnl2.setTtact5()]*/ttfile.setTtact5(Utils.evaluateNumber(7, 0, parma5.getP5ac91()).intValue());
        /* TODO:Duplicate field [refnl2.setTtcst5()]*/ttfile.setTtcst5(0);
        /* TODO:Duplicate field [refnl2.setTtcst5()]*/ttfile.setTtcst5(0);
        /* TODO:Duplicate field [refnl2.setTtacb5()]*/ttfile.setTtacb5(0);
        /* TODO:Duplicate field [refnl2.setTtacb5()]*/ttfile.setTtacb5(0);
        /* TODO:Duplicate field [refnl2.setTtdrc5()]*/ttfile.setTtdrc5(Utils.movel(/* TODO:Duplicate field [refnl2.getTtdrc5()]*/ttfile.getTtdrc5(), 1, parma5.getP5dc91(), 1));
        /* TODO:Duplicate field [refnl2.setTtamt5()]*/ttfile.setTtamt5(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtamt5()]*/ttfile.setTtamt5(Utils.evaluateNumber(15, 2, parma5.getP5am91()));
        /* TODO:Duplicate field [refnl2.setTtirt1()]*/ttfile.setTtirt1(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtirt1()]*/ttfile.setTtirt1(Utils.evaluateNumber(9, 7, 0));
        /* TODO:Duplicate field [refnl2.setTtirt2()]*/ttfile.setTtirt2(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtirt2()]*/ttfile.setTtirt2(Utils.evaluateNumber(9, 7, 0));
        /* TODO:Duplicate field [refnl2.setTtrefn()]*/ttfile.setTtrefn(0L);
        /* TODO:Duplicate field [refnl2.setTtrefn()]*/ttfile.setTtrefn(Utils.evaluateNumber(11, 0, wkrefn).longValue());
        /* TODO:Duplicate field [refnl2.setTtrefb()]*/ttfile.setTtrefb(0L);
        /* TODO:Duplicate field [refnl2.setTtrefb()]*/ttfile.setTtrefb(Utils.evaluateNumber(11, 0, ds009.getWkrefb()).longValue());
        /* TODO:Duplicate field [refnl2.setTtdupf()]*/ttfile.setTtdupf(Utils.movel(/* TODO:Duplicate field [refnl2.getTtdupf()]*/ttfile.getTtdupf(), 1, "1", 1));
        /* TODO:Duplicate field [refnl2.setTtmtid()]*/ttfile.setTtmtid(" ");
        /* TODO:Duplicate field [refnl2.setTtfg01()]*/ttfile.setTtfg01(" ");
        /* TODO:Duplicate field [refnl2.setTtfg02()]*/ttfile.setTtfg02(" ");
        /* TODO:Duplicate field [refnl2.setTtseqn()]*/ttfile.setTtseqn(0);
        /* TODO:Duplicate field [refnl2.setTtseqn()]*/ttfile.setTtseqn(0);
        /* TODO:Duplicate field [refnl2.setTtrtyp()]*/ttfile.setTtrtyp(Utils.movel(/* TODO:Duplicate field [refnl2.getTtrtyp()]*/ttfile.getTtrtyp(), 1, "1", 1));
        /* TODO:Duplicate field [refnl2.setTtcmdt()]*/ttfile.setTtcmdt("          ");
        /* TODO:Duplicate field [refnl2.setTtsect()]*/ttfile.setTtsect(Utils.movel(/* TODO:Duplicate field [refnl2.getTtsect()]*/ttfile.getTtsect(), 3, parm0.getPasect(), 3));
        /* TODO:Duplicate field [refnl2.setTtdler()]*/ttfile.setTtdler("  ");
        /* TODO:Duplicate field [refnl2.setTtpotq()]*/ttfile.setTtpotq(Utils.movel(/* TODO:Duplicate field [refnl2.getTtpotq()]*/ttfile.getTtpotq(), 3, parm0.getPapotq(), 3));
        /* TODO:Duplicate field [refnl2.setTtcotq()]*/ttfile.setTtcotq(Utils.movel(/* TODO:Duplicate field [refnl2.getTtcotq()]*/ttfile.getTtcotq(), 3, parm0.getPacotq(), 3));
        /* TODO:Duplicate field [refnl2.setTtoutq()]*/ttfile.setTtoutq(Utils.movel(/* TODO:Duplicate field [refnl2.getTtoutq()]*/ttfile.getTtoutq(), 3, parm0.getPaoutq(), 3));
        /* TODO:Duplicate field [refnl2.setTtccfg()]*/ttfile.setTtccfg(" ");
        /* TODO:Duplicate field [refnl2.setTtttst()]*/ttfile.setTtttst(0);
        /* TODO:Duplicate field [refnl2.setTtttst()]*/ttfile.setTtttst(Utils.evaluateNumber(7, 0, wktime).intValue());
        /* TODO:Duplicate field [refnl2.setTttted()]*/ttfile.setTttted(0);
        /* TODO:Duplicate field [refnl2.setTttted()]*/ttfile.setTttted(0);
        /* TODO:Duplicate field [refnl2.setTttmst()]*/ttfile.setTttmst(0);
        /* TODO:Duplicate field [refnl2.setTttmst()]*/ttfile.setTttmst(0);
        /* TODO:Duplicate field [refnl2.setTttmed()]*/ttfile.setTttmed(0);
        /* TODO:Duplicate field [refnl2.setTttmed()]*/ttfile.setTttmed(0);
        /* TODO:Duplicate field [refnl2.setTtprst()]*/ttfile.setTtprst(0);
        /* TODO:Duplicate field [refnl2.setTtprst()]*/ttfile.setTtprst(0);
        /* TODO:Duplicate field [refnl2.setTtpred()]*/ttfile.setTtpred(0);
        /* TODO:Duplicate field [refnl2.setTtpred()]*/ttfile.setTtpred(0);
        /* TODO:Duplicate field [refnl2.setTtiplr()]*/ttfile.setTtiplr(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtiplr()]*/ttfile.setTtiplr(Utils.evaluateNumber(15, 7, 0));
        /* TODO:Duplicate field [refnl2.setTteplr()]*/ttfile.setTteplr(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTteplr()]*/ttfile.setTteplr(Utils.evaluateNumber(15, 7, 0));
        /* TODO:Duplicate field [refnl2.setTtvrno()]*/ttfile.setTtvrno("       ");
        /* TODO:Duplicate field [refnl2.setTtts11()]*/ttfile.setTtts11(0);
        /* TODO:Duplicate field [refnl2.setTtts11()]*/ttfile.setTtts11(Utils.evaluateNumber(7, 0, wkusn1).intValue());
        /* TODO:Duplicate field [refnl2.setTtts12()]*/ttfile.setTtts12(0);
        /* TODO:Duplicate field [refnl2.setTtts12()]*/ttfile.setTtts12(Utils.evaluateNumber(5, 0, wkusn2).intValue());
        /* TODO:Duplicate field [refnl2.setTtts21()]*/ttfile.setTtts21(0);
        /* TODO:Duplicate field [refnl2.setTtts21()]*/ttfile.setTtts21(0);
        /* TODO:Duplicate field [refnl2.setTtts22()]*/ttfile.setTtts22(0);
        /* TODO:Duplicate field [refnl2.setTtts22()]*/ttfile.setTtts22(0);
        /* TODO:Duplicate field [refnl2.setTtts31()]*/ttfile.setTtts31(0);
        /* TODO:Duplicate field [refnl2.setTtts31()]*/ttfile.setTtts31(0);
        /* TODO:Duplicate field [refnl2.setTtts32()]*/ttfile.setTtts32(0);
        /* TODO:Duplicate field [refnl2.setTtts32()]*/ttfile.setTtts32(0);
        /* TODO:Duplicate field [refnl2.setTtas11()]*/ttfile.setTtas11(0);
        /* TODO:Duplicate field [refnl2.setTtas11()]*/ttfile.setTtas11(0);
        /* TODO:Duplicate field [refnl2.setTtas12()]*/ttfile.setTtas12(0);
        /* TODO:Duplicate field [refnl2.setTtas12()]*/ttfile.setTtas12(0);
        /* TODO:Duplicate field [refnl2.setTtas21()]*/ttfile.setTtas21(0);
        /* TODO:Duplicate field [refnl2.setTtas21()]*/ttfile.setTtas21(0);
        /* TODO:Duplicate field [refnl2.setTtas22()]*/ttfile.setTtas22(0);
        /* TODO:Duplicate field [refnl2.setTtas22()]*/ttfile.setTtas22(0);
        /* TODO:Duplicate field [refnl2.setTtas31()]*/ttfile.setTtas31(0);
        /* TODO:Duplicate field [refnl2.setTtas31()]*/ttfile.setTtas31(0);
        /* TODO:Duplicate field [refnl2.setTtas32()]*/ttfile.setTtas32(0);
        /* TODO:Duplicate field [refnl2.setTtas32()]*/ttfile.setTtas32(0);
        /* TODO:Duplicate field [refnl2.setTterid()]*/ttfile.setTterid(" ");
        /* TODO:Duplicate field [refnl2.setTtodam()]*/ttfile.setTtodam(BigDecimal.ZERO);
        /* TODO:Duplicate field [refnl2.setTtodam()]*/ttfile.setTtodam(Utils.evaluateNumber(15, 2, 0));
        /* TODO:Duplicate field [refnl2.setTtcmmt()]*/ttfile.setTtcmmt(" ");
        /* TODO:Duplicate field [refnl2.setTthln1()]*/ttfile.setTthln1(0);
        /* TODO:Duplicate field [refnl2.setTthln1()]*/ttfile.setTthln1(0);
        /* TODO:Duplicate field [refnl2.setTthln2()]*/ttfile.setTthln2(0);
        /* TODO:Duplicate field [refnl2.setTthln2()]*/ttfile.setTthln2(0);
        /* TODO:Duplicate field [refnl2.setTthln3()]*/ttfile.setTthln3(0);
        /* TODO:Duplicate field [refnl2.setTthln3()]*/ttfile.setTthln3(0);
        /* TODO:Duplicate field [refnl2.setTthln4()]*/ttfile.setTthln4(0);
        /* TODO:Duplicate field [refnl2.setTthln4()]*/ttfile.setTthln4(0);
        /* TODO:Duplicate field [refnl2.setTthln5()]*/ttfile.setTthln5(0);
        /* TODO:Duplicate field [refnl2.setTthln5()]*/ttfile.setTthln5(0);
        /* TODO:Duplicate field [refnl2.setTtsfg1()]*/ttfile.setTtsfg1(" ");
        /* TODO:Duplicate field [refnl2.setTtsfg2()]*/ttfile.setTtsfg2(" ");
        /* TODO:Duplicate field [refnl2.setTtsfg3()]*/ttfile.setTtsfg3(" ");
        /* TODO:Duplicate field [refnl2.setTtsfg4()]*/ttfile.setTtsfg4(" ");
        /* TODO:Duplicate field [refnl2.setTtsfg5()]*/ttfile.setTtsfg5(" ");
        /* TODO:Duplicate field [refnl2.setTtufg1()]*/ttfile.setTtufg1(" ");
        /* TODO:Duplicate field [refnl2.setTtufg2()]*/ttfile.setTtufg2(" ");
        /* TODO:Duplicate field [refnl2.setTtufg3()]*/ttfile.setTtufg3(" ");
        /* TODO:Duplicate field [refnl2.setTtufg4()]*/ttfile.setTtufg4(" ");
        /* TODO:Duplicate field [refnl2.setTtufg5()]*/ttfile.setTtufg5(" ");
        /* TODO:Duplicate field [refnl2.setTtustf()]*/ttfile.setTtustf(Utils.movel(/* TODO:Duplicate field [refnl2.getTtustf()]*/ttfile.getTtustf(), 1, "0", 1));
        /* TODO:Duplicate field [refnl2.setTtuenf()]*/ttfile.setTtuenf(Utils.movel(/* TODO:Duplicate field [refnl2.getTtuenf()]*/ttfile.getTtuenf(), 1, "0", 1));
        /* TODO:Duplicate field [refnl2.setTtuspf()]*/ttfile.setTtuspf(Utils.movel(/* TODO:Duplicate field [refnl2.getTtuspf()]*/ttfile.getTtuspf(), 1, "0", 1));
        /* TODO:Duplicate field [refnl2.setTtlstf()]*/ttfile.setTtlstf(Utils.movel(/* TODO:Duplicate field [refnl2.getTtlstf()]*/ttfile.getTtlstf(), 1, "0", 1));
        /* TODO:Duplicate field [refnl2.setTtlenf()]*/ttfile.setTtlenf(Utils.movel(/* TODO:Duplicate field [refnl2.getTtlenf()]*/ttfile.getTtlenf(), 1, "0", 1));
        /* TODO:Duplicate field [refnl2.setTtlspf()]*/ttfile.setTtlspf(Utils.movel(/* TODO:Duplicate field [refnl2.getTtlspf()]*/ttfile.getTtlspf(), 1, "0", 1));
        /* TODO:Duplicate field [refnl2.setTtitfc()]*/ttfile.setTtitfc("                                                  ");
        // ** RESERV AREA (1)
        ttara1.setTtocd6(0);
        ttara1.setTtocd6(Utils.evaluateNumber(1, 0, parma5.getP5ofc6()).intValue());
        ttara1.setTtcur6(0);
        ttara1.setTtcur6(Utils.evaluateNumber(3, 0, parma5.getP5cur6()).intValue());
        ttara1.setTtact6(0);
        ttara1.setTtact6(Utils.evaluateNumber(7, 0, parma5.getP5ac92()).intValue());
        ttara1.setTtcst6(0);
        ttara1.setTtcst6(0);
        ttara1.setTtacb6(0);
        ttara1.setTtacb6(0);
        ttara1.setTtdrc6(Utils.movel(ttara1.getTtdrc6(), 1, parma5.getP5dc92(), 1));
        ttara1.setTtamt6(BigDecimal.ZERO);
        ttara1.setTtamt6(Utils.evaluateNumber(15, 2, parma5.getP5am92()));
        ttara1.setTtfecd(Utils.movel(ttara1.getTtfecd(), 4, dto.getWsfecd(), 4));
        ttara1.setTtfcfm(0);
        ttara1.setTtfcfm(Utils.evaluateNumber(7, 0, wkfcfm).intValue());
        ttara1.setTtfcto(0);
        ttara1.setTtfcto(Utils.evaluateNumber(7, 0, wkfcto).intValue());
        ttara1.setTtsbcd(" ");
        ttara1.setTtlref(0L);
        ttara1.setTtlref(Utils.evaluateNumber(11, 0, ds010.getWklref()).longValue());
        ttara1.setTtapno(Utils.movel(ttara1.getTtapno(), 14, dto.getWsapno(), 14));
        ttara1.setTtcust(0);
        ttara1.setTtcust(Utils.evaluateNumber(7, 0, wkcust).intValue());
        ttara1.setTtvatc(Utils.movel(ttara1.getTtvatc(), 1, dto.getWsvatc(), 1));
        ttara1.setTtacrf(Utils.movel(ttara1.getTtacrf(), 1, dto.getWsacrf(), 1));
        ttara1.setTtrate(BigDecimal.ZERO);
        ttara1.setTtrate(Utils.evaluateNumber(9, 7, dto.getWsrate()));
        ttara1.setTtsprd(BigDecimal.ZERO);
        ttara1.setTtsprd(Utils.evaluateNumber(9, 7, dto.getWssprd()));
        ttara1.setTtccd1(Utils.movel(ttara1.getTtccd1(), 1, dto.getWsccd1(), 1));
        ttara1.setTtccd2(Utils.movel(ttara1.getTtccd2(), 1, dto.getWsccd2(), 1));
        ttara1.setTtrmks(Utils.movel(ttara1.getTtrmks(), 60, ds011.getWsrmks(), 60));
        ttara1.setTtthei(Utils.movel(ttara1.getTtthei(), 15, dto.getWsthei(), 15));
        ttara1.setTtflag(Utils.movel(ttara1.getTtflag(), 10, ds012.getWsflag(), 10));
        ttara1.setTthgfg(Utils.movel(ttara1.getTthgfg(), 1, wkac05, 1));
        ttara1.setTtterm(Utils.movel(ttara1.getTtterm(), 1, parm0.getPastlf(), 1));
        ttara1.setTtcr01(Utils.movel(ttara1.getTtcr01(), 1, "0", 1));
        ttara1.setTtcr02(Utils.movel(ttara1.getTtcr02(), 1, "0", 1));
        ttara1.setTtcr03(Utils.movel(ttara1.getTtcr03(), 1, "0", 1));
        ttara1.setTtcr04(Utils.movel(ttara1.getTtcr04(), 1, "0", 1));
        ttara1.setTtcr05(Utils.movel(ttara1.getTtcr05(), 1, "0", 1));
        ttara1.setTtcr06(Utils.movel(ttara1.getTtcr06(), 1, "0", 1));
        ttara1.setTtcr07(Utils.movel(ttara1.getTtcr07(), 1, "0", 1));
        ttara1.setTtcr08(Utils.movel(ttara1.getTtcr08(), 1, "0", 1));
        ttara1.setTtcr09(Utils.movel(ttara1.getTtcr09(), 1, "0", 1));
        ttara1.setTtcr10(Utils.movel(ttara1.getTtcr10(), 1, "0", 1));
        ttara1.setTtcr11(Utils.movel(ttara1.getTtcr11(), 1, "0", 1));
        ttara1.setTtcr12(Utils.movel(ttara1.getTtcr12(), 1, "0", 1));
        ttara1.setTtcr13(Utils.movel(ttara1.getTtcr13(), 1, "0", 1));
        ttara1.setTtcr14(Utils.movel(ttara1.getTtcr14(), 1, "0", 1));
        ttara1.setTtcr15(Utils.movel(ttara1.getTtcr15(), 1, "0", 1));
        ttara1.setTtcr16(Utils.movel(ttara1.getTtcr16(), 1, "0", 1));
        ttara1.setTtcr17(Utils.movel(ttara1.getTtcr17(), 1, "0", 1));
        ttara1.setTtcr18(Utils.movel(ttara1.getTtcr18(), 1, "0", 1));
        ttara1.setTtcr19(Utils.movel(ttara1.getTtcr19(), 1, "0", 1));
        ttara1.setTtcr20(Utils.movel(ttara1.getTtcr20(), 1, "0", 1));
        ttara1.setTtcr21(Utils.movel(ttara1.getTtcr21(), 1, "0", 1));
        if (dto.getWstrcd().equals(61)) {
            if (!Utils.rTrim(dto.getWsfecd()).equals(Utils.rTrim(wkofcd))) {
                ttara1.setTtcr01(Utils.movel(ttara1.getTtcr01(), 1, "1", 1));

            }
            if (!wkfcfm.equals(wkoffm)) {
                ttara1.setTtcr02(Utils.movel(ttara1.getTtcr02(), 1, "1", 1));

            }
            if (!wkfcto.equals(wkofto)) {
                ttara1.setTtcr03(Utils.movel(ttara1.getTtcr03(), 1, "1", 1));

            }
            if (dto.getWsamnt().compareTo(wkofam) != 0) {
                ttara1.setTtcr04(Utils.movel(ttara1.getTtcr04(), 1, "1", 1));

            }
            if (!dto.getWsacno().equals(wkofac)) {
                ttara1.setTtcr05(Utils.movel(ttara1.getTtcr05(), 1, "1", 1));

            }
            if (!Utils.rTrim(dto.getWsnsos()).equals(Utils.rTrim(wkonos))) {
                ttara1.setTtcr07(Utils.movel(ttara1.getTtcr07(), 1, "1", 1));

            }
            if (!Utils.rTrim(dto.getWsnsac()).equals(Utils.rTrim(wkonac))) {
                ttara1.setTtcr08(Utils.movel(ttara1.getTtcr08(), 1, "1", 1));

            }
            if (!Utils.rTrim(dto.getWsnsbk()).equals(Utils.rTrim(wkonbn))) {
                ttara1.setTtcr09(Utils.movel(ttara1.getTtcr09(), 1, "1", 1));

            }
            if (!ds010.getWklref().equals(wkolrf)) {
                ttara1.setTtcr10(Utils.movel(ttara1.getTtcr10(), 1, "1", 1));

            }
            if (!Utils.rTrim(dto.getWsapno()).equals(Utils.rTrim(wkoapn))) {
                ttara1.setTtcr11(Utils.movel(ttara1.getTtcr11(), 1, "1", 1));

            }
            if (!Utils.rTrim(dto.getWscust()).equals(Utils.rTrim(wkoctb))) {
                ttara1.setTtcr12(Utils.movel(ttara1.getTtcr12(), 1, "1", 1));

            }
            if (!Utils.rTrim(dto.getWsvatc()).equals(Utils.rTrim(wkovat))) {
                ttara1.setTtcr13(Utils.movel(ttara1.getTtcr13(), 1, "1", 1));

            }
            if (!Utils.rTrim(dto.getWsacrf()).equals(Utils.rTrim(wkoarf))) {
                ttara1.setTtcr14(Utils.movel(ttara1.getTtcr14(), 1, "1", 1));

            }
            if (dto.getWsrate().compareTo(wkorat) != 0) {
                ttara1.setTtcr15(Utils.movel(ttara1.getTtcr15(), 1, "1", 1));

            }
            if (dto.getWssprd().compareTo(wkospr) != 0) {
                ttara1.setTtcr16(Utils.movel(ttara1.getTtcr16(), 1, "1", 1));

            }
            if (!Utils.rTrim(dto.getWsccd1()).equals(Utils.rTrim(wkocc1))) {
                ttara1.setTtcr17(Utils.movel(ttara1.getTtcr17(), 1, "1", 1));

            }
            if (!Utils.rTrim(dto.getWsccd2()).equals(Utils.rTrim(wkocc2))) {
                ttara1.setTtcr18(Utils.movel(ttara1.getTtcr18(), 1, "1", 1));

            }
            if (!Utils.rTrim(ds011.getWsrmks()).equals(Utils.rTrim(wkormk))) {
                ttara1.setTtcr19(Utils.movel(ttara1.getTtcr19(), 1, "1", 1));

            }
            if (!Utils.rTrim(dto.getWsthei()).equals(Utils.rTrim(wkothe))) {
                ttara1.setTtcr20(Utils.movel(ttara1.getTtcr20(), 1, "1", 1));

            }
            if (!Utils.rTrim(ds012.getWsflag()).equals(Utils.rTrim(wkoflg))) {
                ttara1.setTtcr21(Utils.movel(ttara1.getTtcr21(), 1, "1", 1));

            }

        }
        ttara1.setTter01(" ");
        if (/* TODO:Duplicate field [refnl2.getTttrcd()]*/ttfile.getTttrcd().equals(63)) {
            _2dmget();    // *DMCPU GET
            ttara1.setTtarx1(Utils.movel(ttara1.getTtarx1(), 192, ds013.getWkarx1(), 192));

        }
        // ** RESERV AREA (2)
        ttara2.setTtcynm(Utils.movel(ttara2.getTtcynm(), 3, dto.getWscycd(), 3));
        ttara2.setTtfenm(Utils.movel(ttara2.getTtfenm(), 15, dto.getWsfenm(), 15));
        ttara2.setTtfacc(0);
        ttara2.setTtfacc(Utils.evaluateNumber(7, 0, dto.getWsacno()).intValue());
        ttara2.setTtfacn(Utils.movel(ttara2.getTtfacn(), 20, dto.getWsacnm(), 20));
        ttara2.setTt1cyn(Utils.movel(ttara2.getTt1cyn(), 3, dto.getWsnscy(), 3));
        ttara2.setTt1aci(Utils.movel(ttara2.getTt1aci(), 10, dto.getWsnsac(), 10));
        if (!dto.getWsnsab().equals(0)) {
            ttara2.setTt1acb(Utils.move(ttara2.getTt1acb(), 2, dto.getWsnsab(), 2, 0));

        }
        ttara2.setTt1acc(0);
        ttara2.setTt1acc(Utils.evaluateNumber(7, 0, wkexcd).intValue());
        ttara2.setTt1acn(Utils.movel(ttara2.getTt1acn(), 20, dto.getWsnsan(), 20));
        ttara2.setTt1bkc(0);
        ttara2.setTt1bkc(Utils.evaluateNumber(7, 0, wknsbc).intValue());
        ttara2.setTt1bkn(Utils.movel(ttara2.getTt1bkn(), 18, dto.getWsnsbk(), 18));
        ttara2.setTtcsti(Utils.movel(ttara2.getTtcsti(), 18, dto.getWscust(), 18));
        ttara2.setTtcnm1(Utils.movel(ttara2.getTtcnm1(), 40, wkcnm1, 40));
        ttara2.setTtcnm2(Utils.movel(ttara2.getTtcnm2(), 40, wkcnm2, 40));
        ttara2.setTt2cyn("   ");
        ttara2.setTt2aci("          ");
        ttara2.setTt2acb("  ");
        ttara2.setTt2acc(0);
        ttara2.setTt2acc(0);
        ttara2.setTt2acn("                    ");
        ttara2.setTt2bkc(0);
        ttara2.setTt2bkc(0);
        ttara2.setTt2bkn("                  ");
        ttara2.setTticy1(Utils.movel(ttara2.getTticy1(), 3, dto.getWscycd(), 3));
        ttara2.setTtiae1(0);
        ttara2.setTtiae1(Utils.evaluateNumber(7, 0, parma5.getP5ec91()).intValue());
        ttara2.setTtian1(Utils.movel(ttara2.getTtian1(), 20, parma5.getP5an91(), 20));
        ttara2.setTticy2(Utils.movel(ttara2.getTticy2(), 3, dto.getWscycd(), 3));
        ttara2.setTtiae2(0);
        ttara2.setTtiae2(Utils.evaluateNumber(7, 0, parma5.getP5ec92()).intValue());
        ttara2.setTtian2(Utils.movel(ttara2.getTtian2(), 20, parma5.getP5an92(), 20));
        ttara2.setTtofcd(Utils.movel(ttara2.getTtofcd(), 4, wkofcd, 4));
        ttara2.setTtofnm(Utils.movel(ttara2.getTtofnm(), 15, wkofnm, 15));
        ttara2.setTtoffm(0);
        ttara2.setTtoffm(Utils.evaluateNumber(7, 0, wkoffm).intValue());
        ttara2.setTtofto(0);
        ttara2.setTtofto(Utils.evaluateNumber(7, 0, wkofto).intValue());
        ttara2.setTtofam(BigDecimal.ZERO);
        ttara2.setTtofam(Utils.evaluateNumber(15, 2, wkofam));
        ttara2.setTtofac(0);
        ttara2.setTtofac(Utils.evaluateNumber(7, 0, wkofac).intValue());
        ttara2.setTtofan(Utils.movel(ttara2.getTtofan(), 20, wkofan, 20));
        ttara2.setTtosbc(" ");
        ttara2.setTtonos(Utils.movel(ttara2.getTtonos(), 1, wkonos, 1));
        ttara2.setTtoncy(Utils.movel(ttara2.getTtoncy(), 3, wkoncy, 3));
        ttara2.setTtonac(Utils.movel(ttara2.getTtonac(), 10, wkonac, 10));
        ttara2.setTtonab(Utils.movel(ttara2.getTtonab(), 2, wkonab, 2));
        ttara2.setTtonae(0);
        ttara2.setTtonae(Utils.evaluateNumber(7, 0, wkonae).intValue());
        ttara2.setTtonan(Utils.movel(ttara2.getTtonan(), 20, wkonan, 20));
        ttara2.setTtonbc(0);
        ttara2.setTtonbc(Utils.evaluateNumber(7, 0, wkonbc).intValue());
        ttara2.setTtonbn(Utils.movel(ttara2.getTtonbn(), 18, wkonbn, 18));
        ttara2.setTtolrf(0L);
        ttara2.setTtolrf(Utils.evaluateNumber(11, 0, wkolrf).longValue());
        ttara2.setTtoapn(Utils.movel(ttara2.getTtoapn(), 14, wkoapn, 14));
        ttara2.setTtocst(0);
        ttara2.setTtocst(Utils.evaluateNumber(7, 0, wkocst).intValue());
        ttara2.setTtoctb(Utils.movel(ttara2.getTtoctb(), 18, wkoctb, 18));
        ttara2.setTtocn1(Utils.movel(ttara2.getTtocn1(), 40, wkocn1, 40));
        ttara2.setTtocn2(Utils.movel(ttara2.getTtocn2(), 40, wkocn2, 40));
        ttara2.setTtovat(Utils.movel(ttara2.getTtovat(), 1, wkovat, 1));
        ttara2.setTtoarf(Utils.movel(ttara2.getTtoarf(), 1, wkoarf, 1));
        ttara2.setTtorat(BigDecimal.ZERO);
        ttara2.setTtorat(Utils.evaluateNumber(9, 7, wkorat));
        ttara2.setTtospr(BigDecimal.ZERO);
        ttara2.setTtospr(Utils.evaluateNumber(9, 7, wkospr));
        ttara2.setTtocc1(Utils.movel(ttara2.getTtocc1(), 1, wkocc1, 1));
        ttara2.setTtocc2(Utils.movel(ttara2.getTtocc2(), 1, wkocc2, 1));
        ttara2.setTtormk(Utils.movel(ttara2.getTtormk(), 60, wkormk, 60));
        ttara2.setTtothe(Utils.movel(ttara2.getTtothe(), 15, wkothe, 15));
        ttara2.setTtoflg(Utils.movel(ttara2.getTtoflg(), 10, wkoflg, 10));

    }

    // ****************************************************
    // IN  PROCESS  CHECK  (2)  PROCESS         *
    // ****************************************************
    private void _2pchk2() {
        _127in1 = 0L;
        _127in1 = Utils.evaluateNumber(11, 0, wkrefn).longValue();
        _127in2 = 0;
        _127in2 = Utils.evaluateNumber(5, 0, ds001.getWkopn1()).intValue();
        _127in3 = 0;
        _127in3 = Utils.evaluateNumber(1, 0, ds001.getWkopn2()).intValue();
        _127();
        if (Utils.rTrim(_127ot).equals(Utils.rTrim("1"))) {
            if (indicator.getIn99() == false) {
                indicator.setIn62(true);    // *UOS6623*REF.NO

            }
            indicator.setIn22(true);
            indicator.setIn99(true);

        }
        if (Utils.rTrim(_127ot).equals(Utils.rTrim("2"))) {
            if (indicator.getIn99() == false) {
                indicator.setIn63(true);    // *UOS6620*REF.NO

            }
            indicator.setIn22(true);
            indicator.setIn99(true);

        }

    }

    // ****************************************************
    // TTFILE  OUTPUT  PROCESS                  *
    // ****************************************************
    private void _2ttout() {
        _1157();
        if (Utils.rTrim(_115701.get_1157ot()).equals(Utils.rTrim("1"))) {
            if (indicator.getIn99() == false) {
                indicator.setIn61(true);    // *UOS6621*OP.NO

            }
            indicator.setIn21(true);
            indicator.setIn99(true);

        }

    }

    // ****************************************************
    // SCREEN  ITEM  SET  PROCESS   (FGFILE)    *
    // ****************************************************
    private void _2srset() {
        // **  <01> OP.NO SET  ***
        // NO SET
        // **       REF.NO SET  ***
        wkrefn = 0L;
        wkrefn = Utils.evaluateNumber(11, 0, fgfll1.getFgrefn()).longValue();
        // **  <02> CUR CHECK  ***
        dto.setWsoscd(Utils.movel(dto.getWsoscd(), 1, fgfll1.getFgoscd(), 1, 0));
        dto.setWscycd("   ");
        wkcode = 0;
        wkcode = Utils.evaluateNumber(3, 0, fgfll1.getFgcycd()).intValue();
        wksupp = 0;
        wksupp = 0;
        wkflg1 = " ";
        wkflg2 = " ";
        wkflg3 = " ";
        cdfile.setCdkey1("   ");
        cdfile.setCdkey2("       ");
        cdfile.setCdkey1(Utils.movel(cdfile.getCdkey1(), 3, "173", 3));
        cdfile.setCdkey2(Utils.movel(cdfile.getCdkey2(), 7, fgfll1.getFgoscd(), 1, 0));
        cdfileKey = new Cdfile();
        cdfileKey.setCdkey1(cdfile.getCdkey1());
        cdfileKey.setCdkey2(cdfile.getCdkey2());
        cdfileTemp = cdfileDAO.selectFirstMatching(cdfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlCdfile.offsetClear();
        if (cdfileTemp != null) {
            indicator.setIn80(false);
            cdfile = cdfileTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
            wkflg1 = Utils.movel(wkflg1, 1, cdfile.getCdflg1(), 1);
            wkflg2 = Utils.movel(wkflg2, 1, cdfile.getCdflg2(), 1);
            wkflg3 = Utils.movel(wkflg3, 1, cdfile.getCdflg3(), 1);

        }
        cyfileKey = new Cyfile();
        cyfileKey.setCycode(fgfll1.getFgcycd());
        cyfileTemp = cyfileDAO.selectFirstMatching(cyfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlCyfile.offsetClear();
        if (cyfileTemp != null) {
            indicator.setIn80(false);
            cyfile = cyfileTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
            dto.setWscycd(Utils.movel(dto.getWscycd(), 3, /* TODO:Duplicate field [cyfll1.getCyname()]*/cyfile.getCyname(), 3));
            wksupp = 0;
            wksupp = Utils.evaluateNumber(1, 0, /* TODO:Duplicate field [cyfll1.getCysupp()]*/cyfile.getCysupp()).intValue();

        }
        // **  <03> VAL.DATE SET  ***
        parm10.setPdindt(0);
        parm10.setPdindt(Utils.evaluateNumber(7, 0, fgfll1.getFgvldt()).intValue());
        parm10.setPdecd1(Utils.movel(parm10.getPdecd1(), 1, parm0.getPadted(), 1));
        parm10.setPdecd2(Utils.movel(parm10.getPdecd2(), 1, "2", 1));
        this.fw102003VO.setPcparm(parm10.toString());
        this.fw102003Service.doMain(this.fw102003VO);
        parm10.setData(this.fw102003VO.getPcparm());
        ds006.setWkdate(Utils.movel(ds006.getWkdate(), 8, parm10.getPdotdt(), 8, 0));
        dto.setWsvdt1(Utils.movel(dto.getWsvdt1(), 2, ds006.getWkdat1(), 2));
        dto.setWsvdt2(Utils.movel(dto.getWsvdt2(), 2, ds006.getWkdat2(), 2));
        dto.setWsvdt3(Utils.movel(dto.getWsvdt3(), 3, ds006.getWkdat3(), 3));
        wkvldt = 0;
        wkvldt = Utils.evaluateNumber(7, 0, fgfll1.getFgvldt()).intValue();
        // **  <04> FEE CODE SET  ***
        dto.setWsfecd(Utils.movel(dto.getWsfecd(), 4, fgfll1.getFgfecd(), 4));
        dto.setWsfenm("               ");
        wkfefg = " ";
        wkcdf3 = " ";    // *ADD MTB-1463
        cdfile.setCdkey1("   ");
        cdfile.setCdkey2("       ");
        cdfile.setCdkey1(Utils.movel(cdfile.getCdkey1(), 3, "195", 3));
        cdfile.setCdkey2(Utils.movel(cdfile.getCdkey2(), 7, dto.getWsfecd(), 4));
        cdfileKey = new Cdfile();
        cdfileKey.setCdkey1(cdfile.getCdkey1());
        cdfileKey.setCdkey2(cdfile.getCdkey2());
        cdfileTemp = cdfileDAO.selectFirstMatching(cdfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlCdfile.offsetClear();
        if (cdfileTemp != null) {
            indicator.setIn80(false);
            cdfile = cdfileTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
            dto.setWsfenm(Utils.movel(dto.getWsfenm(), 15, cdfile.getCdnam1(), 20));
            wkfefg = Utils.movel(wkfefg, 1, cdfile.getCdflg1(), 1);
            wkcdf3 = cdfile.getCdflg3();    // *ADD MTB-1463

        }
        // * OLD SET *
        wkofcd = Utils.movel(wkofcd, 4, fgfll1.getFgfecd(), 4);
        wkofnm = Utils.movel(wkofnm, 15, dto.getWsfenm(), 15);
        // **  <05> FEE CAL.FM SET  ***
        if (!fgfll1.getFgfcfm().equals(0)) {
            parm10.setPdindt(0);
            parm10.setPdindt(Utils.evaluateNumber(7, 0, fgfll1.getFgfcfm()).intValue());
            parm10.setPdecd1(Utils.movel(parm10.getPdecd1(), 1, parm0.getPadted(), 1));
            parm10.setPdecd2(Utils.movel(parm10.getPdecd2(), 1, "2", 1));
            this.fw102003VO.setPcparm(parm10.toString());
            this.fw102003Service.doMain(this.fw102003VO);
            parm10.setData(this.fw102003VO.getPcparm());
            ds006.setWkdate(Utils.movel(ds006.getWkdate(), 8, parm10.getPdotdt(), 8, 0));
            dto.setWsfcf1(Utils.movel(dto.getWsfcf1(), 2, ds006.getWkdat1(), 2));
            dto.setWsfcf2(Utils.movel(dto.getWsfcf2(), 2, ds006.getWkdat2(), 2));
            dto.setWsfcf3(Utils.movel(dto.getWsfcf3(), 3, ds006.getWkdat3(), 3));

        }
        wkfcfm = 0;
        wkfcfm = Utils.evaluateNumber(7, 0, fgfll1.getFgfcfm()).intValue();
        // * OLD SET *
        wkoffm = 0;
        wkoffm = Utils.evaluateNumber(7, 0, fgfll1.getFgfcfm()).intValue();
        // **  <06> FEE CAL.TO SET  ***
        if (!fgfll1.getFgfcto().equals(0)) {
            parm10.setPdindt(0);
            parm10.setPdindt(Utils.evaluateNumber(7, 0, fgfll1.getFgfcto()).intValue());
            parm10.setPdecd1(Utils.movel(parm10.getPdecd1(), 1, parm0.getPadted(), 1));
            parm10.setPdecd2(Utils.movel(parm10.getPdecd2(), 1, "2", 1));
            this.fw102003VO.setPcparm(parm10.toString());
            this.fw102003Service.doMain(this.fw102003VO);
            parm10.setData(this.fw102003VO.getPcparm());
            ds006.setWkdate(Utils.movel(ds006.getWkdate(), 8, parm10.getPdotdt(), 8, 0));
            dto.setWsfct1(Utils.movel(dto.getWsfct1(), 2, ds006.getWkdat1(), 2));
            dto.setWsfct2(Utils.movel(dto.getWsfct2(), 2, ds006.getWkdat2(), 2));
            dto.setWsfct3(Utils.movel(dto.getWsfct3(), 3, ds006.getWkdat3(), 3));

        }
        wkfcto = 0;
        wkfcto = Utils.evaluateNumber(7, 0, fgfll1.getFgfcto()).intValue();
        // * OLD SET *
        wkofto = 0;
        wkofto = Utils.evaluateNumber(7, 0, fgfll1.getFgfcto()).intValue();
        // **  <07> FEE AMOUNT SET  ***
        dto.setWsamnt(Utils.evaluateNumber(15, 2, fgfll1.getFgtamt()));
        // * OLD SET *
        wkofam = BigDecimal.ZERO;
        wkofam = Utils.evaluateNumber(15, 2, fgfll1.getFgtamt());
        // **  <08> FEE A/C SET  ***
        dto.setWsacno(Utils.evaluateNumber(7, 0, fgfll1.getFgaccd()).intValue());
        dto.setWsacnm("                    ");
        wkact3 = 0;
        wkact3 = Utils.evaluateNumber(7, 0, fgfll1.getFgaccd()).intValue();
        wkfacc = 0;
        wkfacc = 0;
        wkfacn = "                    ";
        wkac05 = " ";
        wkac25 = " ";
        wkot61 = " ";
        wka3ac = 0;
        wka3ac = 0;
        wkb3ac = 0;
        wkb3ac = 0;
        wkc3ac = 0;
        wkc3ac = 0;
        wkd3ac = 0;
        wkd3ac = 0;
        wke4ac = 0;
        wke4ac = 0;
        wkf4ac = 0;
        wkf4ac = 0;
        acfileKey = new Acfile();
        acfileKey.setAcincd(fgfll1.getFgaccd());
        acfileTemp = acfileDAO.selectFirstMatching(acfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlAcfile.offsetClear();
        if (acfileTemp != null) {
            indicator.setIn80(false);
            acfile = acfileTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
            dto.setWsacnm(Utils.movel(dto.getWsacnm(), 20, /* TODO:Duplicate field [extnl1.getAcname()]*/acfile.getAcname(), 20));
            wkfacc = 0;
            wkfacc = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [extnl1.getAcexcd()]*/acfile.getAcexcd()).intValue();
            wkfacn = Utils.movel(wkfacn, 20, /* TODO:Duplicate field [extnl1.getAcname()]*/acfile.getAcname(), 20);
            wkdrcr = Utils.movel(wkdrcr, 1, /* TODO:Duplicate field [extnl1.getAcdrcr()]*/acfile.getAcdrcr(), 1);
            wkac05 = Utils.movel(wkac05, 1, /* TODO:Duplicate field [extnl1.getAccd05()]*/acfile.getAccd05(), 1);
            wkac25 = Utils.movel(wkac25, 1, /* TODO:Duplicate field [extnl1.getAccd25()]*/acfile.getAccd25(), 1);
            wkot61 = Utils.movel(wkot61, 1, /* TODO:Duplicate field [extnl1.getAcot61()]*/acfile.getAcot61(), 1);

        }
        /* TODO:Duplicate field [tafll1.setTalsno()]*/tatable.setTalsno(Utils.movel(/* TODO:Duplicate field [tafll1.getTalsno()]*/tatable.getTalsno(), 4, "416 ", 4));
        /* TODO:Duplicate field [tafll1.setTatype()]*/tatable.setTatype(Utils.movel(/* TODO:Duplicate field [tafll1.getTatype()]*/tatable.getTatype(), 1, "8", 1));
        /* TODO:Duplicate field [tafll1.setTaaccd()]*/tatable.setTaaccd(0);
        /* TODO:Duplicate field [tafll1.setTaaccd()]*/tatable.setTaaccd(Utils.evaluateNumber(7, 0, fgfll1.getFgaccd()).intValue());
        /* TODO:Duplicate field [tafll1.setTaact1()]*/tatable.setTaact1("  ");
        /* TODO:Duplicate field [tafll1.setTaact2()]*/tatable.setTaact2("  ");
        /* TODO:Duplicate field [tafll1.setTaact3()]*/tatable.setTaact3("  ");
        /* TODO:Duplicate field [tafll1.setTacd01()]*/tatable.setTacd01(Utils.movel(/* TODO:Duplicate field [tafll1.getTacd01()]*/tatable.getTacd01(), 1, "2", 1));
        tatableKey = new Tatable();
        tatableKey.setTalsno(/* TODO:Duplicate field [tafll1.getTalsno()]*/tatable.getTalsno());
        tatableKey.setTatype(/* TODO:Duplicate field [tafll1.getTatype()]*/tatable.getTatype());
        tatableKey.setTaaccd(/* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd());
        tatableKey.setTaact1(/* TODO:Duplicate field [tafll1.getTaact1()]*/tatable.getTaact1());
        tatableKey.setTaact2(/* TODO:Duplicate field [tafll1.getTaact2()]*/tatable.getTaact2());
        tatableKey.setTaact3(/* TODO:Duplicate field [tafll1.getTaact3()]*/tatable.getTaact3());
        tatableKey.setTacd01(/* TODO:Duplicate field [tafll1.getTacd01()]*/tatable.getTacd01());
        tatableTemp = tatableDAO.selectFirstMatching(tatableKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlTatable.offsetClear();
        if (tatableTemp != null) {
            indicator.setIn80(false);
            tatable = tatableTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
            wktacd = 0;
            wktacd = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd()).intValue();

        }
        /* TODO:Duplicate field [tafll1.setTalsno()]*/tatable.setTalsno(Utils.movel(/* TODO:Duplicate field [tafll1.getTalsno()]*/tatable.getTalsno(), 4, "416 ", 4));
        /* TODO:Duplicate field [tafll1.setTatype()]*/tatable.setTatype(Utils.movel(/* TODO:Duplicate field [tafll1.getTatype()]*/tatable.getTatype(), 1, "9", 1));
        /* TODO:Duplicate field [tafll1.setTaaccd()]*/tatable.setTaaccd(0);
        /* TODO:Duplicate field [tafll1.setTaaccd()]*/tatable.setTaaccd(Utils.evaluateNumber(7, 0, fgfll1.getFgaccd()).intValue());
        /* TODO:Duplicate field [tafll1.setTaact1()]*/tatable.setTaact1("  ");
        /* TODO:Duplicate field [tafll1.setTaact2()]*/tatable.setTaact2("  ");
        /* TODO:Duplicate field [tafll1.setTaact3()]*/tatable.setTaact3("  ");
        /* TODO:Duplicate field [tafll1.setTacd01()]*/tatable.setTacd01(Utils.movel(/* TODO:Duplicate field [tafll1.getTacd01()]*/tatable.getTacd01(), 1, "2", 1));
        tatableKey = new Tatable();
        tatableKey.setTalsno(/* TODO:Duplicate field [tafll1.getTalsno()]*/tatable.getTalsno());
        tatableKey.setTatype(/* TODO:Duplicate field [tafll1.getTatype()]*/tatable.getTatype());
        tatableKey.setTaaccd(/* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd());
        tatableKey.setTaact1(/* TODO:Duplicate field [tafll1.getTaact1()]*/tatable.getTaact1());
        tatableKey.setTaact2(/* TODO:Duplicate field [tafll1.getTaact2()]*/tatable.getTaact2());
        tatableKey.setTaact3(/* TODO:Duplicate field [tafll1.getTaact3()]*/tatable.getTaact3());
        tatableKey.setTacd01(/* TODO:Duplicate field [tafll1.getTacd01()]*/tatable.getTacd01());
        tatableTemp = tatableDAO.selectFirstMatching(tatableKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlTatable.offsetClear();
        if (tatableTemp != null) {
            indicator.setIn80(false);
            tatable = tatableTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
            wktacd = 0;
            wktacd = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTatacd()]*/tatable.getTatacd()).intValue();

        }
        _2acget();    // ACCRUAL A/C GET
        // * OLD SET *
        wkofac = 0;
        wkofac = Utils.evaluateNumber(7, 0, fgfll1.getFgaccd()).intValue();
        wkofan = Utils.movel(wkofan, 20, dto.getWsacnm(), 20);
        // **  <09> SB CODE SET  ***
        // **  <10> NOSTRO CUR SET  ***
        dto.setWsnsos(Utils.move(dto.getWsnsos(), 1, fgfll1.getFgcoos(), 1, 0));
        dto.setWsnscy("   ");
        wknfg1 = " ";
        wknfg2 = " ";
        wknfg3 = " ";
        cdfile.setCdkey1("   ");
        cdfile.setCdkey2("       ");
        cdfile.setCdkey1(Utils.movel(cdfile.getCdkey1(), 3, "173", 3));
        cdfile.setCdkey2(Utils.movel(cdfile.getCdkey2(), 7, fgfll1.getFgcoos(), 1, 0));
        cdfileKey = new Cdfile();
        cdfileKey.setCdkey1(cdfile.getCdkey1());
        cdfileKey.setCdkey2(cdfile.getCdkey2());
        cdfileTemp = cdfileDAO.selectFirstMatching(cdfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlCdfile.offsetClear();
        if (cdfileTemp != null) {
            indicator.setIn80(false);
            cdfile = cdfileTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
            wknfg1 = Utils.movel(wknfg1, 1, cdfile.getCdflg1(), 1);
            wknfg2 = Utils.movel(wknfg2, 1, cdfile.getCdflg2(), 1);
            wknfg3 = Utils.movel(wknfg3, 1, cdfile.getCdflg3(), 1);

        }
        cyfileKey = new Cyfile();
        cyfileKey.setCycode(fgfll1.getFgcocy());
        cyfileTemp = cyfileDAO.selectFirstMatching(cyfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlCyfile.offsetClear();
        if (cyfileTemp != null) {
            indicator.setIn80(false);
            cyfile = cyfileTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
            dto.setWsnscy(Utils.movel(dto.getWsnscy(), 3, /* TODO:Duplicate field [cyfll1.getCyname()]*/cyfile.getCyname(), 3));

        }
        wkocd4 = 0;
        wkocd4 = Utils.evaluateNumber(1, 0, fgfll1.getFgcoos()).intValue();
        wkcur4 = 0;
        wkcur4 = Utils.evaluateNumber(3, 0, fgfll1.getFgcocy()).intValue();
        // * OLD SET *
        wkonos = Utils.move(wkonos, 1, fgfll1.getFgcoos(), 1, 0);
        wkoncy = Utils.movel(wkoncy, 3, dto.getWsnscy(), 3);
        // **  <11> NOSTRO A/C SET  ***
        dto.setWsnsac("          ");
        dto.setWsnsab(0);
        w108o1 = " ";
        w108o2 = " ";
        w108o3 = 0;
        w108o3 = 0;
        w108o4 = 0;
        w108o4 = 0;
        w108o5 = 0;
        w108o5 = 0;
        w108o6 = 0;
        w108o6 = 0;
        w108o7 = 0;
        w108o7 = 0;
        wkexcd = 0;
        wkexcd = 0;
        wkabbr = "          ";
        wkname = "                    ";
        wkamcd = " ";
        wkac07 = " ";
        wkac24 = " ";
        ds009.setWkrefb(0L);
        ds009.setWkrefb(Utils.evaluateNumber(11, 0, fgfll1.getFgrefb()).longValue());
        acfileKey = new Acfile();
        acfileKey.setAcincd(fgfll1.getFgcoac());
        acfileTemp = acfileDAO.selectFirstMatching(acfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlAcfile.offsetClear();
        if (acfileTemp != null) {
            indicator.setIn80(false);
            acfile = acfileTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
            if (Utils.rTrim(/* TODO:Duplicate field [extnl1.getAccd20()]*/acfile.getAccd20()).equals(Utils.rTrim("1"))) {
                dto.setWsnsac(Utils.movel(dto.getWsnsac(), 10, ds009.getWkref9(), 9, 0));
                dto.setWsnsab(0);
            } else {
                dto.setWsnsac(Utils.movel(dto.getWsnsac(), 10, /* TODO:Duplicate field [extnl1.getAcabbr()]*/acfile.getAcabbr(), 10));
                dto.setWsnsab(Utils.evaluateNumber(2, 0, fgfll1.getFgacbr()).intValue());

            }

        }
        _110801.set_1108i1(Utils.movel(_110801.get_1108i1(), 10, dto.getWsnsac(), 10));
        _110801.set_1108i2(0);
        _110801.set_1108i2(Utils.evaluateNumber(3, 0, dto.getWsnsab()).intValue());
        _110801.set_1108i3("0");
        _1108();
        if (Utils.rTrim(_110801.get_1108o1()).equals(Utils.rTrim(" "))) {
            dto.setWsnsan(Utils.movel(dto.getWsnsan(), 20, /* TODO:Duplicate field [extnl1.getAcname()]*/acfile.getAcname(), 20));
            wkexcd = 0;
            wkexcd = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [extnl1.getAcexcd()]*/acfile.getAcexcd()).intValue();
            wkabbr = Utils.movel(wkabbr, 10, /* TODO:Duplicate field [extnl1.getAcabbr()]*/acfile.getAcabbr(), 10);
            wkname = Utils.movel(wkname, 20, /* TODO:Duplicate field [extnl1.getAcname()]*/acfile.getAcname(), 20);
            wkamcd = Utils.movel(wkamcd, 1, /* TODO:Duplicate field [extnl1.getAcamcd()]*/acfile.getAcamcd(), 1);
            wkac07 = Utils.movel(wkac07, 1, /* TODO:Duplicate field [extnl1.getAccd07()]*/acfile.getAccd07(), 1);
            wkac24 = Utils.movel(wkac24, 1, /* TODO:Duplicate field [extnl1.getAccd24()]*/acfile.getAccd24(), 1);
            w108o1 = Utils.movel(w108o1, 1, _110801.get_1108o1(), 1);
            w108o2 = Utils.movel(w108o2, 1, _110801.get_1108o2(), 1);
            w108o3 = 0;
            w108o3 = Utils.evaluateNumber(7, 0, _110801.get_1108o3()).intValue();
            w108o4 = 0;
            w108o4 = Utils.evaluateNumber(3, 0, _110801.get_1108o4()).intValue();
            w108o5 = 0;
            w108o5 = Utils.evaluateNumber(1, 0, _110801.get_1108o5()).intValue();
            w108o6 = 0;
            w108o6 = Utils.evaluateNumber(3, 0, _110801.get_1108o6()).intValue();
            w108o7 = 0;
            w108o7 = Utils.evaluateNumber(7, 0, _110801.get_1108o7()).intValue();

        }
        // * OLD SET *
        wkonac = Utils.movel(wkonac, 10, dto.getWsnsac(), 10);
        if (!dto.getWsnsab().equals(0)) {
            wkonab = Utils.move(wkonab, 2, dto.getWsnsab(), 2, 0);

        }
        wkonae = 0;
        wkonae = Utils.evaluateNumber(7, 0, wkexcd).intValue();
        wkonan = Utils.movel(wkonan, 20, dto.getWsnsan(), 20);
        // **  <12> NOSTR BK SET  ***
        if (indicator.getIn80() == false) {
            if (Utils.rTrim(/* TODO:Duplicate field [extnl1.getAcamcd()]*/acfile.getAcamcd()).equals(Utils.rTrim("3"))) {
                dto.setWsnsbk("                  ");
                wknsbc = 0;
                wknsbc = Utils.evaluateNumber(7, 0, fgfll1.getFgcoct()).intValue();
                wknsbn = "                  ";
                cmfileKey = new Cmfile();
                cmfileKey.setCmcust(fgfll1.getFgcoct());
                cmfileTemp = cmfileDAO.selectFirstMatching(cmfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
                offsetCtlCmfile.offsetClear();
                if (cmfileTemp != null) {
                    indicator.setIn81(false);
                    cmfile = cmfileTemp;
                } else {
                    indicator.setIn81(true);
                }
                if (indicator.getIn81() == false) {
                    dto.setWsnsbk(Utils.movel(dto.getWsnsbk(), 18, cmfile.getCmctab(), 18));
                    wknsbn = Utils.movel(wknsbn, 18, cmfile.getCmctab(), 18);
                    // * OLD SET *
                    wkonbc = Utils.movel(wkonbc, 7, 0, cmfile.getCmcust(), 7, 0).intValue();
                    wkonbn = Utils.movel(wkonbn, 18, cmfile.getCmctab(), 18);

                }

            }

        }
        // **  <13> LINK REF. SET  ***
        dto.setWslref(Utils.evaluateNumber(11, 0, fgfll1.getFglref()).longValue());
        ds010.setWklref(0L);
        ds010.setWklref(Utils.evaluateNumber(11, 0, fgfll1.getFglref()).longValue());
        // * OLD SET *
        wkolrf = 0L;
        wkolrf = Utils.evaluateNumber(11, 0, fgfll1.getFglref()).longValue();
        // **  <14> LINK AP.NO SET  ***
        dto.setWsapno(Utils.movel(dto.getWsapno(), 14, fgfll1.getFgapno(), 14));
        // * OLD SET *
        wkoapn = Utils.movel(wkoapn, 14, fgfll1.getFgapno(), 14);
        // **  <15> CUSTOMER SET  ***
        dto.setWscust("                  ");
        wkcust = 0;
        wkcust = Utils.evaluateNumber(7, 0, fgfll1.getFgcust()).intValue();
        wkcnm1 = "                                        ";
        wkcnm2 = "                                        ";
        wkcocd = 0;
        wkcocd = 0;
        cmfileKey = new Cmfile();
        cmfileKey.setCmcust(fgfll1.getFgcust());
        cmfileTemp = cmfileDAO.selectFirstMatching(cmfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlCmfile.offsetClear();
        if (cmfileTemp != null) {
            indicator.setIn80(false);
            cmfile = cmfileTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
            dto.setWscust(Utils.movel(dto.getWscust(), 18, cmfile.getCmctab(), 18));
            wkcnm1 = Utils.movel(wkcnm1, 40, cmfile.getCmnam1(), 40);
            wkcnm2 = Utils.movel(wkcnm2, 40, cmfile.getCmnam2(), 40);
            wkcocd = 0;
            wkcocd = Utils.evaluateNumber(3, 0, cmfile.getCmcocd()).intValue();
            // * OLD SET *
            wkocst = Utils.movel(wkocst, 7, 0, cmfile.getCmcust(), 7, 0).intValue();
            wkoctb = Utils.movel(wkoctb, 18, cmfile.getCmctab(), 18);
            wkocn1 = Utils.movel(wkocn1, 40, cmfile.getCmnam1(), 40);
            wkocn2 = Utils.movel(wkocn2, 40, cmfile.getCmnam2(), 40);

        }
        // **  <16> VAT SET  ***
        dto.setWsvatc(Utils.movel(dto.getWsvatc(), 1, fgfll1.getFgvatc(), 1));
        // * OLD SET *
        wkovat = Utils.movel(wkovat, 1, fgfll1.getFgvatc(), 1);
        // **  <17> ACCRUAL FG SET  ***
        dto.setWsacrf(Utils.movel(dto.getWsacrf(), 1, fgfll1.getFgacrf(), 1));
        // * OLD SET *
        wkoarf = Utils.movel(wkoarf, 1, fgfll1.getFgacrf(), 1);
        // **  <18> RATE SET  ***
        dto.setWsrate(Utils.evaluateNumber(9, 7, fgfll1.getFgrate()));
        // * OLD SET *
        wkorat = BigDecimal.ZERO;
        wkorat = Utils.evaluateNumber(9, 7, fgfll1.getFgrate());
        // **  <19> SPREAD SET  ***
        dto.setWssprd(Utils.evaluateNumber(9, 7, fgfll1.getFgsprd()));
        // * OLD SET *
        wkospr = BigDecimal.ZERO;
        wkospr = Utils.evaluateNumber(9, 7, fgfll1.getFgsprd());
        // **  <20> FEE.CL.CD1 SET  ***
        dto.setWsccd1(Utils.movel(dto.getWsccd1(), 1, fgfll1.getFgccd1(), 1));
        // * OLD SET *
        wkocc1 = Utils.movel(wkocc1, 1, fgfll1.getFgccd1(), 1);
        // **  <21> FEE.CL.CD2 SET  ***
        dto.setWsccd2(Utils.movel(dto.getWsccd2(), 1, fgfll1.getFgccd2(), 1));
        // * OLD SET *
        wkocc2 = Utils.movel(wkocc2, 1, fgfll1.getFgccd2(), 1);
        // **  <22> PARTICULAR SET  ***
        ds011.setWsrmks(Utils.movel(ds011.getWsrmks(), 60, fgfll1.getFgrmks(), 60));
        // * OLD SET *
        wkormk = Utils.movel(wkormk, 60, fgfll1.getFgrmks(), 60);
        // **  <23> THEIR SET  ***
        dto.setWsthei(Utils.movel(dto.getWsthei(), 15, fgfll1.getFgthei(), 15));
        // * OLD SET *
        wkothe = Utils.movel(wkothe, 15, fgfll1.getFgthei(), 15);
        // **  <24> FLAG SET  ***
        ds012.setWsflg1(Utils.movel(ds012.getWsflg1(), 1, fgfll1.getFgflg1(), 1));
        ds012.setWsflg2(Utils.movel(ds012.getWsflg2(), 1, fgfll1.getFgflg2(), 1));
        ds012.setWsflg3(Utils.movel(ds012.getWsflg3(), 1, fgfll1.getFgflg3(), 1));
        ds012.setWsflg4(Utils.movel(ds012.getWsflg4(), 1, fgfll1.getFgflg4(), 1));
        ds012.setWsflg5(Utils.movel(ds012.getWsflg5(), 1, fgfll1.getFgflg5(), 1));
        ds012.setWsflg6(Utils.movel(ds012.getWsflg6(), 1, fgfll1.getFgflg6(), 1));
        ds012.setWsflg7(Utils.movel(ds012.getWsflg7(), 1, fgfll1.getFgflg7(), 1));
        ds012.setWsflg8(Utils.movel(ds012.getWsflg8(), 1, fgfll1.getFgflg8(), 1));
        ds012.setWsflg9(Utils.movel(ds012.getWsflg9(), 1, fgfll1.getFgflg9(), 1));
        ds012.setWsfg10(Utils.movel(ds012.getWsfg10(), 1, fgfll1.getFgfg10(), 1));
        // * OLD SET *
        wkoflg = Utils.movel(wkoflg, 10, ds012.getWsflag(), 10);

    }

    // ****************************************************
    // BALANCE  CHECK  PROCESS                  *
    // ****************************************************
    private void _2blnck() {
        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CLEAR] original-code : 2577.00:C                   CLEAR                   PARMA5
        // FIXME DSクラスの初期化は手動対応が必要です。
        if (dto.getWstrcd().equals(60) || dto.getWstrcd().equals(63)) {
            if (wkvldt <= parm0.getPatody() && !/* TODO:Duplicate field [refnl2.getTtocd3()]*/ttfile.getTtocd3().equals(/* TODO:Duplicate field [refnl2.getTtocd4()]*/ttfile.getTtocd4())) {
                parma5.setP5rtcy(0);
                parma5.setP5rtcy(0);
                parma5.setP5exrt(BigDecimal.ZERO);
                parma5.setP5exrt(Utils.evaluateNumber(11, 6, 0));
                wkcoos = Utils.move(wkcoos, 1, /* TODO:Duplicate field [refnl2.getTtocd4()]*/ttfile.getTtocd4(), 1, 0);
                parma5.setP5pair(dto.getWsoscd() + wkcoos);
                parma5.setP5cur1(0);
                parma5.setP5cur1(Utils.evaluateNumber(3, 0, /* TODO:Duplicate field [refnl2.getTtcur3()]*/ttfile.getTtcur3()).intValue());
                parma5.setP5am11(BigDecimal.ZERO);
                parma5.setP5am11(Utils.evaluateNumber(15, 2, /* TODO:Duplicate field [refnl2.getTtamt3()]*/ttfile.getTtamt3()));
                parma5.setP5dc11(Utils.movel(parma5.getP5dc11(), 1, /* TODO:Duplicate field [refnl2.getTtdrc3()]*/ttfile.getTtdrc3(), 1));
                parma5.setP5ac11(0);
                parma5.setP5ac11(Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [refnl2.getTtact3()]*/ttfile.getTtact3()).intValue());
                parma5.setP5am12(BigDecimal.ZERO);
                parma5.setP5am12(Utils.evaluateNumber(15, 2, 0));
                parma5.setP5dc12(" ");
                parma5.setP5ac12(0);
                parma5.setP5ac12(0);
                parma5.setP5am13(BigDecimal.ZERO);
                parma5.setP5am13(Utils.evaluateNumber(15, 2, 0));
                parma5.setP5dc13(" ");
                parma5.setP5ac13(0);
                parma5.setP5ac13(0);
                parma5.setP5am14(BigDecimal.ZERO);
                parma5.setP5am14(Utils.evaluateNumber(15, 2, 0));
                parma5.setP5dc14(" ");
                parma5.setP5ac14(0);
                parma5.setP5ac14(0);
                parma5.setP5cur2(0);
                parma5.setP5cur2(Utils.evaluateNumber(3, 0, /* TODO:Duplicate field [refnl2.getTtcur4()]*/ttfile.getTtcur4()).intValue());
                parma5.setP5digt(0);
                parma5.setP5digt(Utils.evaluateNumber(1, 0, wksupp).intValue());
                parma5.setP5am21(BigDecimal.ZERO);
                parma5.setP5am21(Utils.evaluateNumber(15, 2, /* TODO:Duplicate field [refnl2.getTtamt4()]*/ttfile.getTtamt4()));
                parma5.setP5dc21(Utils.movel(parma5.getP5dc21(), 1, /* TODO:Duplicate field [refnl2.getTtdrc4()]*/ttfile.getTtdrc4(), 1));
                parma5.setP5ac21(0);
                parma5.setP5ac21(Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [refnl2.getTtact4()]*/ttfile.getTtact4()).intValue());
                parma5.setP5am22(BigDecimal.ZERO);
                parma5.setP5am22(Utils.evaluateNumber(15, 2, 0));
                parma5.setP5dc22(" ");
                parma5.setP5ac22(0);
                parma5.setP5ac22(0);
                parma5.setP5am23(BigDecimal.ZERO);
                parma5.setP5am23(Utils.evaluateNumber(15, 2, 0));
                parma5.setP5dc23(" ");
                parma5.setP5ac23(0);
                parma5.setP5ac23(0);
                parma5.setP5am24(BigDecimal.ZERO);
                parma5.setP5am24(Utils.evaluateNumber(15, 2, 0));
                parma5.setP5dc24(" ");
                parma5.setP5ac24(0);
                parma5.setP5ac24(0);
                parma5.setP5aflg(" ");
                this.fw102211VO.setParma5(parma5.toString());
                this.fw102211Service.doMain(this.fw102211VO);
                parma5.setData(this.fw102211VO.getParma5());

            }

        }

    }

    // ****************************************************
    // ACCURAL  A/C  GET  PROCESS               *
    // ****************************************************
    private void _2acget() {
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(0);
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(Utils.evaluateNumber(7, 0, wktacd).intValue());
        /* TODO:Duplicate field [tafll1.setTarefa()]*/tatable.setTarefa(Utils.movel(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa(), 3, "A3P", 3));
        tafll1Key = new Tafll1();
        tafll1Key.setTaajac(/* TODO:Duplicate field [tafll1.getTaajac()]*/tatable.getTaajac());
        tafll1Key.setTarefa(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa());
        tafll1Temp = tafll1DAO.selectFirstMatching(tafll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlTafll1.offsetClear();
        if (tafll1Temp != null) {
            indicator.setIn81(false);
            tafll1 = tafll1Temp;
        } else {
            indicator.setIn81(true);
        }
        if (indicator.getIn81() == false) {
            wka3ac = 0;
            wka3ac = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd()).intValue();

        }
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(0);
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(Utils.evaluateNumber(7, 0, wktacd).intValue());
        /* TODO:Duplicate field [tafll1.setTarefa()]*/tatable.setTarefa(Utils.movel(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa(), 3, "B3S", 3));
        tafll1Key = new Tafll1();
        tafll1Key.setTaajac(/* TODO:Duplicate field [tafll1.getTaajac()]*/tatable.getTaajac());
        tafll1Key.setTarefa(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa());
        tafll1Temp = tafll1DAO.selectFirstMatching(tafll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlTafll1.offsetClear();
        if (tafll1Temp != null) {
            indicator.setIn81(false);
            tafll1 = tafll1Temp;
        } else {
            indicator.setIn81(true);
        }
        if (indicator.getIn81() == false) {
            wkb3ac = 0;
            wkb3ac = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd()).intValue();

        }
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(0);
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(Utils.evaluateNumber(7, 0, wktacd).intValue());
        /* TODO:Duplicate field [tafll1.setTarefa()]*/tatable.setTarefa(Utils.movel(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa(), 3, "C3S", 3));
        tafll1Key = new Tafll1();
        tafll1Key.setTaajac(/* TODO:Duplicate field [tafll1.getTaajac()]*/tatable.getTaajac());
        tafll1Key.setTarefa(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa());
        tafll1Temp = tafll1DAO.selectFirstMatching(tafll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlTafll1.offsetClear();
        if (tafll1Temp != null) {
            indicator.setIn81(false);
            tafll1 = tafll1Temp;
        } else {
            indicator.setIn81(true);
        }
        if (indicator.getIn81() == false) {
            wkc3ac = 0;
            wkc3ac = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd()).intValue();

        }
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(0);
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(Utils.evaluateNumber(7, 0, wktacd).intValue());
        /* TODO:Duplicate field [tafll1.setTarefa()]*/tatable.setTarefa(Utils.movel(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa(), 3, "D3P", 3));
        tafll1Key = new Tafll1();
        tafll1Key.setTaajac(/* TODO:Duplicate field [tafll1.getTaajac()]*/tatable.getTaajac());
        tafll1Key.setTarefa(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa());
        tafll1Temp = tafll1DAO.selectFirstMatching(tafll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlTafll1.offsetClear();
        if (tafll1Temp != null) {
            indicator.setIn81(false);
            tafll1 = tafll1Temp;
        } else {
            indicator.setIn81(true);
        }
        if (indicator.getIn81() == false) {
            wkd3ac = 0;
            wkd3ac = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd()).intValue();

        }
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(0);
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(Utils.evaluateNumber(7, 0, wktacd).intValue());
        /* TODO:Duplicate field [tafll1.setTarefa()]*/tatable.setTarefa(Utils.movel(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa(), 3, " 4P", 3));
        tafll1Key = new Tafll1();
        tafll1Key.setTaajac(/* TODO:Duplicate field [tafll1.getTaajac()]*/tatable.getTaajac());
        tafll1Key.setTarefa(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa());
        tafll1Temp = tafll1DAO.selectFirstMatching(tafll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlTafll1.offsetClear();
        if (tafll1Temp != null) {
            indicator.setIn81(false);
            tafll1 = tafll1Temp;
        } else {
            indicator.setIn81(true);
        }
        if (indicator.getIn81() == false) {
            wke4ac = 0;
            wke4ac = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd()).intValue();

        }
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(0);
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(Utils.evaluateNumber(7, 0, wktacd).intValue());
        /* TODO:Duplicate field [tafll1.setTarefa()]*/tatable.setTarefa(Utils.movel(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa(), 3, " 4S", 3));
        tafll1Key = new Tafll1();
        tafll1Key.setTaajac(/* TODO:Duplicate field [tafll1.getTaajac()]*/tatable.getTaajac());
        tafll1Key.setTarefa(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa());
        tafll1Temp = tafll1DAO.selectFirstMatching(tafll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlTafll1.offsetClear();
        if (tafll1Temp != null) {
            indicator.setIn81(false);
            tafll1 = tafll1Temp;
        } else {
            indicator.setIn81(true);
        }
        if (indicator.getIn81() == false) {
            wke4ac = 0;
            wke4ac = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd()).intValue();

        }
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(0);
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(Utils.evaluateNumber(7, 0, wktacd).intValue());
        /* TODO:Duplicate field [tafll1.setTarefa()]*/tatable.setTarefa(Utils.movel(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa(), 3, "94P", 3));
        tafll1Key = new Tafll1();
        tafll1Key.setTaajac(/* TODO:Duplicate field [tafll1.getTaajac()]*/tatable.getTaajac());
        tafll1Key.setTarefa(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa());
        tafll1Temp = tafll1DAO.selectFirstMatching(tafll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlTafll1.offsetClear();
        if (tafll1Temp != null) {
            indicator.setIn81(false);
            tafll1 = tafll1Temp;
        } else {
            indicator.setIn81(true);
        }
        if (indicator.getIn81() == false) {
            wkf4ac = 0;
            wkf4ac = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd()).intValue();

        }
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(0);
        /* TODO:Duplicate field [tafll1.setTaajac()]*/tatable.setTaajac(Utils.evaluateNumber(7, 0, wktacd).intValue());
        /* TODO:Duplicate field [tafll1.setTarefa()]*/tatable.setTarefa(Utils.movel(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa(), 3, "94S", 3));
        tafll1Key = new Tafll1();
        tafll1Key.setTaajac(/* TODO:Duplicate field [tafll1.getTaajac()]*/tatable.getTaajac());
        tafll1Key.setTarefa(/* TODO:Duplicate field [tafll1.getTarefa()]*/tatable.getTarefa());
        tafll1Temp = tafll1DAO.selectFirstMatching(tafll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlTafll1.offsetClear();
        if (tafll1Temp != null) {
            indicator.setIn81(false);
            tafll1 = tafll1Temp;
        } else {
            indicator.setIn81(true);
        }
        if (indicator.getIn81() == false) {
            wkf4ac = 0;
            wkf4ac = Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [tafll1.getTaaccd()]*/tatable.getTaaccd()).intValue();

        }

    }

    // ****************************************************
    // ****      #23  CUST CODE CHECK  SUB-RTN        *****
    // ****************************************************
    private void _123() {
        _123wk1 = 0;
        _102301.set_123ot(" ");    // RETRN CODE
        // **  INITIAL SET ROUTINE
        // #23I17が数字の検査
        indicator.setIn91(false);
        if (Integer.valueOf(Utils.check(CNSNUM1, Utils.substring(_102301.get_123i17(), 1, 6))).equals(0) && Integer.valueOf(Utils.check(CNSNUM2, Utils.substring(_102301.get_123i17(), 7, 1))).equals(0)) {
            indicator.setIn91(true);

        }
        if (indicator.getIn91() == true) {
            _123wk1 = Utils.move(_123wk1, 7, 0, _102301.get_123i17(), 7).intValue();

        }
        if (indicator.getIn91() == false) {
            indicator.setIn92(true);
            _102301.set_123ot("1");    // ERR RETRN CODE

        }
        if (indicator.getIn91() == true) {
            cmfileKey = new Cmfile();
            cmfileKey.setCmcust(_123wk1);
            cmfileTemp = cmfileDAO.selectFirstMatching(cmfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
            offsetCtlCmfile.offsetClear();
            if (cmfileTemp != null) {
                indicator.setIn92(false);
                cmfile = cmfileTemp;
            } else {
                indicator.setIn92(true);
            }
            if (indicator.getIn92() == true) {
                _102301.set_123ot("1");    // ERR RETRN CODE

            }

        }
        // **  CATG IND NO2 CHECK ROUTINE
        if (indicator.getIn92() == false) {
            if (!Utils.rTrim(_102301.get_123in2()).equals(Utils.rTrim("E"))) {
                if (Utils.rTrim(_102301.get_123in2()).equals(Utils.rTrim("A"))) {
                    indicator.setIn92(false);
                    if (cmfile.getCmcat2().equals(1)) {
                        indicator.setIn92(true);

                    }
                    if (indicator.getIn92() == false) {
                        indicator.setIn92(false);
                        if (cmfile.getCmcat2().equals(2)) {
                            indicator.setIn92(true);

                        }

                    }

                }
                if (Utils.rTrim(_102301.get_123in2()).equals(Utils.rTrim("B"))) {
                    indicator.setIn92(false);
                    if (cmfile.getCmcat2().equals(3)) {
                        indicator.setIn92(true);

                    }

                }
                if (Utils.rTrim(_102301.get_123in2()).equals(Utils.rTrim("C"))) {
                    indicator.setIn92(false);
                    if (cmfile.getCmcat2().equals(1)) {
                        indicator.setIn92(true);

                    }
                    if (indicator.getIn92() == false) {
                        indicator.setIn92(false);
                        if (cmfile.getCmcat2().equals(2)) {
                            indicator.setIn92(true);

                        }

                    }
                    if (indicator.getIn92() == false) {
                        indicator.setIn92(false);
                        if (cmfile.getCmcat2().equals(3)) {
                            indicator.setIn92(true);

                        }

                    }

                }
                if (Utils.rTrim(_102301.get_123in2()).equals(Utils.rTrim("D"))) {
                    indicator.setIn92(false);
                    indicator.setIn92(false);
                    if (cmfile.getCmcat2() > 3) {
                        indicator.setIn92(true);

                    }
                    if (cmfile.getCmcat2() < 3) {
                        indicator.setIn92(true);

                    }

                }
                if (Utils.rTrim(_102301.get_123in2()).equals(Utils.rTrim("F"))) {
                    indicator.setIn92(false);
                    indicator.setIn92(false);
                    if (cmfile.getCmcat2() > 3) {
                        indicator.setIn92(true);

                    }
                    if (cmfile.getCmcat2().equals(3)) {
                        indicator.setIn92(true);

                    }
                    if (indicator.getIn92() == true) {
                        indicator.setIn92(false);
                        indicator.setIn92(false);
                        if (cmfile.getCmcat2() < 6) {
                            indicator.setIn92(true);

                        }
                        if (cmfile.getCmcat2().equals(6)) {
                            indicator.setIn92(true);

                        }

                    }

                }
                if (indicator.getIn92() == false) {
                    _102301.set_123ot("2");    // ERR RETRN CODE

                }

            }

        }

    }

    // ****************************************************
    // ****      ACCOUNT CODE CHECK  SUB-RTN          *****
    // ****************************************************
    private void _124() {
        _124wk1 = 0;
        _102401.set_124ot(" ");
        // #24I17が数字の検査
        indicator.setIn91(false);
        if (Integer.valueOf(Utils.check(CNSNUM1, Utils.substring(_102401.get_124i17(), 1, 6))).equals(0) && Integer.valueOf(Utils.check(CNSNUM2, Utils.substring(_102401.get_124i17(), 7, 1))).equals(0)) {
            indicator.setIn91(true);

        }
        if (indicator.getIn91() == true) {
            _124wk1 = Utils.move(_124wk1, 7, 0, _102401.get_124i17(), 7).intValue();

        }
        if (indicator.getIn91() == false) {
            _102401.set_124ot("1");

        }
        if (indicator.getIn91() == true) {
            extnl1Key = new Extnl1();
            extnl1Key.setAcexcd(_124wk1);
            extnl1Temp = extnl1DAO.selectFirstMatching(extnl1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
            offsetCtlExtnl1.offsetClear();
            if (extnl1Temp != null) {
                indicator.setIn92(false);
                extnl1 = extnl1Temp;
            } else {
                indicator.setIn92(true);
            }
            if (indicator.getIn92() == true) {
                _102401.set_124ot("1");

            }

        }
        if (Utils.rTrim(_102401.get_124ot()).equals(Utils.rTrim(" "))) {
            if (!Utils.rTrim(/* TODO:Duplicate field [extnl1.getAcokno()]*/acfile.getAcokno()).equals(Utils.rTrim("1"))) {
                _102401.set_124ot("2");

            }

        }

    }

// ****************************************************
// ****      TTFILE & FGFILE DUP CHECK  SUB-RTN   *****
// ****************************************************
private void _127() {
_127ot = "0";
//ndz-del-s
// // TODO FFRPG to Javaコンバータ - 変換に失敗しました  命令[CHAIN] original-code : 2782.00:C     #27IN1        CHAIN     T2RECD                             91
//ndz-del-e
// FIXME ツール未対応の引数です
if (indicator.getIn91() == false) {
    // TODO FFRPG to Javaコンバータ - 変換に失敗しました  命令[IFNE] original-code : 2783.00:C  N91#27IN2        IFNE      T2CPU2
    // FIXME 項目のデータ型もしくは桁数が取得できません。不足資産もしくは未対応キーワードの可能性があります。
    _127ot = "1";
} else {
    // TODO FFRPG to Javaコンバータ - 変換に失敗しました  命令[IFNE] original-code : 2786.00:C     #27IN3        IFNE      T2CPU3
    // FIXME 項目のデータ型もしくは桁数が取得できません。不足資産もしくは未対応キーワードの可能性があります。
    _127ot = "1";

}

}

}
if (!Utils.rTrim(_127ot).equals(Utils.rTrim("1"))) {
fgfll1Key = new Fgfll1();
fgfll1Key.setFgrefn(_127in1);
fgfll1Temp = fgfll1DAO.selectFirstMatching(fgfll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
offsetCtlFgfll1.offsetClear();
if (fgfll1Temp != null) {
indicator.setIn91(false);
fgfll1 = fgfll1Temp;
} else {
indicator.setIn91(true);
}
if (indicator.getIn91() == false) {
_127ot = "2";

}

}
_127in1 = 0L;
_127in1 = 0L;
_127in2 = 0;
_127in2 = 0;
_127in3 = 0;
_127in3 = 0;

}

// ****************************************************
// ****      DMFILE  DMCPU  GET  PROCESS          *****
// **********************************************HILOEQ
private void _2dmget() {
// WORK AREA CLEAR
indicator.setIn85(false);
ds013.setWkarx1("                                                                                                                                                                                                ");
ds013.setWkpcp1(0);
ds013.setWkpcp1(0);
ds013.setWkpcp2(0);
ds013.setWkpcp2(0);
ds013.setWkpcp3(0);
ds013.setWkpcp3(0);
// KEYDM1 SET
dmfll3.setDmrefn(0L);
dmfll3.setDmrefn(Utils.evaluateNumber(11, 0, /* TODO:Duplicate field [refnl2.getTtrefn()]*/ttfile.getTtrefn()).longValue());
dmfll3.setDmrefa(0L);
dmfll3.setDmrefa(Utils.evaluateNumber(11, 0, ttara1.getTtlref()).longValue());
dmfll3.setDmckdt(0);
dmfll3.setDmckdt(Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [refnl2.getTtvldt()]*/ttfile.getTtvldt()).intValue());
dmfll3.setDmoscd(0);
dmfll3.setDmoscd(Utils.evaluateNumber(1, 0, /* TODO:Duplicate field [refnl2.getTtocd3()]*/ttfile.getTtocd3()).intValue());
dmfll3.setDmcycd(0);
dmfll3.setDmcycd(Utils.evaluateNumber(3, 0, /* TODO:Duplicate field [refnl2.getTtcur3()]*/ttfile.getTtcur3()).intValue());
dmfll3.setDmaccd(0);
dmfll3.setDmaccd(Utils.evaluateNumber(7, 0, /* TODO:Duplicate field [refnl2.getTtact3()]*/ttfile.getTtact3()).intValue());
dmfll3.setDmcpu1(0);
dmfll3.setDmcpu1(0);
dmfll3.setDmcpu2(0);
dmfll3.setDmcpu2(0);
dmfll3.setDmcpu3(0);
dmfll3.setDmcpu3(0);
dmfll3Key = new Dmfll3();
dmfll3Key.setDmrefn(dmfll3.getDmrefn());
dmfll3Key.setDmrefa(dmfll3.getDmrefa());
dmfll3Key.setDmckdt(dmfll3.getDmckdt());
dmfll3Key.setDmoscd(dmfll3.getDmoscd());
dmfll3Key.setDmcycd(dmfll3.getDmcycd());
dmfll3Key.setDmaccd(dmfll3.getDmaccd());
dmfll3Key.setDmcpu1(dmfll3.getDmcpu1());
dmfll3Key.setDmcpu2(dmfll3.getDmcpu2());
dmfll3Key.setDmcpu3(dmfll3.getDmcpu3());
dmfll3DAO.setReadCriteria(dmfll3Key, SelectSqlPattern.GE, this.getClass().getSimpleName());
offsetCtlDmfll3.offsetClear();
dmfll3Key = new Dmfll3();
dmfll3Key.setDmrefn(dmfll3.getDmrefn());
dmfll3Key.setDmrefa(dmfll3.getDmrefa());
dmfll3Key.setDmckdt(dmfll3.getDmckdt());
dmfll3Key.setDmoscd(dmfll3.getDmoscd());
dmfll3Key.setDmcycd(dmfll3.getDmcycd());
dmfll3Key.setDmaccd(dmfll3.getDmaccd());
dmfll3Temp = dmfll3DAO.select(dmfll3Key, offsetCtlDmfll3.getOffsetAndIncrement(), SelectSqlPattern.EQ, this.getClass().getSimpleName());
if (dmfll3Temp == null) {
indicator.setIn85(true);
} else {
indicator.setIn85(false);
dmfll3 = dmfll3Temp;
}
if (indicator.getIn85() == false) {
if (!dmfll3.getDmtrcd().equals(41)) {
ds013.setWkpcp1(0);
ds013.setWkpcp1(Utils.evaluateNumber(7, 0, dmfll3.getDmcpu1()).intValue());
ds013.setWkpcp2(0);
ds013.setWkpcp2(Utils.evaluateNumber(5, 0, dmfll3.getDmcpu2()).intValue());
ds013.setWkpcp3(0);
ds013.setWkpcp3(Utils.evaluateNumber(1, 0, dmfll3.getDmcpu3()).intValue());

}

}

}

// ****************************************************
// ****      #102  SUPPLY UNIT CHECK  SUB-RTN     *****
// ****************************************************
private void _1102() {
_110201.set_1102ot(" ");
if (_110201.get_1102i1().equals(0)) {
if (!_110201.get_1102w1().equals(0)) {
_110201.set_1102ot("1");    // ERR RETRN CODE

}

}

}

// ****************************************************
// ****      #105  SETTLEMENT AC CHECK  SUB-RTN   *****
// ****************************************************
private void _1105() {
if (Utils.rTrim(_110501.get_1105n1()).equals(Utils.rTrim(_110501.get_1105d1()))) {    // CHECK DATA ?
_110501.set_1105n2(_110501.get_1105d2());    // 'NEW' = 'OLD'
} else {
_110501.set_1105o1(" ");    // RETRN CODE 1
_110501.set_1105o2(" ");    // RETRN CODE 2
Arrays.fill(indicator.getIn(), 90, 92, false);
// *
for (wkidxfor6 = 1; wkidxfor6 <= 1 ; wkidxfor6++) {
if (Utils.rTrim(_110501.get_1105i9()).equals(Utils.rTrim(" "))) {
    if (!_110501.get_1105i1().equals(0)) {
        _110501.set_1105o1("5");
        break;

    }

}
// *
if (Utils.rTrim(_110501.get_1105i7()).equals(Utils.rTrim(" "))) {
    _110501.set_1105o2("1");
    if (!Utils.rTrim(_110501.get_1105i8()).equals(Utils.rTrim("1"))) {
        _110501.set_1105o1("6");
    } else {
        if (!_110501.get_1105i6().equals(0)) {
            _110501.set_1105o1("1");

        }

    }
    break;

}
// *
if (Utils.rTrim(_110501.get_1105i7()).equals(Utils.rTrim("1"))) {
    _110501.set_1105o2("4");
    if (!Utils.rTrim(_110501.get_1105i8()).equals(Utils.rTrim("2"))) {
        _110501.set_1105o1("7");
    } else {
        if (!_110501.get_1105i6().equals(0)) {
            _110501.set_1105o1("1");

        }
        if (_110501.get_1105i5().equals(0)) {
            _110501.set_1105o1("1");

        }

    }
    break;

}
// *
indicator.setIn90(false);
if (Utils.rTrim(_110501.get_1105i7()).equals(Utils.rTrim("2"))) {
    indicator.setIn90(true);

}
if (indicator.getIn90() == false) {
    indicator.setIn90(false);
    if (Utils.rTrim(_110501.get_1105i7()).equals(Utils.rTrim("4"))) {
        indicator.setIn90(true);

    }

}
if (indicator.getIn90() == false) {
    indicator.setIn91(false);
    if (Utils.rTrim(_110501.get_1105i7()).equals(Utils.rTrim("5"))) {
        indicator.setIn91(true);

    }

}
if (indicator.getIn91() == false) {
    indicator.setIn91(false);
    if (Utils.rTrim(_110501.get_1105i7()).equals(Utils.rTrim("7"))) {
        indicator.setIn91(true);

    }

}
if (indicator.getIn90() == true || indicator.getIn91() == true) {
    for (wkidxfor7 = 1; wkidxfor7 <= 1 ; wkidxfor7++) {
        _110501.set_1105o2("2");
        if (!_110501.get_1105i6().equals(0)) {
            _110501.set_1105o1("1");
        } else {
            if (Utils.rTrim(_110501.get_1105id()).equals(Utils.rTrim("2"))) {
                indicator.setIn90(false);
                if (_110501.get_1105i1().equals(_110501.get_1105ia())) {
                    indicator.setIn90(true);

                }
                if (indicator.getIn90() == true) {
                    indicator.setIn90(false);
                    if (_110501.get_1105i2().equals(_110501.get_1105ib())) {
                        indicator.setIn90(true);

                    }

                }
                if (indicator.getIn90() == true) {
                    indicator.setIn90(false);
                    if (_110501.get_1105i5().equals(_110501.get_1105ic())) {
                        indicator.setIn90(true);

                    }

                }
                if (indicator.getIn90() == false) {
                    _110501.set_1105o1("4");

                }
                if (indicator.getIn90() == false) {
                    break;

                }

            }
            /* TODO:Duplicate field [refnl4.setAmoscd()]*/amfile.setAmoscd(0);
            /* TODO:Duplicate field [refnl4.setAmoscd()]*/amfile.setAmoscd(Utils.evaluateNumber(1, 0, _110501.get_1105i1()).intValue());    // AMFILE
            /* TODO:Duplicate field [refnl4.setAmcycd()]*/amfile.setAmcycd(0);
            /* TODO:Duplicate field [refnl4.setAmcycd()]*/amfile.setAmcycd(Utils.evaluateNumber(3, 0, _110501.get_1105i2()).intValue());    // KEY FIELD
            /* TODO:Duplicate field [refnl4.setAmaccd()]*/amfile.setAmaccd(0);
            /* TODO:Duplicate field [refnl4.setAmaccd()]*/amfile.setAmaccd(Utils.evaluateNumber(7, 0, _110501.get_1105i3()).intValue());    // DATA
            /* TODO:Duplicate field [refnl4.setAmcust()]*/amfile.setAmcust(0);
            /* TODO:Duplicate field [refnl4.setAmcust()]*/amfile.setAmcust(Utils.evaluateNumber(7, 0, _110501.get_1105i5()).intValue());    // SET
            /* TODO:Duplicate field [refnl4.setAmacbr()]*/amfile.setAmacbr(0);
            /* TODO:Duplicate field [refnl4.setAmacbr()]*/amfile.setAmacbr(Utils.evaluateNumber(3, 0, _110501.get_1105i4()).intValue());
            amfileKey = new Amfile();
            amfileKey.setAmoscd(/* TODO:Duplicate field [refnl4.getAmoscd()]*/amfile.getAmoscd());
            amfileKey.setAmcycd(/* TODO:Duplicate field [refnl4.getAmcycd()]*/amfile.getAmcycd());
            amfileKey.setAmaccd(/* TODO:Duplicate field [refnl4.getAmaccd()]*/amfile.getAmaccd());
            amfileKey.setAmcust(/* TODO:Duplicate field [refnl4.getAmcust()]*/amfile.getAmcust());
            amfileKey.setAmacbr(/* TODO:Duplicate field [refnl4.getAmacbr()]*/amfile.getAmacbr());
            amfileTemp = amfileDAO.selectFirstMatching(amfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
            offsetCtlAmfile.offsetClear();
            if (amfileTemp != null) {
                indicator.setIn90(false);
                amfile = amfileTemp;
            } else {
                indicator.setIn90(true);
            }
            if (indicator.getIn90() == true) {
                _110501.set_1105o1("3");

            }
            if (indicator.getIn90() == true) {
                break;

            }
            if (indicator.getIn90() == false) {
                if (Utils.rTrim(/* TODO:Duplicate field [refnl4.getAmflg1()]*/amfile.getAmflg1()).equals(Utils.rTrim("1"))) {
                    _110501.set_1105o1("3");
                } else {
                    if (indicator.getIn91() == true) {
                        _110501.set_1105o1("8");

                    }

                }

            }

        }
        break;
    }

}
// *
indicator.setIn90(false);
if (Utils.rTrim(_110501.get_1105i7()).equals(Utils.rTrim("3"))) {
    indicator.setIn90(true);

}
if (indicator.getIn90() == false) {
    indicator.setIn91(false);
    if (Utils.rTrim(_110501.get_1105i7()).equals(Utils.rTrim("6"))) {
        indicator.setIn91(true);

    }

}
if (indicator.getIn90() == true || indicator.getIn91() == true) {
    for (wkidxfor8 = 1; wkidxfor8 <= 1 ; wkidxfor8++) {
        _110501.set_1105o2("3");
        if (_110501.get_1105i6().equals(0)) {
            _110501.set_1105o1("2");
        } else {
            if (Utils.rTrim(_110501.get_1105id()).equals(Utils.rTrim("2"))) {
                indicator.setIn90(false);
                if (_110501.get_1105i1().equals(_110501.get_1105ia())) {
                    indicator.setIn90(true);

                }
                if (indicator.getIn90() == true) {
                    indicator.setIn90(false);
                    if (_110501.get_1105i2().equals(_110501.get_1105ib())) {
                        indicator.setIn90(true);

                    }

                }
                if (indicator.getIn90() == true) {
                    indicator.setIn90(false);
                    if (_110501.get_1105i6().equals(_110501.get_1105ic())) {
                        indicator.setIn90(true);

                    }

                }
                if (indicator.getIn90() == false) {
                    _110501.set_1105o1("4");

                }
                if (indicator.getIn90() == false) {
                    break;

                }

            }
            /* TODO:Duplicate field [refnl4.setAmoscd()]*/amfile.setAmoscd(0);
            /* TODO:Duplicate field [refnl4.setAmoscd()]*/amfile.setAmoscd(Utils.evaluateNumber(1, 0, _110501.get_1105i1()).intValue());    // AMFILE
            /* TODO:Duplicate field [refnl4.setAmcycd()]*/amfile.setAmcycd(0);
            /* TODO:Duplicate field [refnl4.setAmcycd()]*/amfile.setAmcycd(Utils.evaluateNumber(3, 0, _110501.get_1105i2()).intValue());    // KEY FIELD
            /* TODO:Duplicate field [refnl4.setAmaccd()]*/amfile.setAmaccd(0);
            /* TODO:Duplicate field [refnl4.setAmaccd()]*/amfile.setAmaccd(Utils.evaluateNumber(7, 0, _110501.get_1105i3()).intValue());    // DATA
            /* TODO:Duplicate field [refnl4.setAmcust()]*/amfile.setAmcust(0);
            /* TODO:Duplicate field [refnl4.setAmcust()]*/amfile.setAmcust(Utils.evaluateNumber(7, 0, _110501.get_1105i6()).intValue());    // SET
            /* TODO:Duplicate field [refnl4.setAmacbr()]*/amfile.setAmacbr(0);
            /* TODO:Duplicate field [refnl4.setAmacbr()]*/amfile.setAmacbr(Utils.evaluateNumber(3, 0, _110501.get_1105i4()).intValue());
            amfileKey = new Amfile();
            amfileKey.setAmoscd(/* TODO:Duplicate field [refnl4.getAmoscd()]*/amfile.getAmoscd());
            amfileKey.setAmcycd(/* TODO:Duplicate field [refnl4.getAmcycd()]*/amfile.getAmcycd());
            amfileKey.setAmaccd(/* TODO:Duplicate field [refnl4.getAmaccd()]*/amfile.getAmaccd());
            amfileKey.setAmcust(/* TODO:Duplicate field [refnl4.getAmcust()]*/amfile.getAmcust());
            amfileKey.setAmacbr(/* TODO:Duplicate field [refnl4.getAmacbr()]*/amfile.getAmacbr());
            amfileTemp = amfileDAO.selectFirstMatching(amfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
            offsetCtlAmfile.offsetClear();
            if (amfileTemp != null) {
                indicator.setIn90(false);
                amfile = amfileTemp;
            } else {
                indicator.setIn90(true);
            }
            if (indicator.getIn90() == true) {
                _110501.set_1105o1("3");

            }
            if (indicator.getIn90() == true) {
                break;

            }
            if (indicator.getIn90() == false) {
                if (Utils.rTrim(/* TODO:Duplicate field [refnl4.getAmflg1()]*/amfile.getAmflg1()).equals(Utils.rTrim("1"))) {
                    _110501.set_1105o1("3");
                } else {
                    if (indicator.getIn91() == true) {
                        _110501.set_1105o1("8");

                    }

                }

            }

        }
    }

}
// *
}
_110501.set_1105d1(Utils.move(_110501.get_1105d1(), 42, _110501.get_1105n1(), 43));    // NEW ==> OLD
_110501.set_1105d2(_110501.get_1105n2());    // NEW ==> OLD

}

}

// ****************************************************
// ****      #108 ACCOUNT.ACNO.ACBR CHECK SUB-RTN *****
// ****************************************************
private void _1108() {
_110801.set_1108ot(" ");
_110801.set_1108o1(" ");
_110801.set_1108o2(" ");
_110801.set_1108o3(0);
_110801.set_1108o4(0);
_110801.set_1108o5(0);
_110801.set_1108o6(0);
_110801.set_1108o7(0);
// #108W1が数字の検査
indicator.setIn90(false);
if (Integer.valueOf(Utils.check(CNSNUM1, Utils.substring(_110801.get_1108w1(), 1, 8))).equals(0) && Integer.valueOf(Utils.check(CNSNUM2, Utils.substring(_110801.get_1108w1(), 9, 1))).equals(0)) {
indicator.setIn90(true);

}
if (indicator.getIn90() == true) {
indicator.setIn90(false);
if (Utils.rTrim(_110801.get_1108w3()).equals(Utils.rTrim(" "))) {
indicator.setIn90(true);

}

}
// *
if (indicator.getIn90() == true) {    // A/C BY CUSTMOER
for (wkidxfor9 = 1; wkidxfor9 <= 1 ; wkidxfor9++) {
_110801.set_1108o2("2");
/* TODO:Duplicate field [refnl4.setAmrefb()]*/amfile.setAmrefb(0L);
/* TODO:Duplicate field [refnl4.setAmrefb()]*/amfile.setAmrefb(Utils.evaluateNumber(11, 0, _110801.get_1108w2()).longValue());
refnl4Key = new Refnl4();
refnl4Key.setAmrefb(/* TODO:Duplicate field [refnl4.getAmrefb()]*/amfile.getAmrefb());
refnl4Temp = refnl4DAO.selectFirstMatching(refnl4Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
offsetCtlRefnl4.offsetClear();
if (refnl4Temp != null) {
    indicator.setIn91(false);
    refnl4 = refnl4Temp;
} else {
    indicator.setIn91(true);
}
if (indicator.getIn91() == true) {
    _110801.set_1108ot("1");
    _110801.set_1108o1("5");
    break;

}
acfileKey = new Acfile();
acfileKey.setAcincd(/* TODO:Duplicate field [refnl4.getAmaccd()]*/amfile.getAmaccd());
acfileTemp = acfileDAO.selectFirstMatching(acfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
offsetCtlAcfile.offsetClear();
if (acfileTemp != null) {
    indicator.setIn91(false);
    acfile = acfileTemp;
} else {
    indicator.setIn91(true);
}
if (!_110801.get_1108i2().equals(0)) {
    _110801.set_1108ot("1");
    _110801.set_1108o1("7");
    break;

}
_110801.set_1108o5(/* TODO:Duplicate field [refnl4.getAmoscd()]*/amfile.getAmoscd());
_110801.set_1108o6(/* TODO:Duplicate field [refnl4.getAmcycd()]*/amfile.getAmcycd());
_110801.set_1108o3(/* TODO:Duplicate field [extnl1.getAcincd()]*/acfile.getAcincd());
_110801.set_1108o7(/* TODO:Duplicate field [refnl4.getAmcust()]*/amfile.getAmcust());
_110801.set_1108o4(/* TODO:Duplicate field [refnl4.getAmacbr()]*/amfile.getAmacbr());
}
// *
} else {    // ABRR OR EXCD
// *
for (wkidxfor10 = 1; wkidxfor10 <= 1 ; wkidxfor10++) {
_110801.set_1108o2("1");
_102401.set_124in(_110801.get_1108i1());
_124();
if (!Utils.rTrim(_102401.get_124ot()).equals(Utils.rTrim(" "))) {
    _110801.set_1108ot("1");
    _110801.set_1108o1(_102401.get_124ot());
    break;

}
if (Utils.rTrim(/* TODO:Duplicate field [extnl1.getActmcd()]*/acfile.getActmcd()).equals(Utils.rTrim("1"))) {
    _110801.set_1108ot("1");
    _110801.set_1108o1("3");
    break;

}
// GBS-1027-A
if (!Utils.rTrim(/* TODO:Duplicate field [extnl1.getAcplcd()]*/acfile.getAcplcd()).equals(Utils.rTrim(" ")) || !Utils.rTrim(/* TODO:Duplicate field [extnl1.getAcfxcd()]*/acfile.getAcfxcd()).equals(Utils.rTrim(" ")) || !Utils.rTrim(/* TODO:Duplicate field [extnl1.getAcepcd()]*/acfile.getAcepcd()).equals(Utils.rTrim(" "))) {    // "
    _110801.set_1108o2("3");

}
if (!Utils.rTrim(/* TODO:Duplicate field [extnl1.getAccd21()]*/acfile.getAccd21()).equals(Utils.rTrim(" "))) {    // TRAN A/C FLAG
    _110801.set_1108o2("4");

}
if (!Utils.rTrim(/* TODO:Duplicate field [extnl1.getAccd23()]*/acfile.getAccd23()).equals(Utils.rTrim(" "))) {    // RECEIVABLE FLAG
    _110801.set_1108o2("5");

}
if (Utils.rTrim(_110801.get_1108i3()).equals(Utils.rTrim("0"))) {
    if (_110801.get_1108o2().compareTo("2") > 0) {
        _110801.set_1108ot("1");
        _110801.set_1108o1("4");
        break;

    }

}
//ndz-del-s
//if (/* TODO:Duplicate field [extnl1.getAcamcd()]*/acfile.getAcamcd().compareTo("2") >= 0) {
//ndz-del-e
//ndz-add-s
if (Utils.rTrim(extnl1.getAcamcd()).compareTo("2") >= 0) {
//ndz-add-e
    if (_110801.get_1108i2().equals(0)) {
        _110801.set_1108ot("1");
        _110801.set_1108o1("8");
        break;

    }

}
//ndz-del-s
//if (/* TODO:Duplicate field [extnl1.getAcamcd()]*/acfile.getAcamcd().compareTo("2") < 0) {
//ndz-del-e
//ndz-add-s
if (Utils.rTrim(extnl1.getAcamcd()).compareTo("2") < 0) {
//ndz-add-e
    if (!_110801.get_1108i2().equals(0)) {
        _110801.set_1108ot("1");
        _110801.set_1108o1("7");
        break;

    }

}
if (Utils.rTrim(/* TODO:Duplicate field [extnl1.getAccd20()]*/acfile.getAccd20()).equals(Utils.rTrim("1"))) {
    _110801.set_1108ot("1");
    _110801.set_1108o1("6");
    break;

}
_110801.set_1108o3(/* TODO:Duplicate field [extnl1.getAcincd()]*/acfile.getAcincd());
_110801.set_1108o4(_110801.get_1108i2());
}
// *

}

}

// ****************************************************
// ****      #111  VAT CODE PICK UP   SUB-RTN     *****
// ****************************************************
private void _1111() {
_111101.set_1111ot(" ");
_111101.set_1111o1(" ");
indicator.setIn90(false);
indicator.setIn91(false);
if (Utils.rTrim(_111101.get_1111i1()).equals(Utils.rTrim(""))) {    // VAT = X
if (!Utils.rTrim(_111101.get_1111i3()).equals(Utils.rTrim(""))) {
if (Utils.rTrim(_111101.get_1111i3()).equals(Utils.rTrim("0"))) {
    _111101.set_1111ot(" ");
    _111101.set_1111o1("0");
} else {
    _111101.set_1111ot("1");    // ERR RETRN CODE
    _111101.set_1111o1("0");

}
} else {
_111101.set_1111ot(" ");
_111101.set_1111o1("0");

}

}
if (Utils.rTrim(_111101.get_1111i1()).equals(Utils.rTrim("1"))) {
if (!Utils.rTrim(_111101.get_1111i3()).equals(Utils.rTrim(""))) {
cdfile.setCdkey1("027");
cdfile.setCdkey2("       ");
cdfile.setCdkey2(Utils.movel(cdfile.getCdkey2(), 7, _111101.get_1111i3(), 1));
cdfileKey = new Cdfile();
cdfileKey.setCdkey1(cdfile.getCdkey1());
cdfileKey.setCdkey2(cdfile.getCdkey2());
cdfileTemp = cdfileDAO.selectFirstMatching(cdfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
offsetCtlCdfile.offsetClear();
if (cdfileTemp != null) {
    indicator.setIn90(false);
    cdfile = cdfileTemp;
} else {
    indicator.setIn90(true);
}
if (indicator.getIn90() == true) {
    _111101.set_1111ot("1");    // VAT ERR

}
if (indicator.getIn90() == false) {
    _111101.set_1111ot(" ");    // OK

}
if (indicator.getIn90() == false) {
    _111101.set_1111o1(_111101.get_1111i3());    // INPUT VAT SET

}
} else {
cofileKey = new Cofile();
cofileKey.setCocode(_111101.get_1111i2());
cofileTemp = cofileDAO.selectFirstMatching(cofileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
offsetCtlCofile.offsetClear();
if (cofileTemp != null) {
    indicator.setIn91(false);
    cofile = cofileTemp;
} else {
    indicator.setIn91(true);
}
if (indicator.getIn91() == true) {
    _111101.set_1111ot(" ");    // SYSTEM ERR

}
if (indicator.getIn91() == true) {
    _111101.set_1111o1("0");

}
if (indicator.getIn91() == false) {
    _111101.set_1111ot(" ");    // OK
    if (Utils.rTrim(cofile.getCoflg5()).equals(Utils.rTrim("1"))) {
        _111101.set_1111o1("3");
    } else {
        _111101.set_1111o1("2");

    }

}

}

}

}

private void _1157() {
_115701.set_1157ot(" ");    // *INITIAL SET
rrncl = 0;
rrncl = 0;    // //
wktted = 0;
wktted = 0;    // //
indicator.setIn80(false);    // *INITIAL SET
rrncl = 0;
rrncl = Utils.evaluateNumber(5, 0, 1).intValue();    // *RRN INIT SET
clfileKey = new Clfile();
clfileKey.setClbrno(rrncl);
//ndz-del-s
// // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CHAIN] original-code : 3155.00:C     RRNCL         CHAIN     CLRECD                             99        *CONTROL FILE
// // FIXME [CLFILE]テーブルに悲観ロックが必要な可能性があります。必要な場合は最後の引数に「LockModeType.PESSIMISTIC_READ」を追加してください
// clfileTemp = clfileDAO.selectFirstMatching(clfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
//ndz-del-e
offsetCtlClfile.offsetClear();
if (clfileTemp != null) {
indicator.setIn99(false);
clfile = clfileTemp;
} else {
indicator.setIn99(true);
}    // *CONTROL FILE
clfile.setCltctr(Utils.evaluateNumber(5, 0, clfile.getCltctr() + 1).intValue());    // *TT.SEQ COUNTER
//ndz-del-s
// // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[UPDATE] original-code : 3159.00:C                   UPDATE    CLRECD
// // FIXME [CLFILE]テーブルに悲観ロックが必要な可能性があります。必要な場合は手動変換で対応してください
// clfileDAO.update(clfile);
//ndz-del-e
/* TODO:Duplicate field [refnl2.setTtseqn()]*/ttfile.setTtseqn(0);
/* TODO:Duplicate field [refnl2.setTtseqn()]*/ttfile.setTtseqn(Utils.evaluateNumber(5, 0, clfile.getCltctr()).intValue());    // *TT.SEQ NO SET
wktted = new BigDecimal(DateTimeFormatter.ofPattern("HHmmss").format(LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), DateTimeFormatter.ISO_LOCAL_TIME))).intValue();    // *TIME SET
/* TODO:Duplicate field [refnl2.setTttted()]*/ttfile.setTttted(0);
/* TODO:Duplicate field [refnl2.setTttted()]*/ttfile.setTttted(Utils.evaluateNumber(7, 0, wktted).intValue());    // //
try {
ttfileDAO.insert(ttfile);
indicator.setIn99(false);
} catch (Exception e) {
indicator.setIn99(true);
throw new RuntimeException(e);
}    // *TTFILE WRITE
if (indicator.getIn99() == true) {
_115701.set_1157ot("1");

}

}    // *#157 ENDSR

// ****************************************************
// ****    #177   OP NO. AUTO-GET   SUB-RTN       *****
// ****************************************************
private void _1177() {
_117702.set_1177o1(0);
_117702.set_1177o1(0);
_117701.set_1177in(_117702.get_1177i1());
nufile.setNucod1(0);
nufile.setNucod1(Utils.evaluateNumber(5, 0, 99).intValue());
nufile.setNucod2(0);
nufile.setNucod2(Utils.evaluateNumber(5, 0, _117701.get_1177id()).intValue());
nufileKey = new Nufile();
nufileKey.setNucod1(nufile.getNucod1());
nufileKey.setNucod2(nufile.getNucod2());
//ndz-del-s
// // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CHAIN] original-code : 3182.00:C     KEYNU         CHAIN     NURECD                             80
// //                                  0360.00:C     KEYNU         KLIST
// //                                  0361.00:C                   KFLD                    NUCOD1
// //                                  0362.00:C                   KFLD                    NUCOD2
// // FIXME [NUFILE]テーブルに悲観ロックが必要な可能性があります。必要な場合は最後の引数に「LockModeType.PESSIMISTIC_READ」を追加してください
// nufileTemp = nufileDAO.selectFirstMatching(nufileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
//ndz-del-e
offsetCtlNufile.offsetClear();
if (nufileTemp != null) {
indicator.setIn80(false);
nufile = nufileTemp;
} else {
indicator.setIn80(true);
}
if (indicator.getIn80() == false) {
_117703.set_1177no(0L);
_117703.set_1177no(Utils.evaluateNumber(11, 0, nufile.getNunumb()).longValue());
_117703.set_1177n3(0L);
_117703.set_1177n3(Utils.evaluateNumber(11, 0, nufile.getNunumb()).longValue());
if (_117703.get_1177n2().equals(9999)) {
_1177a1.set_1177ac(_1177ar[1]);
_1177a1.set_1177ad(_117702.get_1177i1());
_1177a2 = BigDecimal.ZERO;
_1177a2 = Utils.evaluateNumber(15, 5, 80);
this.qcmdexcService.doMain();
// TODO FFRPG to Javaコンバータ - 未対応命令です  命令[EXCEPT] original-code : 3195.00:C                   EXCEPT    #177NU                                       CHG MTB-207
// FIXME ツール未対応命令です    // CHG MTB-207
indicator.setInLR(true);
// TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[RETURN] original-code : 3197.00:C                   RETURN
// FIXME 命令[RETURN] は手動変換が必要です
} else {
_117703.set_1177n2(Utils.evaluateNumber(4, 0, _117703.get_1177n2() + 1).intValue());

}
if (_117703.get_1177n2() >= 9000) {
_1177a1.set_1177ac(_1177ar[2]);
_1177a1.set_1177ad(_117702.get_1177i1());
_1177a2 = BigDecimal.ZERO;
_1177a2 = Utils.evaluateNumber(15, 5, 80);
this.qcmdexcService.doMain();

}
_117703.set_1177n3(Utils.move(_117703.get_1177n3(), 11, 0, _117703.get_1177n2(), 4, 0).longValue());
nufile.setNunumb(0L);
nufile.setNunumb(Utils.evaluateNumber(11, 0, _117703.get_1177n3()).longValue());
//ndz-del-s
// // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[UPDATE] original-code : 3214.00:C                   UPDATE    NURECD
// // FIXME [NUFILE]テーブルに悲観ロックが必要な可能性があります。必要な場合は手動変換で対応してください
// nufileDAO.update(nufile);
//ndz-del-e

}
if (indicator.getIn80() == true) {
nufile.setNubrno(0);
nufile.setNubrno(Utils.evaluateNumber(3, 0, parm0.getPabrno()).intValue());
nufile.setNuusn1(0);
nufile.setNuusn1(0);
nufile.setNuusn2(0);
nufile.setNuusn2(0);
_117703.set_1177n1(0);
_117703.set_1177n1(Utils.evaluateNumber(6, 0, 1).intValue());
_117703.set_1177n4(0);
_117703.set_1177n4(Utils.evaluateNumber(2, 0, _117701.get_1177id()).intValue());
nufile.setNunumb(0L);
nufile.setNunumb(Utils.evaluateNumber(11, 0, _117703.get_1177n1()).longValue());
nufile.setNuflg1(" ");
nufile.setNuflg2(" ");
nufile.setNuflg3(" ");
nufile.setNuflg4(" ");
nufile.setNuflg5(" ");
nufile.setNursrv("          ");
try {
nufileDAO.insert(nufile);
indicator.setIn80(false);
} catch (Exception e) {
indicator.setIn80(true);
throw new RuntimeException(e);
}

}
_117702.set_1177o1(0);
_117702.set_1177o1(Utils.evaluateNumber(6, 0, _117703.get_1177n1()).intValue());

}

/**
 * {@inheritDoc}
 */
@Override
public void func01Action(Os771dViewDTO dto) {
setMemberVariables(dto);
// TODO 手動変換の対応が必要です
// FIXME 機能01処理を実装してください
        
// 画面表示前にメンバ変数データを保持
setLogicDTO();
}
    
/**
 * {@inheritDoc}
 */
@Override
public void func03Action(Os771dViewDTO dto) {
setMemberVariables(dto);
// TODO 手動変換の対応が必要です
// FIXME 機能03処理を実装してください
        
// 画面表示前にメンバ変数データを保持
setLogicDTO();
}
    
/**
 * 画面(os771d1)内容をクリア.
 */
private void clearOs771d1() {
dto.setWstrcd(0);
dto.setWsrefn(0L);
}
/**
 * 画面(os771d2)内容をクリア.
 */
private void clearOs771d2() {
dto.setWsopno("");
dto.setWsrefo("");
dto.setWsoscd("");
dto.setWscycd("");
dto.setWsvdt1("");
dto.setWsvdt2("");
dto.setWsvdt3("");
dto.setWsfecd("");
dto.setWsfcf1("");
dto.setWsfcf2("");
dto.setWsfcf3("");
dto.setWsfct1("");
dto.setWsfct2("");
dto.setWsfct3("");
dto.setWsamnt(BigDecimal.ZERO);
dto.setWsacno(0);
dto.setWssbcd("");
dto.setWsnsos("");
dto.setWsnsac("");
dto.setWsnsab(0);
dto.setWsnsbk("");
dto.setWslref(0L);
dto.setWsapno("");
dto.setWscust("");
dto.setWsvatc("");
dto.setWsacrf("");
dto.setWsrate(BigDecimal.ZERO);
dto.setWssprd(BigDecimal.ZERO);
dto.setWsccd1("");
dto.setWsccd2("");
dto.setWsrmk1("");
dto.setWsrmk2("");
dto.setWsthei("");
dto.setWsflag("");
}
/**
 * 画面(os771d3)内容をクリア.
 */
private void clearOs771d3() {
dto.setWsactn("");
}
/**
 * LogicDTOからメンバ変数へ設定.
 */
private void setMemberVariables(Os771dViewDTO dto) {
this.indicator = dto.getIndicator();
this.dto = dto;

this.fgfll1 = this.logicDTO.getFgfll1();
this.fgfll1Key = this.logicDTO.getFgfll1Key();
this.fgfll1Temp = this.logicDTO.getFgfll1Temp();
this.offsetCtlFgfll1 = this.logicDTO.getOffsetCtlFgfll1();
this.cyfile = this.logicDTO.getCyfile();
this.cyfileKey = this.logicDTO.getCyfileKey();
this.cyfileTemp = this.logicDTO.getCyfileTemp();
this.offsetCtlCyfile = this.logicDTO.getOffsetCtlCyfile();
this.cyfll1 = this.logicDTO.getCyfll1();
this.cyfll1Key = this.logicDTO.getCyfll1Key();
this.cyfll1Temp = this.logicDTO.getCyfll1Temp();
this.offsetCtlCyfll1 = this.logicDTO.getOffsetCtlCyfll1();
this.acfile = this.logicDTO.getAcfile();
this.acfileKey = this.logicDTO.getAcfileKey();
this.acfileTemp = this.logicDTO.getAcfileTemp();
this.offsetCtlAcfile = this.logicDTO.getOffsetCtlAcfile();
this.extnl1 = this.logicDTO.getExtnl1();
this.extnl1Key = this.logicDTO.getExtnl1Key();
this.extnl1Temp = this.logicDTO.getExtnl1Temp();
this.offsetCtlExtnl1 = this.logicDTO.getOffsetCtlExtnl1();
this.cmfile = this.logicDTO.getCmfile();
this.cmfileKey = this.logicDTO.getCmfileKey();
this.cmfileTemp = this.logicDTO.getCmfileTemp();
this.offsetCtlCmfile = this.logicDTO.getOffsetCtlCmfile();
this.amfile = this.logicDTO.getAmfile();
this.amfileKey = this.logicDTO.getAmfileKey();
this.amfileTemp = this.logicDTO.getAmfileTemp();
this.offsetCtlAmfile = this.logicDTO.getOffsetCtlAmfile();
this.refnl4 = this.logicDTO.getRefnl4();
this.refnl4Key = this.logicDTO.getRefnl4Key();
this.refnl4Temp = this.logicDTO.getRefnl4Temp();
this.offsetCtlRefnl4 = this.logicDTO.getOffsetCtlRefnl4();
this.cdfile = this.logicDTO.getCdfile();
this.cdfileKey = this.logicDTO.getCdfileKey();
this.cdfileTemp = this.logicDTO.getCdfileTemp();
this.offsetCtlCdfile = this.logicDTO.getOffsetCtlCdfile();
this.cofile = this.logicDTO.getCofile();
this.cofileKey = this.logicDTO.getCofileKey();
this.cofileTemp = this.logicDTO.getCofileTemp();
this.offsetCtlCofile = this.logicDTO.getOffsetCtlCofile();
this.tatable = this.logicDTO.getTatable();
this.tatableKey = this.logicDTO.getTatableKey();
this.tatableTemp = this.logicDTO.getTatableTemp();
this.offsetCtlTatable = this.logicDTO.getOffsetCtlTatable();
this.tafll1 = this.logicDTO.getTafll1();
this.tafll1Key = this.logicDTO.getTafll1Key();
this.tafll1Temp = this.logicDTO.getTafll1Temp();
this.offsetCtlTafll1 = this.logicDTO.getOffsetCtlTafll1();
this.refnl2 = this.logicDTO.getRefnl2();
this.refnl2Key = this.logicDTO.getRefnl2Key();
this.refnl2Temp = this.logicDTO.getRefnl2Temp();
this.offsetCtlRefnl2 = this.logicDTO.getOffsetCtlRefnl2();
this.clfile = this.logicDTO.getClfile();
this.clfileKey = this.logicDTO.getClfileKey();
this.clfileTemp = this.logicDTO.getClfileTemp();
this.offsetCtlClfile = this.logicDTO.getOffsetCtlClfile();
this.nufile = this.logicDTO.getNufile();
this.nufileKey = this.logicDTO.getNufileKey();
this.nufileTemp = this.logicDTO.getNufileTemp();
this.offsetCtlNufile = this.logicDTO.getOffsetCtlNufile();
this.dmfll3 = this.logicDTO.getDmfll3();
this.dmfll3Key = this.logicDTO.getDmfll3Key();
this.dmfll3Temp = this.logicDTO.getDmfll3Temp();
this.offsetCtlDmfll3 = this.logicDTO.getOffsetCtlDmfll3();
this.ttfile = this.logicDTO.getTtfile();
this.ttfileKey = this.logicDTO.getTtfileKey();
this.ttfileTemp = this.logicDTO.getTtfileTemp();
this.offsetCtlTtfile = this.logicDTO.getOffsetCtlTtfile();
this._1177ar = this.logicDTO.get_1177ar();
this.wkrefn = this.logicDTO.getWkrefn();
this.wkusn1 = this.logicDTO.getWkusn1();
this.wkusn2 = this.logicDTO.getWkusn2();
this.wkstat = this.logicDTO.getWkstat();
this.wkflg1 = this.logicDTO.getWkflg1();
this.wkflg2 = this.logicDTO.getWkflg2();
this.wkflg3 = this.logicDTO.getWkflg3();
this.wkcode = this.logicDTO.getWkcode();
this.wksupp = this.logicDTO.getWksupp();
this.wkvldt = this.logicDTO.getWkvldt();
this.wkfenm = this.logicDTO.getWkfenm();
this.wkfefg = this.logicDTO.getWkfefg();
this.wkcdf3 = this.logicDTO.getWkcdf3();
this.wkfcfm = this.logicDTO.getWkfcfm();
this.wkfcto = this.logicDTO.getWkfcto();
this.wkact3 = this.logicDTO.getWkact3();
this.wkfacc = this.logicDTO.getWkfacc();
this.wkfacn = this.logicDTO.getWkfacn();
this.wkdrcr = this.logicDTO.getWkdrcr();
this.wkac05 = this.logicDTO.getWkac05();
this.wkac25 = this.logicDTO.getWkac25();
this.wkot61 = this.logicDTO.getWkot61();
this.wktacd = this.logicDTO.getWktacd();
this.wka3ac = this.logicDTO.getWka3ac();
this.wkb3ac = this.logicDTO.getWkb3ac();
this.wkc3ac = this.logicDTO.getWkc3ac();
this.wkd3ac = this.logicDTO.getWkd3ac();
this.wke4ac = this.logicDTO.getWke4ac();
this.wkf4ac = this.logicDTO.getWkf4ac();
this.wknfg1 = this.logicDTO.getWknfg1();
this.wknfg2 = this.logicDTO.getWknfg2();
this.wknfg3 = this.logicDTO.getWknfg3();
this.wkocd4 = this.logicDTO.getWkocd4();
this.wkcur4 = this.logicDTO.getWkcur4();
this.wkexcd = this.logicDTO.getWkexcd();
this.wkabbr = this.logicDTO.getWkabbr();
this.wkname = this.logicDTO.getWkname();
this.wkamcd = this.logicDTO.getWkamcd();
this.wkac07 = this.logicDTO.getWkac07();
this.wkac24 = this.logicDTO.getWkac24();
this.w108o1 = this.logicDTO.getW108o1();
this.w108o2 = this.logicDTO.getW108o2();
this.w108o3 = this.logicDTO.getW108o3();
this.w108o4 = this.logicDTO.getW108o4();
this.w108o5 = this.logicDTO.getW108o5();
this.w108o6 = this.logicDTO.getW108o6();
this.w108o7 = this.logicDTO.getW108o7();
this.wknsbc = this.logicDTO.getWknsbc();
this.wknsbn = this.logicDTO.getWknsbn();
this.wkcust = this.logicDTO.getWkcust();
this.wkcnm1 = this.logicDTO.getWkcnm1();
this.wkcnm2 = this.logicDTO.getWkcnm2();
this.wkcocd = this.logicDTO.getWkcocd();
this.wkvatc = this.logicDTO.getWkvatc();
this.wkofcd = this.logicDTO.getWkofcd();
this.wkofnm = this.logicDTO.getWkofnm();
this.wkoffm = this.logicDTO.getWkoffm();
this.wkofto = this.logicDTO.getWkofto();
this.wkofam = this.logicDTO.getWkofam();
this.wkofac = this.logicDTO.getWkofac();
this.wkofan = this.logicDTO.getWkofan();
this.wkonos = this.logicDTO.getWkonos();
this.wkoncy = this.logicDTO.getWkoncy();
this.wkonac = this.logicDTO.getWkonac();
this.wkonab = this.logicDTO.getWkonab();
this.wkonae = this.logicDTO.getWkonae();
this.wkonan = this.logicDTO.getWkonan();
this.wkonbc = this.logicDTO.getWkonbc();
this.wkonbn = this.logicDTO.getWkonbn();
this.wkolrf = this.logicDTO.getWkolrf();
this.wkoapn = this.logicDTO.getWkoapn();
this.wkocst = this.logicDTO.getWkocst();
this.wkoctb = this.logicDTO.getWkoctb();
this.wkocn1 = this.logicDTO.getWkocn1();
this.wkocn2 = this.logicDTO.getWkocn2();
this.wkovat = this.logicDTO.getWkovat();
this.wkoarf = this.logicDTO.getWkoarf();
this.wkorat = this.logicDTO.getWkorat();
this.wkospr = this.logicDTO.getWkospr();
this.wkocc1 = this.logicDTO.getWkocc1();
this.wkocc2 = this.logicDTO.getWkocc2();
this.wkormk = this.logicDTO.getWkormk();
this.wkothe = this.logicDTO.getWkothe();
this.wkoflg = this.logicDTO.getWkoflg();
this.wkprfg = this.logicDTO.getWkprfg();
this.wktime = this.logicDTO.getWktime();
this.wkcoos = this.logicDTO.getWkcoos();
this._123wk1 = this.logicDTO.get_123wk1();
this._124wk1 = this.logicDTO.get_124wk1();
this._127ot = this.logicDTO.get_127ot();
this._127in1 = this.logicDTO.get_127in1();
this._127in2 = this.logicDTO.get_127in2();
this._127in3 = this.logicDTO.get_127in3();
this.wktted = this.logicDTO.getWktted();
this.rrncl = this.logicDTO.getRrncl();
this._1177a2 = this.logicDTO.get_1177a2();
this.wkidxmov = this.logicDTO.getWkidxmov();
this.wkidxmov2 = this.logicDTO.getWkidxmov2();
this.wkidxfor1 = this.logicDTO.getWkidxfor1();
this.wkidxfor2 = this.logicDTO.getWkidxfor2();
this.wkidxfor3 = this.logicDTO.getWkidxfor3();
this.wkidxfor4 = this.logicDTO.getWkidxfor4();
this.wkidxfor5 = this.logicDTO.getWkidxfor5();
this.wkidxfor6 = this.logicDTO.getWkidxfor6();
this.wkidxfor7 = this.logicDTO.getWkidxfor7();
this.wkidxfor8 = this.logicDTO.getWkidxfor8();
this.wkidxfor9 = this.logicDTO.getWkidxfor9();
this.wkidxfor10 = this.logicDTO.getWkidxfor10();
this.wkidxfor11 = this.logicDTO.getWkidxfor11();
this.wkidxfor12 = this.logicDTO.getWkidxfor12();
this.wkidxfor13 = this.logicDTO.getWkidxfor13();
this.wkcatvar = this.logicDTO.getWkcatvar();
this.wkcatvarlen = this.logicDTO.getWkcatvarlen();
this.wkcatblank = this.logicDTO.getWkcatblank();
this.ttara1 = this.logicDTO.getTtara1();
this.ttara2 = this.logicDTO.getTtara2();
this.parm0 = this.logicDTO.getParm0();
this.parm09 = this.logicDTO.getParm09();
this.parm10 = this.logicDTO.getParm10();
this.parma5 = this.logicDTO.getParma5();
this.ds001 = this.logicDTO.getDs001();
this.ds002 = this.logicDTO.getDs002();
this.ds003 = this.logicDTO.getDs003();
this.ds004 = this.logicDTO.getDs004();
this.ds005 = this.logicDTO.getDs005();
this.ds006 = this.logicDTO.getDs006();
this.ds007 = this.logicDTO.getDs007();
this.ds008 = this.logicDTO.getDs008();
this.ds009 = this.logicDTO.getDs009();
this.ds010 = this.logicDTO.getDs010();
this.ds011 = this.logicDTO.getDs011();
this.ds012 = this.logicDTO.getDs012();
this.ds013 = this.logicDTO.getDs013();
this._102301 = this.logicDTO.get_102301();
this._102401 = this.logicDTO.get_102401();
this._110201 = this.logicDTO.get_110201();
this._110501 = this.logicDTO.get_110501();
this._110801 = this.logicDTO.get_110801();
this._111101 = this.logicDTO.get_111101();
this._115701 = this.logicDTO.get_115701();
this._117701 = this.logicDTO.get_117701();
this._117702 = this.logicDTO.get_117702();
this._117703 = this.logicDTO.get_117703();
this._1177a1 = this.logicDTO.get_1177a1();
}

/**
 * メンバ変数からLogicDTOへ設定.
 */
private void setLogicDTO() {
this.logicDTO.setFgfll1(this.fgfll1);
this.logicDTO.setFgfll1Key(this.fgfll1Key);
this.logicDTO.setFgfll1Temp(this.fgfll1Temp);
this.logicDTO.setOffsetCtlFgfll1(this.offsetCtlFgfll1);
this.logicDTO.setCyfile(this.cyfile);
this.logicDTO.setCyfileKey(this.cyfileKey);
this.logicDTO.setCyfileTemp(this.cyfileTemp);
this.logicDTO.setOffsetCtlCyfile(this.offsetCtlCyfile);
this.logicDTO.setCyfll1(this.cyfll1);
this.logicDTO.setCyfll1Key(this.cyfll1Key);
this.logicDTO.setCyfll1Temp(this.cyfll1Temp);
this.logicDTO.setOffsetCtlCyfll1(this.offsetCtlCyfll1);
this.logicDTO.setAcfile(this.acfile);
this.logicDTO.setAcfileKey(this.acfileKey);
this.logicDTO.setAcfileTemp(this.acfileTemp);
this.logicDTO.setOffsetCtlAcfile(this.offsetCtlAcfile);
this.logicDTO.setExtnl1(this.extnl1);
this.logicDTO.setExtnl1Key(this.extnl1Key);
this.logicDTO.setExtnl1Temp(this.extnl1Temp);
this.logicDTO.setOffsetCtlExtnl1(this.offsetCtlExtnl1);
this.logicDTO.setCmfile(this.cmfile);
this.logicDTO.setCmfileKey(this.cmfileKey);
this.logicDTO.setCmfileTemp(this.cmfileTemp);
this.logicDTO.setOffsetCtlCmfile(this.offsetCtlCmfile);
this.logicDTO.setAmfile(this.amfile);
this.logicDTO.setAmfileKey(this.amfileKey);
this.logicDTO.setAmfileTemp(this.amfileTemp);
this.logicDTO.setOffsetCtlAmfile(this.offsetCtlAmfile);
this.logicDTO.setRefnl4(this.refnl4);
this.logicDTO.setRefnl4Key(this.refnl4Key);
this.logicDTO.setRefnl4Temp(this.refnl4Temp);
this.logicDTO.setOffsetCtlRefnl4(this.offsetCtlRefnl4);
this.logicDTO.setCdfile(this.cdfile);
this.logicDTO.setCdfileKey(this.cdfileKey);
this.logicDTO.setCdfileTemp(this.cdfileTemp);
this.logicDTO.setOffsetCtlCdfile(this.offsetCtlCdfile);
this.logicDTO.setCofile(this.cofile);
this.logicDTO.setCofileKey(this.cofileKey);
this.logicDTO.setCofileTemp(this.cofileTemp);
this.logicDTO.setOffsetCtlCofile(this.offsetCtlCofile);
this.logicDTO.setTatable(this.tatable);
this.logicDTO.setTatableKey(this.tatableKey);
this.logicDTO.setTatableTemp(this.tatableTemp);
this.logicDTO.setOffsetCtlTatable(this.offsetCtlTatable);
this.logicDTO.setTafll1(this.tafll1);
this.logicDTO.setTafll1Key(this.tafll1Key);
this.logicDTO.setTafll1Temp(this.tafll1Temp);
this.logicDTO.setOffsetCtlTafll1(this.offsetCtlTafll1);
this.logicDTO.setRefnl2(this.refnl2);
this.logicDTO.setRefnl2Key(this.refnl2Key);
this.logicDTO.setRefnl2Temp(this.refnl2Temp);
this.logicDTO.setOffsetCtlRefnl2(this.offsetCtlRefnl2);
this.logicDTO.setClfile(this.clfile);
this.logicDTO.setClfileKey(this.clfileKey);
this.logicDTO.setClfileTemp(this.clfileTemp);
this.logicDTO.setOffsetCtlClfile(this.offsetCtlClfile);
this.logicDTO.setNufile(this.nufile);
this.logicDTO.setNufileKey(this.nufileKey);
this.logicDTO.setNufileTemp(this.nufileTemp);
this.logicDTO.setOffsetCtlNufile(this.offsetCtlNufile);
this.logicDTO.setDmfll3(this.dmfll3);
this.logicDTO.setDmfll3Key(this.dmfll3Key);
this.logicDTO.setDmfll3Temp(this.dmfll3Temp);
this.logicDTO.setOffsetCtlDmfll3(this.offsetCtlDmfll3);
this.logicDTO.setTtfile(this.ttfile);
this.logicDTO.setTtfileKey(this.ttfileKey);
this.logicDTO.setTtfileTemp(this.ttfileTemp);
this.logicDTO.setOffsetCtlTtfile(this.offsetCtlTtfile);
this.logicDTO.set_1177ar(this._1177ar);
this.logicDTO.setWkrefn(this.wkrefn);
this.logicDTO.setWkusn1(this.wkusn1);
this.logicDTO.setWkusn2(this.wkusn2);
this.logicDTO.setWkstat(this.wkstat);
this.logicDTO.setWkflg1(this.wkflg1);
this.logicDTO.setWkflg2(this.wkflg2);
this.logicDTO.setWkflg3(this.wkflg3);
this.logicDTO.setWkcode(this.wkcode);
this.logicDTO.setWksupp(this.wksupp);
this.logicDTO.setWkvldt(this.wkvldt);
this.logicDTO.setWkfenm(this.wkfenm);
this.logicDTO.setWkfefg(this.wkfefg);
this.logicDTO.setWkcdf3(this.wkcdf3);
this.logicDTO.setWkfcfm(this.wkfcfm);
this.logicDTO.setWkfcto(this.wkfcto);
this.logicDTO.setWkact3(this.wkact3);
this.logicDTO.setWkfacc(this.wkfacc);
this.logicDTO.setWkfacn(this.wkfacn);
this.logicDTO.setWkdrcr(this.wkdrcr);
this.logicDTO.setWkac05(this.wkac05);
this.logicDTO.setWkac25(this.wkac25);
this.logicDTO.setWkot61(this.wkot61);
this.logicDTO.setWktacd(this.wktacd);
this.logicDTO.setWka3ac(this.wka3ac);
this.logicDTO.setWkb3ac(this.wkb3ac);
this.logicDTO.setWkc3ac(this.wkc3ac);
this.logicDTO.setWkd3ac(this.wkd3ac);
this.logicDTO.setWke4ac(this.wke4ac);
this.logicDTO.setWkf4ac(this.wkf4ac);
this.logicDTO.setWknfg1(this.wknfg1);
this.logicDTO.setWknfg2(this.wknfg2);
this.logicDTO.setWknfg3(this.wknfg3);
this.logicDTO.setWkocd4(this.wkocd4);
this.logicDTO.setWkcur4(this.wkcur4);
this.logicDTO.setWkexcd(this.wkexcd);
this.logicDTO.setWkabbr(this.wkabbr);
this.logicDTO.setWkname(this.wkname);
this.logicDTO.setWkamcd(this.wkamcd);
this.logicDTO.setWkac07(this.wkac07);
this.logicDTO.setWkac24(this.wkac24);
this.logicDTO.setW108o1(this.w108o1);
this.logicDTO.setW108o2(this.w108o2);
this.logicDTO.setW108o3(this.w108o3);
this.logicDTO.setW108o4(this.w108o4);
this.logicDTO.setW108o5(this.w108o5);
this.logicDTO.setW108o6(this.w108o6);
this.logicDTO.setW108o7(this.w108o7);
this.logicDTO.setWknsbc(this.wknsbc);
this.logicDTO.setWknsbn(this.wknsbn);
this.logicDTO.setWkcust(this.wkcust);
this.logicDTO.setWkcnm1(this.wkcnm1);
this.logicDTO.setWkcnm2(this.wkcnm2);
this.logicDTO.setWkcocd(this.wkcocd);
this.logicDTO.setWkvatc(this.wkvatc);
this.logicDTO.setWkofcd(this.wkofcd);
this.logicDTO.setWkofnm(this.wkofnm);
this.logicDTO.setWkoffm(this.wkoffm);
this.logicDTO.setWkofto(this.wkofto);
this.logicDTO.setWkofam(this.wkofam);
this.logicDTO.setWkofac(this.wkofac);
this.logicDTO.setWkofan(this.wkofan);
this.logicDTO.setWkonos(this.wkonos);
this.logicDTO.setWkoncy(this.wkoncy);
this.logicDTO.setWkonac(this.wkonac);
this.logicDTO.setWkonab(this.wkonab);
this.logicDTO.setWkonae(this.wkonae);
this.logicDTO.setWkonan(this.wkonan);
this.logicDTO.setWkonbc(this.wkonbc);
this.logicDTO.setWkonbn(this.wkonbn);
this.logicDTO.setWkolrf(this.wkolrf);
this.logicDTO.setWkoapn(this.wkoapn);
this.logicDTO.setWkocst(this.wkocst);
this.logicDTO.setWkoctb(this.wkoctb);
this.logicDTO.setWkocn1(this.wkocn1);
this.logicDTO.setWkocn2(this.wkocn2);
this.logicDTO.setWkovat(this.wkovat);
this.logicDTO.setWkoarf(this.wkoarf);
this.logicDTO.setWkorat(this.wkorat);
this.logicDTO.setWkospr(this.wkospr);
this.logicDTO.setWkocc1(this.wkocc1);
this.logicDTO.setWkocc2(this.wkocc2);
this.logicDTO.setWkormk(this.wkormk);
this.logicDTO.setWkothe(this.wkothe);
this.logicDTO.setWkoflg(this.wkoflg);
this.logicDTO.setWkprfg(this.wkprfg);
this.logicDTO.setWktime(this.wktime);
this.logicDTO.setWkcoos(this.wkcoos);
this.logicDTO.set_123wk1(this._123wk1);
this.logicDTO.set_124wk1(this._124wk1);
this.logicDTO.set_127ot(this._127ot);
this.logicDTO.set_127in1(this._127in1);
this.logicDTO.set_127in2(this._127in2);
this.logicDTO.set_127in3(this._127in3);
this.logicDTO.setWktted(this.wktted);
this.logicDTO.setRrncl(this.rrncl);
this.logicDTO.set_1177a2(this._1177a2);
this.logicDTO.setWkidxmov(this.wkidxmov);
this.logicDTO.setWkidxmov2(this.wkidxmov2);
this.logicDTO.setWkidxfor1(this.wkidxfor1);
this.logicDTO.setWkidxfor2(this.wkidxfor2);
this.logicDTO.setWkidxfor3(this.wkidxfor3);
this.logicDTO.setWkidxfor4(this.wkidxfor4);
this.logicDTO.setWkidxfor5(this.wkidxfor5);
this.logicDTO.setWkidxfor6(this.wkidxfor6);
this.logicDTO.setWkidxfor7(this.wkidxfor7);
this.logicDTO.setWkidxfor8(this.wkidxfor8);
this.logicDTO.setWkidxfor9(this.wkidxfor9);
this.logicDTO.setWkidxfor10(this.wkidxfor10);
this.logicDTO.setWkidxfor11(this.wkidxfor11);
this.logicDTO.setWkidxfor12(this.wkidxfor12);
this.logicDTO.setWkidxfor13(this.wkidxfor13);
this.logicDTO.setWkcatvar(this.wkcatvar);
this.logicDTO.setWkcatvarlen(this.wkcatvarlen);
this.logicDTO.setWkcatblank(this.wkcatblank);
this.logicDTO.setTtara1(this.ttara1);
this.logicDTO.setTtara2(this.ttara2);
this.logicDTO.setParm0(this.parm0);
this.logicDTO.setParm09(this.parm09);
this.logicDTO.setParm10(this.parm10);
this.logicDTO.setParma5(this.parma5);
this.logicDTO.setDs001(this.ds001);
this.logicDTO.setDs002(this.ds002);
this.logicDTO.setDs003(this.ds003);
this.logicDTO.setDs004(this.ds004);
this.logicDTO.setDs005(this.ds005);
this.logicDTO.setDs006(this.ds006);
this.logicDTO.setDs007(this.ds007);
this.logicDTO.setDs008(this.ds008);
this.logicDTO.setDs009(this.ds009);
this.logicDTO.setDs010(this.ds010);
this.logicDTO.setDs011(this.ds011);
this.logicDTO.setDs012(this.ds012);
this.logicDTO.setDs013(this.ds013);
this.logicDTO.set_102301(this._102301);
this.logicDTO.set_102401(this._102401);
this.logicDTO.set_110201(this._110201);
this.logicDTO.set_110501(this._110501);
this.logicDTO.set_110801(this._110801);
this.logicDTO.set_111101(this._111101);
this.logicDTO.set_115701(this._115701);
this.logicDTO.set_117701(this._117701);
this.logicDTO.set_117702(this._117702);
this.logicDTO.set_117703(this._117703);
this.logicDTO.set_1177a1(this._1177a1);
}
// ****************************************************************
// 画面表示系の初期化
// ****************************************************************
private void _initCtlDispFlag() {
if (!this.ctlDispFlag) {
dto.setOs771d1(false);
dto.setOs771d2(false);
dto.setOs771d3(false);
dto.setOs771d3Readonly(false);
dto.setOs771d4(false);
dto.setOs771d4Readonly(false);
this.ctlDispFlag = true;
}
}
}
