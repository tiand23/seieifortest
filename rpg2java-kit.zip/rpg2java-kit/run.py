#!/usr/bin/env python3
"""rpg2java-kit 入口。

  python run.py detect              # java 命中哪些规则 + 缺哪些规则
  python run.py complete            # 补全(确定性 python + LLM 局部补)
  python run.py complete --no-llm   # 只跑确定性部分(不调 LLM)
  python run.py mine                # 客户环境: 从 diff 抽 skill
  python run.py validate            # 客户环境: 对人工版算匹配率
  python run.py [...] --config other.yaml
"""
import argparse
import sys
import pathlib

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

from rpg2java.config import Config
from rpg2java.modes import detect_mode, complete_mode, mine_mode, validate_mode, extract_mode, report_mode


def main():
    ap = argparse.ArgumentParser(prog="rpg2java-kit")
    ap.add_argument("mode", choices=["extract", "detect", "complete", "mine", "validate", "report"])
    ap.add_argument("--config", default=None)
    ap.add_argument("--no-llm", action="store_true", help="complete 时只跑确定性部分")
    args = ap.parse_args()

    cfg = Config.load(args.config)
    if args.mode == "extract":
        extract_mode.run(cfg)
    elif args.mode == "detect":
        detect_mode.run(cfg)
    elif args.mode == "complete":
        complete_mode.run(cfg, use_llm=not args.no_llm)
    elif args.mode == "mine":
        mine_mode.run(cfg)
    elif args.mode == "validate":
        validate_mode.run(cfg)
    elif args.mode == "report":
        report_mode.run(cfg)


if __name__ == "__main__":
    main()
