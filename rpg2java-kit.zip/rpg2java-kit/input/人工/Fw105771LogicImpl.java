package jp.mufg.tr.cats.os.os771.fw105771.logic;

//ndz-add-s
import java.math.BigDecimal;
//ndz-add-e
import jp.co.kobelcosys.ctd.common.batch.constants.SelectSqlPattern;
import jp.co.kobelcosys.ctd.common.utils.Utils;
//ndz-del-s
//import java.nio.charset.Charset;
//ndz-del-e
import jp.co.kobelcosys.ctd.common.vo.Indicator;
import jp.co.kobelcosys.ctd.common.da.OffsetControl;
import jp.mufg.tr.cats.table.ttfile.entity.Ttfile;
import jp.mufg.tr.cats.table.ttfile.dao.TtfileDAO;
import jp.mufg.tr.cats.table.fgfll1.entity.Fgfll1;
import jp.mufg.tr.cats.table.fgfll1.dao.Fgfll1DAO;
import jp.mufg.tr.cats.table.dmfile.entity.Dmfile;
import jp.mufg.tr.cats.table.dmfile.dao.DmfileDAO;
import jp.mufg.tr.cats.os.os771.fw105771.ds.Ttara1;
import jp.mufg.tr.cats.os.os771.fw105771.ds.Parm0;
import jp.mufg.tr.cats.os.os771.fw105771.ds.Parm02;
import jp.mufg.tr.cats.os.os771.fw105771.ds.Ds001;
import jp.mufg.tr.cats.os.os771.fw105771.ds.Ds002;
import jp.mufg.tr.cats.common.fw102006.vo.Fw102006VO;
import jp.mufg.tr.cats.common.fw102006.service.Fw102006Service;
import jp.mufg.tr.cats.os.os771.fw105771.vo.Fw105771VO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
//ndz-del-s
//import jp.co.kobelcosys.ctd.common.vo.Indicator;
//import java.util.HashMap;
//import java.util.Map;
//ndz-del-e

/**
 * FW105771 ロジック.
 **/
@Service
@Scope("prototype")
public class Fw105771LogicImpl implements Fw105771Logic {
    /** 標識. */
    private Indicator indicator = new Indicator();
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[RECNO] original-code : 0003.00:FTTFILE    IF   E             DISK
//    //                                  0004.00:F                                     RECNO(RRNTT)
//    // FIXME キーワード[RECNO] はツール未対応です
//ndz-del-e
    /** ttfile */
    private Ttfile ttfile = new Ttfile();
    /** ttfileKey */
    private Ttfile ttfileKey = new Ttfile();
    /** ttfileTemp */
    private Ttfile ttfileTemp = new Ttfile();
    /** offsetCtlTtfile */
    private OffsetControl offsetCtlTtfile = new OffsetControl();
    /** TTFILE DAO */
    @Autowired
    private TtfileDAO ttfileDAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0005.00:FFGFLL1    UF A E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** fgfll1 */
    private Fgfll1 fgfll1 = new Fgfll1();
    /** fgfll1Key */
    private Fgfll1 fgfll1Key = new Fgfll1();
    /** fgfll1Temp */
    private Fgfll1 fgfll1Temp = new Fgfll1();
    /** offsetCtlFgfll1 */
    private OffsetControl offsetCtlFgfll1 = new OffsetControl();
    /** FGFLL1 DAO */
    @Autowired
    private Fgfll1DAO fgfll1DAO;
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[KEYED] original-code : 0006.00:FDMFILE    IF A E           K DISK
//    // FIXME キーワード[KEYED] はツール未対応です
//ndz-del-e
    /** dmfile */
    private Dmfile dmfile = new Dmfile();
    /** dmfileKey */
    private Dmfile dmfileKey = new Dmfile();
    /** dmfileTemp */
    private Dmfile dmfileTemp = new Dmfile();
    /** offsetCtlDmfile */
    private OffsetControl offsetCtlDmfile = new OffsetControl();
    /** DMFILE DAO */
    @Autowired
    private DmfileDAO dmfileDAO;
//ndz-del-s
//    /** rrntt */
//    private Integer rrntt = 0;
//ndz-del-e
    /** _119in */
    private String _119in = "";
    /** ttara1 */
    private Ttara1 ttara1 = new Ttara1();
    /** parm0 */
    private Parm0 parm0 = new Parm0();
    /** parm02 */
    private Parm02 parm02 = new Parm02();
    /** ds001 */
    private Ds001 ds001 = new Ds001();
    /** ds002 */
    private Ds002 ds002 = new Ds002();
//ndz-del-s
//    // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  キーワード[DFTACTGRP] original-code : 0001.00:H DATEDIT(*MDY-)
//    // FIXME キーワード[DFTACTGRP] はツール未対応です
//ndz-del-e
    /** FW102006 パラメータVO */
    private Fw102006VO fw102006VO = new Fw102006VO();
    /** FW102006 Service */
    @Autowired
    private Fw102006Service fw102006Service;
    /** FW105771 パラメータVO */
    private Fw105771VO fw105771VO = new Fw105771VO();
//ndz-del-s
//    private final String DATEDIT = "Unsupported(/* FIXME 定数[*MDY-] はツール未対応です */)";
//ndz-del-e
    /**
     * デフォルトコンストラクタ.
     */
    public Fw105771LogicImpl() {
    }

    /**
     * メイン処理.
     */
    @Override
    public int main(Fw105771VO fw105771VO)  {
        // 更新件数
        int result = 0;
        this.fw105771VO = fw105771VO;
//ndz-add-s
        parm0.setData(this.fw105771VO.getParm0());
//ndz-add-e

        // ==========================================================================================
        // End of Parmeter definitions.
        // ==========================================================================================
        // ****************************************************
        // PREPARATION  < PLIST >                   *
        // ****************************************************
        // ****************************************************
        // PREPARATION  < KLIST >                   *
        // ****************************************************
        // DMFILE
        // ****************************************************
        // PROGRAM  MAIN  ROUTINE                   *
        // ****************************************************
//ndz-del-s
//        rrntt = 0;
//        rrntt = Utils.evaluateNumber(5, 0, parm0.getParrno()).intValue();
//ndz-del-e
//ndz-add-s
        ttfile.setTtcpu1(parm0.getPacpu1());
        ttfile.setTtcpu2(parm0.getPacpu2());
        ttfile.setTtcpu3(parm0.getPacpu3());
//ndz-add-e
        ttfileKey = new Ttfile();
//ndz-del-s
//        ttfileKey.setTtcpu1(rrntt);
//        ttfileTemp = ttfileDAO.selectFirstMatching(ttfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
//ndz-del-e
//ndz-add-s
        ttfileKey.setTtcpu1(ttfile.getTtcpu1());
        ttfileKey.setTtcpu2(ttfile.getTtcpu2());
        ttfileKey.setTtcpu3(ttfile.getTtcpu3());
        ttfileTemp = ttfileDAO.select(ttfileKey, SelectSqlPattern.GE, this.getClass().getSimpleName());
//ndz-add-e
        offsetCtlTtfile.offsetClear();
        if (ttfileTemp != null) {
            indicator.setIn80(false);
            ttfile = ttfileTemp;
        } else {
            indicator.setIn80(true);
        }
        if (indicator.getIn80() == false) {
//ndz-add-s
            ttara1.setData(ttfile.getTtara1()); 
//ndz-add-e
            _2schk1();
            if (indicator.getIn99() == true) {
                parm0.setPaercd(Utils.movel(parm0.getPaercd(), 1, "2", 1));
            } else {
                if (ttfile.getTttrcd().equals(60)) {
                    _2sfg01();    // FGFILE WRITE
                } else if (ttfile.getTttrcd().equals(61)) {
                    _2sfg02();    // FGFILE UPDATE
                } else if (ttfile.getTttrcd().equals(62)) {
                    _2sfg03();    // FGFILE DELETE
                } else if (ttfile.getTttrcd().equals(63)) {
                    _2sfg04();    // FGFILE CANCEL
                } else if (ttfile.getTttrcd().equals(10)) {
                    _2sfg05();    // FGFILE SETTLE
                }
                if (ttfile.getTttrcd().equals(60) || ttfile.getTttrcd().equals(63) || ttfile.getTttrcd().equals(10)) {
                    if (ttfile.getTtvldt() <= parm0.getPatody()) {
                        _2sam00();    // AMFILE INITL
//ndz-del-s
//                         ds002.setWkarx1(Utils.movel(ds002.getWkarx1(), 192, ttara1.getTtarx1(), 192));
//ndz-del-e
//ndz-add-s
                        ds002.setWkarx1(Utils.movel(ds002.getWkarx1(), 192, ttara1.getTtarx1(), 256));
//ndz-add-e
                        if (!Utils.rTrim(ttfile.getTtdrc3()).equals(Utils.rTrim(" "))) {    // * FEE A/C
                            _2sam01();    // AMFILE UPDATE
                            _2sdm01();    // DMFILE WRITE

                        }
                        if (!Utils.rTrim(ttfile.getTtdrc4()).equals(Utils.rTrim(" "))) {    // * NOSTRO A/C
                            _2sam02();    // AMFILE UPDATE
                            _2sdm02();    // DMFILE WRITE

                        }
                        if (!Utils.rTrim(ttfile.getTtdrc5()).equals(Utils.rTrim(" "))) {    // * I.U.A/C (1)
                            _2sam03();    // AMFILE UPDATE
                            _2sdm03();    // DMFILE WRITE

                        }
                        if (!Utils.rTrim(ttara1.getTtdrc6()).equals(Utils.rTrim(" "))) {    // * I.U.A/C (2)
                            _2sam04();    // AMFILE UPDATE
                            _2sdm04();    // DMFILE WRITE

                        }

                    }

                }

            }

        }
//ndz-add-s
        fw105771VO.setParm0(parm0.toString());
//ndz-add-e
        indicator.setInLR(true);
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[RETURN] original-code : 0118.00:C                   RETURN
//        // FIXME 命令[RETURN] は手動変換が必要です
//ndz-del-e

        return result;
    }

    // ****************************************************
    // MASTER FILE UPDATE CHECK PROCESS         *
    // ****************************************************
    private void _2schk1() {
        fgfll1Key = new Fgfll1();
        fgfll1Key.setFgrefn(ttfile.getTtrefn());
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CHAIN] original-code : 0125.00:C     TTREFN        CHAIN     FGRECD                             80        * FGFLL1 CHAIN
//        // FIXME [FGFLL1]テーブルに悲観ロックが必要な可能性があります。必要な場合は最後の引数に「LockModeType.PESSIMISTIC_READ」を追加してください
//ndz-del-e
        fgfll1Temp = fgfll1DAO.selectFirstMatching(fgfll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlFgfll1.offsetClear();
        if (fgfll1Temp != null) {
            indicator.setIn80(false);
            fgfll1 = fgfll1Temp;
        } else {
            indicator.setIn80(true);
        }    // * FGFLL1 CHAIN
        if (indicator.getIn80() == true) {    // * RECORD NOT FOUND
            if (ttfile.getTttrcd().equals(60)) {    // * TR CODE = 60
                indicator.setIn99(false);    // * NORMAL CASE
            } else {    // * TR CODE N= 60
                indicator.setIn99(true);    // * ERROR CASE

            }
        } else {    // * RECORD FOUND
            if (ttfile.getTttrcd().equals(60)) {    // * TR CODE = 60
                indicator.setIn99(true);    // * ERROR CASE
            } else {    // * TR CODE N= 60
                indicator.setIn99(false);    // * NORMAL CASE

            }
            if (indicator.getIn99() == false) {    // * NOT ERROR
                // * UPDATE DATE SAME ?
                if (ttfile.getTtts11().equals(fgfll1.getFgusn1()) && ttfile.getTtts12().equals(fgfll1.getFgusn2())) {    // * UPDATE NO SAME ?
                    indicator.setIn99(false);    // * NORMAL CASE
                } else {
                    // * UPDATE DATE SAME ?
                    if (!ttfile.getTtusn1().equals(fgfll1.getFgusn1()) || !ttfile.getTtusn2().equals(fgfll1.getFgusn2())) {    // * UPDATE NO SAME ?
                        indicator.setIn99(true);    // * ERROR CASE

                    }

                }

            }

        }

    }

    // ****************************************************
    // FGFILE  WRITE  PROCESS  ( TR = 60 )      *
    // ****************************************************
    private void _2sfg01() {
        fgfll1Key = new Fgfll1();
        fgfll1Key.setFgrefn(ttfile.getTtrefn());
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CHAIN] original-code : 0166.00:C     TTREFN        CHAIN     FGRECD                             80
//        // FIXME [FGFLL1]テーブルに悲観ロックが必要な可能性があります。必要な場合は最後の引数に「LockModeType.PESSIMISTIC_READ」を追加してください
//ndz-del-e
        fgfll1Temp = fgfll1DAO.selectFirstMatching(fgfll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlFgfll1.offsetClear();
        if (fgfll1Temp != null) {
            indicator.setIn80(false);
            fgfll1 = fgfll1Temp;
        } else {
            indicator.setIn80(true);
        }
        fgfll1.setFgbrno(0);
        fgfll1.setFgbrno(Utils.evaluateNumber(3, 0, ttfile.getTtbrno()).intValue());
        fgfll1.setFgoscd(0);
        fgfll1.setFgoscd(Utils.evaluateNumber(1, 0, ttfile.getTtocd3()).intValue());
        fgfll1.setFgcycd(0);
        fgfll1.setFgcycd(Utils.evaluateNumber(3, 0, ttfile.getTtcur3()).intValue());
        fgfll1.setFgaccd(0);
        fgfll1.setFgaccd(Utils.evaluateNumber(7, 0, ttfile.getTtact3()).intValue());
        fgfll1.setFgrefn(0L);
        fgfll1.setFgrefn(Utils.evaluateNumber(11, 0, ttfile.getTtrefn()).longValue());
        fgfll1.setFgvldt(0);
//ndz-del-s
//         fgfll1.setFgvldt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        fgfll1.setFgvldt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        fgfll1.setFgwsid(Utils.movel(fgfll1.getFgwsid(), 3, ttfile.getTtwsid(), 3));
        fgfll1.setFgusid(Utils.movel(fgfll1.getFgusid(), 2, ttfile.getTtusid(), 2));
        fgfll1.setFgusn1(0);
//ndz-del-s
//         fgfll1.setFgusn1(Utils.evaluateNumber(7, 0, ttfile.getTtusn1()).intValue());
//ndz-del-e
//ndz-add-s
        fgfll1.setFgusn1(Utils.evaluateNumber(8, 0, ttfile.getTtusn1()).intValue());
//ndz-add-e
        fgfll1.setFgusn2(0);
        fgfll1.setFgusn2(Utils.evaluateNumber(5, 0, ttfile.getTtusn2()).intValue());
        fgfll1.setFgostp(0);
        fgfll1.setFgostp(Utils.evaluateNumber(3, 0, ttfile.getTtostp()).intValue());
        if (ttfile.getTtvldt() > parm0.getPatody()) {
            fgfll1.setFgstat(Utils.movel(fgfll1.getFgstat(), 1, "0", 1));
        } else {
            fgfll1.setFgstat(Utils.movel(fgfll1.getFgstat(), 1, "6", 1));

        }
        fgfll1.setFgfecd(Utils.movel(fgfll1.getFgfecd(), 4, ttara1.getTtfecd(), 4));
        fgfll1.setFgfcfm(0);
//ndz-del-s
//         fgfll1.setFgfcfm(Utils.evaluateNumber(7, 0, ttara1.getTtfcfm()).intValue());
//ndz-del-e
//ndz-add-s
        fgfll1.setFgfcfm(Utils.evaluateNumber(8, 0, ttara1.getTtfcfm()).intValue());
//ndz-add-e
        fgfll1.setFgfcto(0);
//ndz-del-s
//         fgfll1.setFgfcto(Utils.evaluateNumber(7, 0, ttara1.getTtfcto()).intValue());
//ndz-del-e
//ndz-add-s
        fgfll1.setFgfcto(Utils.evaluateNumber(8, 0, ttara1.getTtfcto()).intValue());
//ndz-add-e
        fgfll1.setFgtamt(BigDecimal.ZERO);
        fgfll1.setFgtamt(Utils.evaluateNumber(15, 2, ttfile.getTtamt3()));
        if (Utils.rTrim(ttfile.getTtdrc3()).equals(Utils.rTrim("1"))) {
            fgfll1.setFgprcd(Utils.movel(fgfll1.getFgprcd(), 1, "P", 1));

        }
        if (Utils.rTrim(ttfile.getTtdrc3()).equals(Utils.rTrim("2"))) {
            fgfll1.setFgprcd(Utils.movel(fgfll1.getFgprcd(), 1, "R", 1));

        }
        fgfll1.setFgcosb(Utils.movel(fgfll1.getFgcosb(), 1, ttara1.getTtsbcd(), 1));
        fgfll1.setFgcoos(0);
        fgfll1.setFgcoos(Utils.evaluateNumber(1, 0, ttfile.getTtocd4()).intValue());
        fgfll1.setFgcocy(0);
        fgfll1.setFgcocy(Utils.evaluateNumber(3, 0, ttfile.getTtcur4()).intValue());
        fgfll1.setFgcoac(0);
        fgfll1.setFgcoac(Utils.evaluateNumber(7, 0, ttfile.getTtact4()).intValue());
        fgfll1.setFgcoct(0);
        fgfll1.setFgcoct(Utils.evaluateNumber(7, 0, ttfile.getTtcst4()).intValue());
        fgfll1.setFgacbr(0);
        fgfll1.setFgacbr(Utils.evaluateNumber(3, 0, ttfile.getTtacb4()).intValue());
        fgfll1.setFgrefb(0L);
        fgfll1.setFgrefb(Utils.evaluateNumber(11, 0, ttfile.getTtrefb()).longValue());
        fgfll1.setFglref(0L);
        fgfll1.setFglref(Utils.evaluateNumber(11, 0, ttara1.getTtlref()).longValue());
        fgfll1.setFgapno(Utils.movel(fgfll1.getFgapno(), 14, ttara1.getTtapno(), 14));
        fgfll1.setFgcust(0);
        fgfll1.setFgcust(Utils.evaluateNumber(7, 0, ttara1.getTtcust()).intValue());
        fgfll1.setFgvatc(Utils.movel(fgfll1.getFgvatc(), 1, ttara1.getTtvatc(), 1));
        fgfll1.setFgacrf(Utils.movel(fgfll1.getFgacrf(), 1, ttara1.getTtacrf(), 1));
        fgfll1.setFgrate(BigDecimal.ZERO);
        fgfll1.setFgrate(Utils.evaluateNumber(9, 7, ttara1.getTtrate()));
        fgfll1.setFgsprd(BigDecimal.ZERO);
        fgfll1.setFgsprd(Utils.evaluateNumber(9, 7, ttara1.getTtsprd()));
        fgfll1.setFgccd1(Utils.movel(fgfll1.getFgccd1(), 1, ttara1.getTtccd1(), 1));
        fgfll1.setFgccd2(Utils.movel(fgfll1.getFgccd2(), 1, ttara1.getTtccd2(), 1));
        fgfll1.setFgrmks(Utils.movel(fgfll1.getFgrmks(), 60, ttara1.getTtrmks(), 60));
        fgfll1.setFgthei(Utils.movel(fgfll1.getFgthei(), 15, ttara1.getTtthei(), 15));
        fgfll1.setFghgfg(Utils.movel(fgfll1.getFghgfg(), 1, ttara1.getTthgfg(), 1));
        fgfll1.setFgsect(Utils.movel(fgfll1.getFgsect(), 3, ttfile.getTtsect(), 3));
        ds001.setWkflag(Utils.movel(ds001.getWkflag(), 10, ttara1.getTtflag(), 10));
        fgfll1.setFgflg1(Utils.movel(fgfll1.getFgflg1(), 1, ds001.getWkflg1(), 1));
        fgfll1.setFgflg2(Utils.movel(fgfll1.getFgflg2(), 1, ds001.getWkflg2(), 1));
        fgfll1.setFgflg3(Utils.movel(fgfll1.getFgflg3(), 1, ds001.getWkflg3(), 1));
        fgfll1.setFgflg4(Utils.movel(fgfll1.getFgflg4(), 1, ds001.getWkflg4(), 1));
        fgfll1.setFgflg5(Utils.movel(fgfll1.getFgflg5(), 1, ds001.getWkflg5(), 1));
        fgfll1.setFgflg6(Utils.movel(fgfll1.getFgflg6(), 1, ds001.getWkflg6(), 1));
        fgfll1.setFgflg7(Utils.movel(fgfll1.getFgflg7(), 1, ds001.getWkflg7(), 1));
        fgfll1.setFgflg8(Utils.movel(fgfll1.getFgflg8(), 1, ds001.getWkflg8(), 1));
        fgfll1.setFgflg9(Utils.movel(fgfll1.getFgflg9(), 1, ds001.getWkflg9(), 1));
        fgfll1.setFgfg10(Utils.movel(fgfll1.getFgfg10(), 1, ds001.getWkfg10(), 1));
        fgfll1.setFgrsrv("                    ");
        fgfll1DAO.insert(fgfll1);

    }

    // ****************************************************
    // FGFILE  UPDATE  PROCESS  ( TR = 61 )     *
    // ****************************************************
    private void _2sfg02() {
        fgfll1Key = new Fgfll1();
        fgfll1Key.setFgrefn(ttfile.getTtrefn());
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CHAIN] original-code : 0244.00:C     TTREFN        CHAIN     FGRECD                             80
//        // FIXME [FGFLL1]テーブルに悲観ロックが必要な可能性があります。必要な場合は最後の引数に「LockModeType.PESSIMISTIC_READ」を追加してください
//ndz-del-e
        fgfll1Temp = fgfll1DAO.selectFirstMatching(fgfll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlFgfll1.offsetClear();
        if (fgfll1Temp != null) {
            indicator.setIn80(false);
            fgfll1 = fgfll1Temp;
        } else {
            indicator.setIn80(true);
        }
        fgfll1.setFgoscd(0);
        fgfll1.setFgoscd(Utils.evaluateNumber(1, 0, ttfile.getTtocd3()).intValue());
        fgfll1.setFgcycd(0);
        fgfll1.setFgcycd(Utils.evaluateNumber(3, 0, ttfile.getTtcur3()).intValue());
        fgfll1.setFgaccd(0);
        fgfll1.setFgaccd(Utils.evaluateNumber(7, 0, ttfile.getTtact3()).intValue());
        fgfll1.setFgvldt(0);
//ndz-del-s
//         fgfll1.setFgvldt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        fgfll1.setFgvldt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        fgfll1.setFgusn1(0);
//ndz-del-s
//         fgfll1.setFgusn1(Utils.evaluateNumber(7, 0, ttfile.getTtusn1()).intValue());
//ndz-del-e
//ndz-add-s
        fgfll1.setFgusn1(Utils.evaluateNumber(8, 0, ttfile.getTtusn1()).intValue());
//ndz-add-e
        fgfll1.setFgusn2(0);
        fgfll1.setFgusn2(Utils.evaluateNumber(5, 0, ttfile.getTtusn2()).intValue());
        fgfll1.setFgfecd(Utils.movel(fgfll1.getFgfecd(), 4, ttara1.getTtfecd(), 4));
        fgfll1.setFgfcfm(0);
//ndz-del-s
//         fgfll1.setFgfcfm(Utils.evaluateNumber(7, 0, ttara1.getTtfcfm()).intValue());
//ndz-del-e
//ndz-add-s
        fgfll1.setFgfcfm(Utils.evaluateNumber(8, 0, ttara1.getTtfcfm()).intValue());
//ndz-add-e
        fgfll1.setFgfcto(0);
//ndz-del-s
//         fgfll1.setFgfcto(Utils.evaluateNumber(7, 0, ttara1.getTtfcto()).intValue());
//ndz-del-e
//ndz-add-s
        fgfll1.setFgfcto(Utils.evaluateNumber(8, 0, ttara1.getTtfcto()).intValue());
//ndz-add-e
        fgfll1.setFgtamt(BigDecimal.ZERO);
        fgfll1.setFgtamt(Utils.evaluateNumber(15, 2, ttfile.getTtamt3()));
        if (Utils.rTrim(ttfile.getTtdrc3()).equals(Utils.rTrim("1"))) {
            fgfll1.setFgprcd(Utils.movel(fgfll1.getFgprcd(), 1, "P", 1));

        }
        if (Utils.rTrim(ttfile.getTtdrc3()).equals(Utils.rTrim("2"))) {
            fgfll1.setFgprcd(Utils.movel(fgfll1.getFgprcd(), 1, "R", 1));

        }
        fgfll1.setFgcosb(Utils.movel(fgfll1.getFgcosb(), 1, ttara1.getTtsbcd(), 1));
        fgfll1.setFgcoos(0);
        fgfll1.setFgcoos(Utils.evaluateNumber(1, 0, ttfile.getTtocd4()).intValue());
        fgfll1.setFgcocy(0);
        fgfll1.setFgcocy(Utils.evaluateNumber(3, 0, ttfile.getTtcur4()).intValue());
        fgfll1.setFgcoac(0);
        fgfll1.setFgcoac(Utils.evaluateNumber(7, 0, ttfile.getTtact4()).intValue());
        fgfll1.setFgcoct(0);
        fgfll1.setFgcoct(Utils.evaluateNumber(7, 0, ttfile.getTtcst4()).intValue());
        fgfll1.setFgacbr(0);
        fgfll1.setFgacbr(Utils.evaluateNumber(3, 0, ttfile.getTtacb4()).intValue());
        fgfll1.setFgrefb(0L);
        fgfll1.setFgrefb(Utils.evaluateNumber(11, 0, ttfile.getTtrefb()).longValue());
        fgfll1.setFglref(0L);
        fgfll1.setFglref(Utils.evaluateNumber(11, 0, ttara1.getTtlref()).longValue());
        fgfll1.setFgapno(Utils.movel(fgfll1.getFgapno(), 14, ttara1.getTtapno(), 14));
        fgfll1.setFgcust(0);
        fgfll1.setFgcust(Utils.evaluateNumber(7, 0, ttara1.getTtcust()).intValue());
        fgfll1.setFgvatc(Utils.movel(fgfll1.getFgvatc(), 1, ttara1.getTtvatc(), 1));
        fgfll1.setFgacrf(Utils.movel(fgfll1.getFgacrf(), 1, ttara1.getTtacrf(), 1));
        fgfll1.setFgrate(BigDecimal.ZERO);
        fgfll1.setFgrate(Utils.evaluateNumber(9, 7, ttara1.getTtrate()));
        fgfll1.setFgsprd(BigDecimal.ZERO);
        fgfll1.setFgsprd(Utils.evaluateNumber(9, 7, ttara1.getTtsprd()));
        fgfll1.setFgccd1(Utils.movel(fgfll1.getFgccd1(), 1, ttara1.getTtccd1(), 1));
        fgfll1.setFgccd2(Utils.movel(fgfll1.getFgccd2(), 1, ttara1.getTtccd2(), 1));
        fgfll1.setFgrmks(Utils.movel(fgfll1.getFgrmks(), 60, ttara1.getTtrmks(), 60));
        fgfll1.setFgthei(Utils.movel(fgfll1.getFgthei(), 15, ttara1.getTtthei(), 15));
        fgfll1.setFghgfg(Utils.movel(fgfll1.getFghgfg(), 1, ttara1.getTthgfg(), 1));
        ds001.setWkflag(Utils.movel(ds001.getWkflag(), 10, ttara1.getTtflag(), 10));
        fgfll1.setFgflg1(Utils.movel(fgfll1.getFgflg1(), 1, ds001.getWkflg1(), 1));
        fgfll1.setFgflg2(Utils.movel(fgfll1.getFgflg2(), 1, ds001.getWkflg2(), 1));
        fgfll1.setFgflg3(Utils.movel(fgfll1.getFgflg3(), 1, ds001.getWkflg3(), 1));
        fgfll1.setFgflg4(Utils.movel(fgfll1.getFgflg4(), 1, ds001.getWkflg4(), 1));
        fgfll1.setFgflg5(Utils.movel(fgfll1.getFgflg5(), 1, ds001.getWkflg5(), 1));
        fgfll1.setFgflg6(Utils.movel(fgfll1.getFgflg6(), 1, ds001.getWkflg6(), 1));
        fgfll1.setFgflg7(Utils.movel(fgfll1.getFgflg7(), 1, ds001.getWkflg7(), 1));
        fgfll1.setFgflg8(Utils.movel(fgfll1.getFgflg8(), 1, ds001.getWkflg8(), 1));
        fgfll1.setFgflg9(Utils.movel(fgfll1.getFgflg9(), 1, ds001.getWkflg9(), 1));
        fgfll1.setFgfg10(Utils.movel(fgfll1.getFgfg10(), 1, ds001.getWkfg10(), 1));
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[UPDATE] original-code : 0299.00:C                   UPDATE    FGRECD
//        // FIXME [FGFLL1]テーブルに悲観ロックが必要な可能性があります。必要な場合は手動変換で対応してください
//ndz-del-e
        fgfll1DAO.update(fgfll1);

    }

    // ****************************************************
    // FGFILE  DELETE  PROCESS  ( TR = 62 )     *
    // ****************************************************
    private void _2sfg03() {
        fgfll1Key = new Fgfll1();
        fgfll1Key.setFgrefn(ttfile.getTtrefn());
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CHAIN] original-code : 0308.00:C     TTREFN        CHAIN     FGRECD                             80
//        // FIXME [FGFLL1]テーブルに悲観ロックが必要な可能性があります。必要な場合は最後の引数に「LockModeType.PESSIMISTIC_READ」を追加してください
//ndz-del-e
        fgfll1Temp = fgfll1DAO.selectFirstMatching(fgfll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlFgfll1.offsetClear();
        if (fgfll1Temp != null) {
            indicator.setIn80(false);
            fgfll1 = fgfll1Temp;
        } else {
            indicator.setIn80(true);
        }
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[DELETE] original-code : 0310.00:C                   DELETE    FGRECD
//        // FIXME [FGFLL1]テーブルに悲観ロックが必要な可能性があります。必要な場合は手動変換で対応してください
//ndz-del-e
        fgfll1DAO.delete(fgfll1);

    }

    // ****************************************************
    // FGFILE  CANCEL  PROCESS  ( TR = 63 )     *
    // ****************************************************
    private void _2sfg04() {
        fgfll1Key = new Fgfll1();
        fgfll1Key.setFgrefn(ttfile.getTtrefn());
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CHAIN] original-code : 0319.00:C     TTREFN        CHAIN     FGRECD                             80
//        // FIXME [FGFLL1]テーブルに悲観ロックが必要な可能性があります。必要な場合は最後の引数に「LockModeType.PESSIMISTIC_READ」を追加してください
//ndz-del-e
        fgfll1Temp = fgfll1DAO.selectFirstMatching(fgfll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlFgfll1.offsetClear();
        if (fgfll1Temp != null) {
            indicator.setIn80(false);
            fgfll1 = fgfll1Temp;
        } else {
            indicator.setIn80(true);
        }
        fgfll1.setFgusn1(0);
//ndz-del-s
//         fgfll1.setFgusn1(Utils.evaluateNumber(7, 0, ttfile.getTtusn1()).intValue());
//ndz-del-e
//ndz-add-s
        fgfll1.setFgusn1(Utils.evaluateNumber(8, 0, ttfile.getTtusn1()).intValue());
//ndz-add-e
        fgfll1.setFgusn2(0);
        fgfll1.setFgusn2(Utils.evaluateNumber(5, 0, ttfile.getTtusn2()).intValue());
        fgfll1.setFgstat(Utils.movel(fgfll1.getFgstat(), 1, "7", 1));
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[UPDATE] original-code : 0326.00:C                   UPDATE    FGRECD
//        // FIXME [FGFLL1]テーブルに悲観ロックが必要な可能性があります。必要な場合は手動変換で対応してください
//ndz-del-e
        fgfll1DAO.update(fgfll1);

    }

    // ****************************************************
    // FGFILE  SETTLE  PROCESS  ( TR = 10 )     *
    // ****************************************************
    private void _2sfg05() {
        fgfll1Key = new Fgfll1();
        fgfll1Key.setFgrefn(ttfile.getTtrefn());
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[CHAIN] original-code : 0335.00:C     TTREFN        CHAIN     FGRECD                             80
//        // FIXME [FGFLL1]テーブルに悲観ロックが必要な可能性があります。必要な場合は最後の引数に「LockModeType.PESSIMISTIC_READ」を追加してください
//ndz-del-e
        fgfll1Temp = fgfll1DAO.selectFirstMatching(fgfll1Key, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlFgfll1.offsetClear();
        if (fgfll1Temp != null) {
            indicator.setIn80(false);
            fgfll1 = fgfll1Temp;
        } else {
            indicator.setIn80(true);
        }
        fgfll1.setFgusn1(0);
//ndz-del-s
//         fgfll1.setFgusn1(Utils.evaluateNumber(7, 0, ttfile.getTtusn1()).intValue());
//ndz-del-e
//ndz-add-s
        fgfll1.setFgusn1(Utils.evaluateNumber(8, 0, ttfile.getTtusn1()).intValue());
//ndz-add-e
        fgfll1.setFgusn2(0);
        fgfll1.setFgusn2(Utils.evaluateNumber(5, 0, ttfile.getTtusn2()).intValue());
        fgfll1.setFgstat(Utils.movel(fgfll1.getFgstat(), 1, "6", 1));
//ndz-del-s
//        // TODO FFRPG to Javaコンバータ - 手動変換の対応が必要です  命令[UPDATE] original-code : 0342.00:C                   UPDATE    FGRECD
//        // FIXME [FGFLL1]テーブルに悲観ロックが必要な可能性があります。必要な場合は手動変換で対応してください
//ndz-del-e
        fgfll1DAO.update(fgfll1);

    }

    // ****************************************************
    // AMFILE  UPDATE  INITIAL  PROCESS         *
    // ****************************************************
    private void _2sam00() {
        parm02.setP2brno(0);
        parm02.setP2brno(Utils.evaluateNumber(3, 0, ttfile.getTtbrno()).intValue());
        parm02.setP2usn1(0);
//ndz-del-s
//         parm02.setP2usn1(Utils.evaluateNumber(7, 0, ttfile.getTtusn1()).intValue());
//ndz-del-e
//ndz-add-s
        parm02.setP2usn1(Utils.evaluateNumber(8, 0, ttfile.getTtusn1()).intValue());
//ndz-add-e
        parm02.setP2usn2(0);
        parm02.setP2usn2(Utils.evaluateNumber(5, 0, ttfile.getTtusn2()).intValue());
        parm02.setP2vldt(0);
//ndz-del-s
//         parm02.setP2vldt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        parm02.setP2vldt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        parm02.setP2ckcd(Utils.movel(parm02.getP2ckcd(), 1, "0", 1));
        parm02.setP2tody(0);
//ndz-del-s
//         parm02.setP2tody(Utils.evaluateNumber(7, 0, ttfile.getTtindt()).intValue());
//ndz-del-e
//ndz-add-s
        parm02.setP2tody(Utils.evaluateNumber(8, 0, ttfile.getTtindt()).intValue());
//ndz-add-e
        parm02.setP2flg1(Utils.movel(parm02.getP2flg1(), 1, parm0.getPastlf(), 1));

    }

    // ****************************************************
    // AMFILE  UPDATE  PROCESS  ( FEE A/C )     *
    // ****************************************************
    private void _2sam01() {
        parm02.setP2oscd(0);
        parm02.setP2oscd(Utils.evaluateNumber(1, 0, ttfile.getTtocd3()).intValue());
        parm02.setP2cycd(0);
        parm02.setP2cycd(Utils.evaluateNumber(3, 0, ttfile.getTtcur3()).intValue());
        parm02.setP2accd(0);
        parm02.setP2accd(Utils.evaluateNumber(7, 0, ttfile.getTtact3()).intValue());
        parm02.setP2cust(0);
        parm02.setP2cust(Utils.evaluateNumber(7, 0, ttfile.getTtcst3()).intValue());
        parm02.setP2acbr(0);
        parm02.setP2acbr(Utils.evaluateNumber(3, 0, ttfile.getTtacb3()).intValue());
        parm02.setP2drcr(Utils.movel(parm02.getP2drcr(), 1, ttfile.getTtdrc3(), 1));
        parm02.setP2amnt(BigDecimal.ZERO);
        parm02.setP2amnt(Utils.evaluateNumber(15, 2, ttfile.getTtamt3()));
        this.fw102006VO.setParm02(parm02.toString());
        this.fw102006Service.doMain(this.fw102006VO);
        parm02.setData(this.fw102006VO.getParm02());

    }

    // ****************************************************
    // AMFILE  UPDATE  PROCESS  ( NOSTRO A/C )  *
    // ****************************************************
    private void _2sam02() {
        parm02.setP2oscd(0);
        parm02.setP2oscd(Utils.evaluateNumber(1, 0, ttfile.getTtocd4()).intValue());
        parm02.setP2cycd(0);
        parm02.setP2cycd(Utils.evaluateNumber(3, 0, ttfile.getTtcur4()).intValue());
        parm02.setP2accd(0);
        parm02.setP2accd(Utils.evaluateNumber(7, 0, ttfile.getTtact4()).intValue());
        parm02.setP2cust(0);
        parm02.setP2cust(Utils.evaluateNumber(7, 0, ttfile.getTtcst4()).intValue());
        parm02.setP2acbr(0);
        parm02.setP2acbr(Utils.evaluateNumber(3, 0, ttfile.getTtacb4()).intValue());
        parm02.setP2drcr(Utils.movel(parm02.getP2drcr(), 1, ttfile.getTtdrc4(), 1));
        parm02.setP2amnt(BigDecimal.ZERO);
        parm02.setP2amnt(Utils.evaluateNumber(15, 2, ttfile.getTtamt4()));
        this.fw102006VO.setParm02(parm02.toString());
        this.fw102006Service.doMain(this.fw102006VO);
        parm02.setData(this.fw102006VO.getParm02());

    }

    // ****************************************************
    // AMFILE  UPDATE  PROCESS  ( I.U.A/C (1) ) *
    // ****************************************************
    private void _2sam03() {
        parm02.setP2oscd(0);
        parm02.setP2oscd(Utils.evaluateNumber(1, 0, ttfile.getTtocd5()).intValue());
        parm02.setP2cycd(0);
        parm02.setP2cycd(Utils.evaluateNumber(3, 0, ttfile.getTtcur5()).intValue());
        parm02.setP2accd(0);
        parm02.setP2accd(Utils.evaluateNumber(7, 0, ttfile.getTtact5()).intValue());
        parm02.setP2cust(0);
        parm02.setP2cust(Utils.evaluateNumber(7, 0, ttfile.getTtcst5()).intValue());
        parm02.setP2acbr(0);
        parm02.setP2acbr(Utils.evaluateNumber(3, 0, ttfile.getTtacb5()).intValue());
        parm02.setP2drcr(Utils.movel(parm02.getP2drcr(), 1, ttfile.getTtdrc5(), 1));
        parm02.setP2amnt(BigDecimal.ZERO);
        parm02.setP2amnt(Utils.evaluateNumber(15, 2, ttfile.getTtamt5()));
        this.fw102006VO.setParm02(parm02.toString());
        this.fw102006Service.doMain(this.fw102006VO);
        parm02.setData(this.fw102006VO.getParm02());

    }

    // ****************************************************
    // AMFILE  UPDATE  PROCESS  ( I.U.A/C (2) ) *
    // ****************************************************
    private void _2sam04() {
        parm02.setP2oscd(0);
        parm02.setP2oscd(Utils.evaluateNumber(1, 0, ttara1.getTtocd6()).intValue());
        parm02.setP2cycd(0);
        parm02.setP2cycd(Utils.evaluateNumber(3, 0, ttara1.getTtcur6()).intValue());
        parm02.setP2accd(0);
        parm02.setP2accd(Utils.evaluateNumber(7, 0, ttara1.getTtact6()).intValue());
        parm02.setP2cust(0);
        parm02.setP2cust(Utils.evaluateNumber(7, 0, ttara1.getTtcst6()).intValue());
        parm02.setP2acbr(0);
        parm02.setP2acbr(Utils.evaluateNumber(3, 0, ttara1.getTtacb6()).intValue());
        parm02.setP2drcr(Utils.movel(parm02.getP2drcr(), 1, ttara1.getTtdrc6(), 1));
        parm02.setP2amnt(BigDecimal.ZERO);
        parm02.setP2amnt(Utils.evaluateNumber(15, 2, ttara1.getTtamt6()));
        this.fw102006VO.setParm02(parm02.toString());
        this.fw102006Service.doMain(this.fw102006VO);
        parm02.setData(this.fw102006VO.getParm02());

    }

    // ****************************************************
    // DMFILE  WRITE  PROCESS  ( FEE A/C )      *
    // ****************************************************
    private void _2sdm01() {
        dmfile = new Dmfile();    // *ADD MTB-1354
        dmfile.setDmoscd(0);
        dmfile.setDmoscd(Utils.evaluateNumber(1, 0, ttfile.getTtocd3()).intValue());
        dmfile.setDmcycd(0);
        dmfile.setDmcycd(Utils.evaluateNumber(3, 0, ttfile.getTtcur3()).intValue());
        dmfile.setDmaccd(0);
        dmfile.setDmaccd(Utils.evaluateNumber(7, 0, ttfile.getTtact3()).intValue());
        dmfile.setDmcust(0);
        dmfile.setDmcust(Utils.evaluateNumber(7, 0, ttfile.getTtcst3()).intValue());
        dmfile.setDmrefn(0L);
        dmfile.setDmrefn(Utils.evaluateNumber(11, 0, ttfile.getTtrefn()).longValue());
        dmfile.setDmcpu0(0);
        dmfile.setDmcpu0(0);
        dmfile.setDmcpu1(0);
//ndz-del-s
//         dmfile.setDmcpu1(Utils.evaluateNumber(7, 0, ttfile.getTtcpu1()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmcpu1(Utils.evaluateNumber(8, 0, ttfile.getTtcpu1()).intValue());
//ndz-add-e
        dmfile.setDmcpu2(0);
        dmfile.setDmcpu2(Utils.evaluateNumber(5, 0, ttfile.getTtcpu2()).intValue());
        dmfile.setDmcpu3(0);
        dmfile.setDmcpu3(Utils.evaluateNumber(1, 0, ttfile.getTtcpu3()).intValue());
        dmfileKey = new Dmfile();
        dmfileKey.setDmoscd(dmfile.getDmoscd());
        dmfileKey.setDmcycd(dmfile.getDmcycd());
        dmfileKey.setDmaccd(dmfile.getDmaccd());
        dmfileKey.setDmcust(dmfile.getDmcust());
        dmfileKey.setDmrefn(dmfile.getDmrefn());
        dmfileKey.setDmcpu0(dmfile.getDmcpu0());
        dmfileKey.setDmcpu1(dmfile.getDmcpu1());
        dmfileKey.setDmcpu2(dmfile.getDmcpu2());
        dmfileKey.setDmcpu3(dmfile.getDmcpu3());
        dmfileTemp = dmfileDAO.selectFirstMatching(dmfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlDmfile.offsetClear();
        if (dmfileTemp != null) {
            indicator.setIn80(false);
            dmfile = dmfileTemp;
        } else {
            indicator.setIn80(true);
        }
        _119in = indicator.getIn80() ? "1" : "0";
        dmfile.setDmbrno(0);
        dmfile.setDmbrno(Utils.evaluateNumber(3, 0, ttfile.getTtbrno()).intValue());
        dmfile.setDmrcid(" ");
        dmfile.setDmwsid(Utils.movel(dmfile.getDmwsid(), 3, ttfile.getTtwsid(), 3));
        dmfile.setDmusid(Utils.movel(dmfile.getDmusid(), 2, ttfile.getTtusid(), 2));
        dmfile.setDmbsdt(0);
//ndz-del-s
//         dmfile.setDmbsdt(Utils.evaluateNumber(7, 0, ttfile.getTtindt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmbsdt(Utils.evaluateNumber(8, 0, ttfile.getTtindt()).intValue());
//ndz-add-e
        dmfile.setDmckdt(0);
//ndz-del-s
//         dmfile.setDmckdt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmckdt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        dmfile.setDmdldt(0);
        dmfile.setDmdldt(0);
        dmfile.setDmapno(Utils.movel(dmfile.getDmapno(), 14, ttara1.getTtapno(), 14));
        dmfile.setDmdrcr(Utils.movel(dmfile.getDmdrcr(), 1, ttfile.getTtdrc3(), 1));
        dmfile.setDmtamt(BigDecimal.ZERO);
        dmfile.setDmtamt(Utils.evaluateNumber(15, 2, ttfile.getTtamt3()));
        dmfile.setDmface(BigDecimal.ZERO);
        dmfile.setDmface(Utils.evaluateNumber(15, 2, 0));
        dmfile.setDmcbal(BigDecimal.ZERO);
        dmfile.setDmcbal(Utils.evaluateNumber(15, 2, 0));
        dmfile.setDmostp(0);
        dmfile.setDmostp(Utils.evaluateNumber(3, 0, ttfile.getTtostp()).intValue());
        if (ttfile.getTttrcd().equals(63)) {
            dmfile.setDmtrcd(0);
            dmfile.setDmtrcd(Utils.evaluateNumber(3, 0, 41).intValue());
        } else {
            dmfile.setDmtrcd(0);
            dmfile.setDmtrcd(Utils.evaluateNumber(3, 0, 10).intValue());

        }
        dmfile.setDmmlcd("  ");
        dmfile.setDmcusa(0);
        dmfile.setDmcusa(Utils.evaluateNumber(7, 0, ttara1.getTtcust()).intValue());
        dmfile.setDmrefa(0L);
        dmfile.setDmrefa(Utils.evaluateNumber(11, 0, ttara1.getTtlref()).longValue());
        dmfile.setDmrefb(0L);
        dmfile.setDmrefb(0l);
        dmfile.setDmvldt(0);
//ndz-del-s
//         dmfile.setDmvldt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmvldt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        dmfile.setDmvatc(Utils.movel(dmfile.getDmvatc(), 1, ttara1.getTtvatc(), 1));
        dmfile.setDmfedc(" ");
        dmfile.setDmfxcd(" ");
        dmfile.setDmchkc(" ");
        dmfile.setDmout1(" ");
        dmfile.setDmout2(" ");
        dmfile.setDmout3(" ");
        dmfile.setDmout4(" ");
        dmfile.setDmout5(" ");
        dmfile.setDmout6(" ");
        dmfile.setDmout7(" ");
        dmfile.setDmout8(" ");
        dmfile.setDmout9(" ");
        dmfile.setDmthei(Utils.movel(dmfile.getDmthei(), 15, ttara1.getTtthei(), 15));
        dmfile.setDmstdt(0);
//ndz-del-s
//         dmfile.setDmstdt(Utils.evaluateNumber(7, 0, ttara1.getTtfcfm()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmstdt(Utils.evaluateNumber(8, 0, ttara1.getTtfcfm()).intValue());
//ndz-add-e
        dmfile.setDmendt(0);
//ndz-del-s
//         dmfile.setDmendt(Utils.evaluateNumber(7, 0, ttara1.getTtfcto()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmendt(Utils.evaluateNumber(8, 0, ttara1.getTtfcto()).intValue());
//ndz-add-e
        dmfile.setDmstmt(0);
        dmfile.setDmstmt(0);
        dmfile.setDmterm(Utils.movel(dmfile.getDmterm(), 1, ttara1.getTtterm(), 1));
        dmfile.setDmotgb(0);
        dmfile.setDmotgb(0);
        dmfile.setDmiblc("    ");
        dmfile.setDmremk(Utils.movel(dmfile.getDmremk(), 60, ttara1.getTtrmks(), 60));
        dmfile.setDmreog(0);
        dmfile.setDmreog(0);
        dmfile.setDmsect(Utils.movel(dmfile.getDmsect(), 3, ttfile.getTtsect(), 3));
        dmfile.setDmstat(" ");
        dmfile.setDmfixc(0);
        dmfile.setDmfixc(0);
        dmfile.setDmratc(0);
        dmfile.setDmratc(0);
        dmfile.setDmrate(BigDecimal.ZERO);
        dmfile.setDmrate(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmeplr(BigDecimal.ZERO);
        dmfile.setDmeplr(Utils.evaluateNumber(15, 7, 0));
        dmfile.setDmmgrt(BigDecimal.ZERO);
        dmfile.setDmmgrt(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmscst(BigDecimal.ZERO);
        dmfile.setDmscst(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmotrc(0);
        dmfile.setDmotrc(0);
        if (ttfile.getTttrcd().equals(63)) {
            dmfile.setDmpcp1(0);
//ndz-del-s
//             dmfile.setDmpcp1(Utils.evaluateNumber(7, 0, ds002.getWkpcp1()).intValue());
//ndz-del-e
//ndz-add-s
            dmfile.setDmpcp1(Utils.evaluateNumber(8, 0, ds002.getWkpcp1()).intValue());
//ndz-add-e
            dmfile.setDmpcp2(0);
            dmfile.setDmpcp2(Utils.evaluateNumber(5, 0, ds002.getWkpcp2()).intValue());
            dmfile.setDmpcp3(0);
            dmfile.setDmpcp3(Utils.evaluateNumber(1, 0, ds002.getWkpcp3()).intValue());

        }
        dmfile.setDmrsrv("                    ");
        _119();

    }

    // ****************************************************
    // DMFILE  WRITE  PROCESS  ( NOSTRO A/C )   *
    // ****************************************************
    private void _2sdm02() {
        dmfile = new Dmfile();    // *ADD MTB-1354
        dmfile.setDmoscd(0);
        dmfile.setDmoscd(Utils.evaluateNumber(1, 0, ttfile.getTtocd4()).intValue());
        dmfile.setDmcycd(0);
        dmfile.setDmcycd(Utils.evaluateNumber(3, 0, ttfile.getTtcur4()).intValue());
        dmfile.setDmaccd(0);
        dmfile.setDmaccd(Utils.evaluateNumber(7, 0, ttfile.getTtact4()).intValue());
        dmfile.setDmcust(0);
        dmfile.setDmcust(Utils.evaluateNumber(7, 0, ttfile.getTtcst4()).intValue());
        dmfile.setDmrefn(0L);
        dmfile.setDmrefn(0l);
        dmfile.setDmcpu0(0);
        dmfile.setDmcpu0(Utils.evaluateNumber(3, 0, ttfile.getTtacb4()).intValue());
        dmfile.setDmcpu1(0);
//ndz-del-s
//         dmfile.setDmcpu1(Utils.evaluateNumber(7, 0, ttfile.getTtcpu1()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmcpu1(Utils.evaluateNumber(8, 0, ttfile.getTtcpu1()).intValue());
//ndz-add-e
        dmfile.setDmcpu2(0);
        dmfile.setDmcpu2(Utils.evaluateNumber(5, 0, ttfile.getTtcpu2()).intValue());
        dmfile.setDmcpu3(0);
        dmfile.setDmcpu3(Utils.evaluateNumber(1, 0, ttfile.getTtcpu3()).intValue());
        dmfileKey = new Dmfile();
        dmfileKey.setDmoscd(dmfile.getDmoscd());
        dmfileKey.setDmcycd(dmfile.getDmcycd());
        dmfileKey.setDmaccd(dmfile.getDmaccd());
        dmfileKey.setDmcust(dmfile.getDmcust());
        dmfileKey.setDmrefn(dmfile.getDmrefn());
        dmfileKey.setDmcpu0(dmfile.getDmcpu0());
        dmfileKey.setDmcpu1(dmfile.getDmcpu1());
        dmfileKey.setDmcpu2(dmfile.getDmcpu2());
        dmfileKey.setDmcpu3(dmfile.getDmcpu3());
        dmfileTemp = dmfileDAO.selectFirstMatching(dmfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlDmfile.offsetClear();
        if (dmfileTemp != null) {
            indicator.setIn80(false);
            dmfile = dmfileTemp;
        } else {
            indicator.setIn80(true);
        }
        _119in = indicator.getIn80() ? "1" : "0";
        dmfile.setDmbrno(0);
        dmfile.setDmbrno(Utils.evaluateNumber(3, 0, ttfile.getTtbrno()).intValue());
        dmfile.setDmrcid(" ");
        dmfile.setDmwsid(Utils.movel(dmfile.getDmwsid(), 3, ttfile.getTtwsid(), 3));
        dmfile.setDmusid(Utils.movel(dmfile.getDmusid(), 2, ttfile.getTtusid(), 2));
        dmfile.setDmbsdt(0);
//ndz-del-s
//         dmfile.setDmbsdt(Utils.evaluateNumber(7, 0, ttfile.getTtindt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmbsdt(Utils.evaluateNumber(8, 0, ttfile.getTtindt()).intValue());
//ndz-add-e
        dmfile.setDmckdt(0);
//ndz-del-s
//         dmfile.setDmckdt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmckdt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        dmfile.setDmdldt(0);
        dmfile.setDmdldt(0);
        dmfile.setDmapno(Utils.movel(dmfile.getDmapno(), 14, ttara1.getTtapno(), 14));
        dmfile.setDmdrcr(Utils.movel(dmfile.getDmdrcr(), 1, ttfile.getTtdrc4(), 1));
        dmfile.setDmtamt(BigDecimal.ZERO);
        dmfile.setDmtamt(Utils.evaluateNumber(15, 2, ttfile.getTtamt4()));
        dmfile.setDmface(BigDecimal.ZERO);
        dmfile.setDmface(Utils.evaluateNumber(15, 2, 0));
        dmfile.setDmcbal(BigDecimal.ZERO);
        dmfile.setDmcbal(Utils.evaluateNumber(15, 2, 0));
        dmfile.setDmostp(0);
        dmfile.setDmostp(Utils.evaluateNumber(3, 0, ttfile.getTtostp()).intValue());
        if (ttfile.getTttrcd().equals(63)) {
            dmfile.setDmtrcd(0);
            dmfile.setDmtrcd(Utils.evaluateNumber(3, 0, 41).intValue());
        } else {
            dmfile.setDmtrcd(0);
            dmfile.setDmtrcd(Utils.evaluateNumber(3, 0, 10).intValue());

        }
        dmfile.setDmmlcd("  ");
        dmfile.setDmcusa(0);
        dmfile.setDmcusa(Utils.evaluateNumber(7, 0, ttara1.getTtcust()).intValue());
        dmfile.setDmrefa(0L);
        dmfile.setDmrefa(Utils.evaluateNumber(11, 0, ttfile.getTtrefn()).longValue());
        dmfile.setDmrefb(0L);
        dmfile.setDmrefb(Utils.evaluateNumber(11, 0, ttfile.getTtrefb()).longValue());
        dmfile.setDmvldt(0);
//ndz-del-s
//         dmfile.setDmvldt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmvldt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        dmfile.setDmvatc(Utils.movel(dmfile.getDmvatc(), 1, ttara1.getTtvatc(), 1));
        dmfile.setDmfedc(" ");
        dmfile.setDmfxcd(" ");
        dmfile.setDmchkc(" ");
        dmfile.setDmout1(" ");
        dmfile.setDmout2(" ");
        dmfile.setDmout3(" ");
        dmfile.setDmout4(" ");
        dmfile.setDmout5(" ");
        dmfile.setDmout6(" ");
        dmfile.setDmout7(" ");
        dmfile.setDmout8(" ");
        dmfile.setDmout9(" ");
        dmfile.setDmthei(Utils.movel(dmfile.getDmthei(), 15, ttara1.getTtthei(), 15));
        dmfile.setDmstdt(0);
        dmfile.setDmstdt(0);
        dmfile.setDmendt(0);
        dmfile.setDmendt(0);
        dmfile.setDmstmt(0);
        dmfile.setDmstmt(0);
        dmfile.setDmterm(Utils.movel(dmfile.getDmterm(), 1, ttara1.getTtterm(), 1));
        dmfile.setDmotgb(0);
        dmfile.setDmotgb(0);
        dmfile.setDmiblc("    ");
        dmfile.setDmremk(Utils.movel(dmfile.getDmremk(), 60, ttara1.getTtrmks(), 60));
        dmfile.setDmreog(0);
        dmfile.setDmreog(0);
        dmfile.setDmsect(Utils.movel(dmfile.getDmsect(), 3, ttfile.getTtsect(), 3));
        dmfile.setDmstat(" ");
        dmfile.setDmfixc(0);
        dmfile.setDmfixc(0);
        dmfile.setDmratc(0);
        dmfile.setDmratc(0);
        dmfile.setDmrate(BigDecimal.ZERO);
        dmfile.setDmrate(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmeplr(BigDecimal.ZERO);
        dmfile.setDmeplr(Utils.evaluateNumber(15, 7, 0));
        dmfile.setDmmgrt(BigDecimal.ZERO);
        dmfile.setDmmgrt(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmscst(BigDecimal.ZERO);
        dmfile.setDmscst(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmotrc(0);
        dmfile.setDmotrc(0);
        if (ttfile.getTttrcd().equals(63)) {
            dmfile.setDmpcp1(0);
//ndz-del-s
//             dmfile.setDmpcp1(Utils.evaluateNumber(7, 0, ds002.getWkpcp1()).intValue());
//ndz-del-e
//ndz-add-s
            dmfile.setDmpcp1(Utils.evaluateNumber(8, 0, ds002.getWkpcp1()).intValue());
//ndz-add-e
            dmfile.setDmpcp2(0);
            dmfile.setDmpcp2(Utils.evaluateNumber(5, 0, ds002.getWkpcp2()).intValue());
            dmfile.setDmpcp3(0);
            dmfile.setDmpcp3(Utils.evaluateNumber(1, 0, ds002.getWkpcp3()).intValue());

        }
        dmfile.setDmrsrv("                    ");
        _119();

    }

    // ****************************************************
    // DMFILE  WRITE  PROCESS  ( I.U.A/C (1) )  *
    // ****************************************************
    private void _2sdm03() {
        dmfile = new Dmfile();    // *ADD MTB-1354
        dmfile.setDmoscd(0);
        dmfile.setDmoscd(Utils.evaluateNumber(1, 0, ttfile.getTtocd5()).intValue());
        dmfile.setDmcycd(0);
        dmfile.setDmcycd(Utils.evaluateNumber(3, 0, ttfile.getTtcur5()).intValue());
        dmfile.setDmaccd(0);
        dmfile.setDmaccd(Utils.evaluateNumber(7, 0, ttfile.getTtact5()).intValue());
        dmfile.setDmcust(0);
        dmfile.setDmcust(Utils.evaluateNumber(7, 0, ttfile.getTtcst5()).intValue());
        dmfile.setDmrefn(0L);
        dmfile.setDmrefn(0l);
        dmfile.setDmcpu0(0);
        dmfile.setDmcpu0(0);
        dmfile.setDmcpu1(0);
//ndz-del-s
//         dmfile.setDmcpu1(Utils.evaluateNumber(7, 0, ttfile.getTtcpu1()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmcpu1(Utils.evaluateNumber(8, 0, ttfile.getTtcpu1()).intValue());
//ndz-add-e
        dmfile.setDmcpu2(0);
        dmfile.setDmcpu2(Utils.evaluateNumber(5, 0, ttfile.getTtcpu2()).intValue());
        dmfile.setDmcpu3(0);
        dmfile.setDmcpu3(Utils.evaluateNumber(1, 0, ttfile.getTtcpu3()).intValue());
        dmfileKey = new Dmfile();
        dmfileKey.setDmoscd(dmfile.getDmoscd());
        dmfileKey.setDmcycd(dmfile.getDmcycd());
        dmfileKey.setDmaccd(dmfile.getDmaccd());
        dmfileKey.setDmcust(dmfile.getDmcust());
        dmfileKey.setDmrefn(dmfile.getDmrefn());
        dmfileKey.setDmcpu0(dmfile.getDmcpu0());
        dmfileKey.setDmcpu1(dmfile.getDmcpu1());
        dmfileKey.setDmcpu2(dmfile.getDmcpu2());
        dmfileKey.setDmcpu3(dmfile.getDmcpu3());
        dmfileTemp = dmfileDAO.selectFirstMatching(dmfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlDmfile.offsetClear();
        if (dmfileTemp != null) {
            indicator.setIn80(false);
            dmfile = dmfileTemp;
        } else {
            indicator.setIn80(true);
        }
        _119in = indicator.getIn80() ? "1" : "0";
        dmfile.setDmbrno(0);
        dmfile.setDmbrno(Utils.evaluateNumber(3, 0, ttfile.getTtbrno()).intValue());
        dmfile.setDmrcid(" ");
        dmfile.setDmwsid(Utils.movel(dmfile.getDmwsid(), 3, ttfile.getTtwsid(), 3));
        dmfile.setDmusid(Utils.movel(dmfile.getDmusid(), 2, ttfile.getTtusid(), 2));
        dmfile.setDmbsdt(0);
//ndz-del-s
//         dmfile.setDmbsdt(Utils.evaluateNumber(7, 0, ttfile.getTtindt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmbsdt(Utils.evaluateNumber(8, 0, ttfile.getTtindt()).intValue());
//ndz-add-e
        dmfile.setDmckdt(0);
//ndz-del-s
//         dmfile.setDmckdt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmckdt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        dmfile.setDmdldt(0);
        dmfile.setDmdldt(0);
        dmfile.setDmapno(Utils.movel(dmfile.getDmapno(), 14, ttara1.getTtapno(), 14));
        dmfile.setDmdrcr(Utils.movel(dmfile.getDmdrcr(), 1, ttfile.getTtdrc5(), 1));
        dmfile.setDmtamt(BigDecimal.ZERO);
        dmfile.setDmtamt(Utils.evaluateNumber(15, 2, ttfile.getTtamt5()));
        dmfile.setDmface(BigDecimal.ZERO);
        dmfile.setDmface(Utils.evaluateNumber(15, 2, 0));
        dmfile.setDmcbal(BigDecimal.ZERO);
        dmfile.setDmcbal(Utils.evaluateNumber(15, 2, 0));
        dmfile.setDmostp(0);
        dmfile.setDmostp(Utils.evaluateNumber(3, 0, ttfile.getTtostp()).intValue());
        if (ttfile.getTttrcd().equals(63)) {
            dmfile.setDmtrcd(0);
            dmfile.setDmtrcd(Utils.evaluateNumber(3, 0, 41).intValue());
        } else {
            dmfile.setDmtrcd(0);
            dmfile.setDmtrcd(Utils.evaluateNumber(3, 0, 10).intValue());

        }
        dmfile.setDmmlcd("  ");
        dmfile.setDmcusa(0);
        dmfile.setDmcusa(Utils.evaluateNumber(7, 0, ttara1.getTtcust()).intValue());
        dmfile.setDmrefa(0L);
        dmfile.setDmrefa(Utils.evaluateNumber(11, 0, ttfile.getTtrefn()).longValue());
        dmfile.setDmrefb(0L);
        dmfile.setDmrefb(0l);
        dmfile.setDmvldt(0);
//ndz-del-s
//         dmfile.setDmvldt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmvldt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        dmfile.setDmvatc(Utils.movel(dmfile.getDmvatc(), 1, ttara1.getTtvatc(), 1));
        dmfile.setDmfedc(" ");
        dmfile.setDmfxcd(" ");
        dmfile.setDmchkc(" ");
        dmfile.setDmout1(" ");
        dmfile.setDmout2(" ");
        dmfile.setDmout3(" ");
        dmfile.setDmout4(" ");
        dmfile.setDmout5(" ");
        dmfile.setDmout6(" ");
        dmfile.setDmout7(" ");
        dmfile.setDmout8(" ");
        dmfile.setDmout9(" ");
        dmfile.setDmthei(Utils.movel(dmfile.getDmthei(), 15, ttara1.getTtthei(), 15));
        dmfile.setDmstdt(0);
        dmfile.setDmstdt(0);
        dmfile.setDmendt(0);
        dmfile.setDmendt(0);
        dmfile.setDmstmt(0);
        dmfile.setDmstmt(0);
        dmfile.setDmterm(Utils.movel(dmfile.getDmterm(), 1, ttara1.getTtterm(), 1));
        dmfile.setDmotgb(0);
        dmfile.setDmotgb(0);
        dmfile.setDmiblc("    ");
        dmfile.setDmremk(Utils.movel(dmfile.getDmremk(), 60, ttara1.getTtrmks(), 60));
        dmfile.setDmreog(0);
        dmfile.setDmreog(0);
        dmfile.setDmsect(Utils.movel(dmfile.getDmsect(), 3, ttfile.getTtsect(), 3));
        dmfile.setDmstat(" ");
        dmfile.setDmfixc(0);
        dmfile.setDmfixc(0);
        dmfile.setDmratc(0);
        dmfile.setDmratc(0);
        dmfile.setDmrate(BigDecimal.ZERO);
        dmfile.setDmrate(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmeplr(BigDecimal.ZERO);
        dmfile.setDmeplr(Utils.evaluateNumber(15, 7, 0));
        dmfile.setDmmgrt(BigDecimal.ZERO);
        dmfile.setDmmgrt(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmscst(BigDecimal.ZERO);
        dmfile.setDmscst(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmotrc(0);
        dmfile.setDmotrc(0);
        if (ttfile.getTttrcd().equals(63)) {
            dmfile.setDmpcp1(0);
//ndz-del-s
//             dmfile.setDmpcp1(Utils.evaluateNumber(7, 0, ds002.getWkpcp1()).intValue());
//ndz-del-e
//ndz-add-s
            dmfile.setDmpcp1(Utils.evaluateNumber(8, 0, ds002.getWkpcp1()).intValue());
//ndz-add-e
            dmfile.setDmpcp2(0);
            dmfile.setDmpcp2(Utils.evaluateNumber(5, 0, ds002.getWkpcp2()).intValue());
            dmfile.setDmpcp3(0);
            dmfile.setDmpcp3(Utils.evaluateNumber(1, 0, ds002.getWkpcp3()).intValue());

        }
        dmfile.setDmrsrv("                    ");
        _119();

    }

    // ****************************************************
    // DMFILE  WRITE  PROCESS  ( I.U.A/C (2) )  *
    // ****************************************************
    private void _2sdm04() {
        dmfile = new Dmfile();    // *ADD MTB-1354
        dmfile.setDmoscd(0);
        dmfile.setDmoscd(Utils.evaluateNumber(1, 0, ttara1.getTtocd6()).intValue());
        dmfile.setDmcycd(0);
        dmfile.setDmcycd(Utils.evaluateNumber(3, 0, ttara1.getTtcur6()).intValue());
        dmfile.setDmaccd(0);
        dmfile.setDmaccd(Utils.evaluateNumber(7, 0, ttara1.getTtact6()).intValue());
        dmfile.setDmcust(0);
        dmfile.setDmcust(Utils.evaluateNumber(7, 0, ttara1.getTtcst6()).intValue());
        dmfile.setDmrefn(0L);
        dmfile.setDmrefn(0l);
        dmfile.setDmcpu0(0);
        dmfile.setDmcpu0(0);
        dmfile.setDmcpu1(0);
//ndz-del-s
//         dmfile.setDmcpu1(Utils.evaluateNumber(7, 0, ttfile.getTtcpu1()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmcpu1(Utils.evaluateNumber(8, 0, ttfile.getTtcpu1()).intValue());
//ndz-add-e
        dmfile.setDmcpu2(0);
        dmfile.setDmcpu2(Utils.evaluateNumber(5, 0, ttfile.getTtcpu2()).intValue());
        dmfile.setDmcpu3(0);
        dmfile.setDmcpu3(Utils.evaluateNumber(1, 0, ttfile.getTtcpu3()).intValue());
        dmfileKey = new Dmfile();
        dmfileKey.setDmoscd(dmfile.getDmoscd());
        dmfileKey.setDmcycd(dmfile.getDmcycd());
        dmfileKey.setDmaccd(dmfile.getDmaccd());
        dmfileKey.setDmcust(dmfile.getDmcust());
        dmfileKey.setDmrefn(dmfile.getDmrefn());
        dmfileKey.setDmcpu0(dmfile.getDmcpu0());
        dmfileKey.setDmcpu1(dmfile.getDmcpu1());
        dmfileKey.setDmcpu2(dmfile.getDmcpu2());
        dmfileKey.setDmcpu3(dmfile.getDmcpu3());
        dmfileTemp = dmfileDAO.selectFirstMatching(dmfileKey, SelectSqlPattern.EQ, this.getClass().getSimpleName());
        offsetCtlDmfile.offsetClear();
        if (dmfileTemp != null) {
            indicator.setIn80(false);
            dmfile = dmfileTemp;
        } else {
            indicator.setIn80(true);
        }
        _119in = indicator.getIn80() ? "1" : "0";
        dmfile.setDmbrno(0);
        dmfile.setDmbrno(Utils.evaluateNumber(3, 0, ttfile.getTtbrno()).intValue());
        dmfile.setDmrcid(" ");
        dmfile.setDmwsid(Utils.movel(dmfile.getDmwsid(), 3, ttfile.getTtwsid(), 3));
        dmfile.setDmusid(Utils.movel(dmfile.getDmusid(), 2, ttfile.getTtusid(), 2));
        dmfile.setDmbsdt(0);
//ndz-del-s
//         dmfile.setDmbsdt(Utils.evaluateNumber(7, 0, ttfile.getTtindt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmbsdt(Utils.evaluateNumber(8, 0, ttfile.getTtindt()).intValue());
//ndz-add-e
        dmfile.setDmckdt(0);
//ndz-del-s
//         dmfile.setDmckdt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmckdt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        dmfile.setDmdldt(0);
        dmfile.setDmdldt(0);
        dmfile.setDmapno(Utils.movel(dmfile.getDmapno(), 14, ttara1.getTtapno(), 14));
        dmfile.setDmdrcr(Utils.movel(dmfile.getDmdrcr(), 1, ttara1.getTtdrc6(), 1));
        dmfile.setDmtamt(BigDecimal.ZERO);
        dmfile.setDmtamt(Utils.evaluateNumber(15, 2, ttara1.getTtamt6()));
        dmfile.setDmface(BigDecimal.ZERO);
        dmfile.setDmface(Utils.evaluateNumber(15, 2, 0));
        dmfile.setDmcbal(BigDecimal.ZERO);
        dmfile.setDmcbal(Utils.evaluateNumber(15, 2, 0));
        dmfile.setDmostp(0);
        dmfile.setDmostp(Utils.evaluateNumber(3, 0, ttfile.getTtostp()).intValue());
        if (ttfile.getTttrcd().equals(63)) {
            dmfile.setDmtrcd(0);
            dmfile.setDmtrcd(Utils.evaluateNumber(3, 0, 41).intValue());
        } else {
            dmfile.setDmtrcd(0);
            dmfile.setDmtrcd(Utils.evaluateNumber(3, 0, 10).intValue());

        }
        dmfile.setDmmlcd("  ");
        dmfile.setDmcusa(0);
        dmfile.setDmcusa(Utils.evaluateNumber(7, 0, ttara1.getTtcust()).intValue());
        dmfile.setDmrefa(0L);
        dmfile.setDmrefa(Utils.evaluateNumber(11, 0, ttfile.getTtrefn()).longValue());
        dmfile.setDmrefb(0L);
        dmfile.setDmrefb(0l);
        dmfile.setDmvldt(0);
//ndz-del-s
//         dmfile.setDmvldt(Utils.evaluateNumber(7, 0, ttfile.getTtvldt()).intValue());
//ndz-del-e
//ndz-add-s
        dmfile.setDmvldt(Utils.evaluateNumber(8, 0, ttfile.getTtvldt()).intValue());
//ndz-add-e
        dmfile.setDmvatc(Utils.movel(dmfile.getDmvatc(), 1, ttara1.getTtvatc(), 1));
        dmfile.setDmfedc(" ");
        dmfile.setDmfxcd(" ");
        dmfile.setDmchkc(" ");
        dmfile.setDmout1(" ");
        dmfile.setDmout2(" ");
        dmfile.setDmout3(" ");
        dmfile.setDmout4(" ");
        dmfile.setDmout5(" ");
        dmfile.setDmout6(" ");
        dmfile.setDmout7(" ");
        dmfile.setDmout8(" ");
        dmfile.setDmout9(" ");
        dmfile.setDmthei(Utils.movel(dmfile.getDmthei(), 15, ttara1.getTtthei(), 15));
        dmfile.setDmstdt(0);
        dmfile.setDmstdt(0);
        dmfile.setDmendt(0);
        dmfile.setDmendt(0);
        dmfile.setDmstmt(0);
        dmfile.setDmstmt(0);
        dmfile.setDmterm(Utils.movel(dmfile.getDmterm(), 1, ttara1.getTtterm(), 1));
        dmfile.setDmotgb(0);
        dmfile.setDmotgb(0);
        dmfile.setDmiblc("    ");
        dmfile.setDmremk(Utils.movel(dmfile.getDmremk(), 60, ttara1.getTtrmks(), 60));
        dmfile.setDmreog(0);
        dmfile.setDmreog(0);
        dmfile.setDmsect(Utils.movel(dmfile.getDmsect(), 3, ttfile.getTtsect(), 3));
        dmfile.setDmstat(" ");
        dmfile.setDmfixc(0);
        dmfile.setDmfixc(0);
        dmfile.setDmratc(0);
        dmfile.setDmratc(0);
        dmfile.setDmrate(BigDecimal.ZERO);
        dmfile.setDmrate(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmeplr(BigDecimal.ZERO);
        dmfile.setDmeplr(Utils.evaluateNumber(15, 7, 0));
        dmfile.setDmmgrt(BigDecimal.ZERO);
        dmfile.setDmmgrt(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmscst(BigDecimal.ZERO);
        dmfile.setDmscst(Utils.evaluateNumber(11, 6, 0));
        dmfile.setDmotrc(0);
        dmfile.setDmotrc(0);
        if (ttfile.getTttrcd().equals(63)) {
            dmfile.setDmpcp1(0);
//ndz-del-s
//             dmfile.setDmpcp1(Utils.evaluateNumber(7, 0, ds002.getWkpcp1()).intValue());
//ndz-del-e
//ndz-add-s
            dmfile.setDmpcp1(Utils.evaluateNumber(8, 0, ds002.getWkpcp1()).intValue());
//ndz-add-e
            dmfile.setDmpcp2(0);
            dmfile.setDmpcp2(Utils.evaluateNumber(5, 0, ds002.getWkpcp2()).intValue());
            dmfile.setDmpcp3(0);
            dmfile.setDmpcp3(Utils.evaluateNumber(1, 0, ds002.getWkpcp3()).intValue());

        }
        dmfile.setDmrsrv("                    ");
        _119();

    }

    // /COPY CPYSRC,FW102019
    // ****************************************************
    // ****      DMFILE  WRITE  SUB-RTN               *****
    // ****************************************************
    private void _119() {
        if (Utils.rTrim(_119in).equals(Utils.rTrim("1"))) {
            dmfile.setDmusn1(0);
//ndz-del-s
//             dmfile.setDmusn1(Utils.evaluateNumber(7, 0, ttfile.getTtusn1()).intValue());
//ndz-del-e
//ndz-add-s
            dmfile.setDmusn1(Utils.evaluateNumber(8, 0, ttfile.getTtusn1()).intValue());
//ndz-add-e
            dmfile.setDmusn2(0);
            dmfile.setDmusn2(Utils.evaluateNumber(5, 0, ttfile.getTtusn2()).intValue());
            dmfileDAO.insert(dmfile);

        }
        _119in = " ";

    }

}
