# rpg2java-kit（中文说明）

RPG→Java 工具自动转换后，**剩余约 20% 手动补全作业**的通用 AI 引擎。
> 日本語は [README.ja.md](./README.ja.md)。

## 1. 核心思想：规则即数据，引擎不变

- 引擎代码**不认识**任何具体规则（EXFMT/KEYED…）。规则是 `rules/*.yaml` 里的**数据**。
- **能确定性就确定性**（python，零成本、零幻觉）；**必须判断的才用 LLM**，且配**客观校验(guardrails)+限次重试**兜底。
- 复杂规则（删旧逻辑+写新逻辑，如 EXFMT）：AI 出草稿，**强制转人工复核**。

## 2. 五个模式 / 完整流程

```
rules_src/*.md ──extract──> rules/*.yaml ──┐
（设计书原文，LLM抽取，人工过目）            │
                                          ├─ detect   每个 java 命中哪些规则 + 缺哪些规则
半成品 java + 人工版 + RPG ──mine──> skills/*.md（prompt+真实例子）
                                          │
                              skills ──complete──> 补全后 java + 报告
                                          │   · 确定性 → python
                                          │   · 复杂   → LLM + guardrails + 重试
                                          │   · 删+写新逻辑(EXFMT) → del_add，转人工复核
                              AI输出 ──validate──> 对人工版语义分级 + 匹配率
```

| 模式 | 作用 | 需人工版? |
|------|------|:-:|
| `extract`  | `rules_src/` 原文 → `rules/*.yaml`（LLM 抽取，**产物需人工过目**） | 否 |
| `detect`   | 各 java 命中哪些规则 + 列出无规则的标记（待补规则工单） | 否 |
| `mine`     | `diff(半成品→人工版)` → 抽真实例子 → 判定确定性/LLM → 生成 `skills/` | **是** |
| `complete` | 按 skill 补全（确定性 python / LLM+校验+重试 / del_add） | 否 |
| `validate` | `diff(AI输出→人工版)` → 一致/等价/逻辑差分级 → 匹配率 | **是** |

`mine`/`validate` 需要客户人工修改版，只能在客户环境跑；`extract`/`detect`/`complete` 本地即可。

## 3. 安装与用法

```bash
pip install -r requirements.txt          # 本地; 客户环境(gemini)再装 google-genai
python run.py extract                     # ① 原文 → rules/*.yaml (跑完人工过目)
python run.py detect                      # ② 命中情况 + 未対応マーカー
python run.py mine                        # ③ 客户环境: 学出 skills/
python run.py complete                    # ④ 补全 (确定性 + LLM)
python run.py complete --no-llm           #    只跑确定性
python run.py validate                    # ⑤ 客户环境: 对人工版算匹配率
python run.py <mode> --config other.yaml
```

## 4. 目录结构

```
rpg2java-kit/
├── config.yaml          # 唯一按环境改: llm.provider / 三路径 / 编码
├── .env                 # LLM 密钥(已gitignore)。本地 DeepSeek; 客户改 Vertex
├── run.py
├── rules_src/*.md       # 设计书规则原文（extract 输入）
├── rules/*.yaml         # 规则定义（extract 产出 / mine 输入）
├── skills/*.md          # mine 推导的 skill：prompt + 真实例子（complete 输入）
├── input/               # 半成品 java
│   └── 人工/            # 人工修改版（mine/validate 用；不会被当输入）
├── output/<java名>/     # 补全后 java + changelog.json + diff_vs_original.html + diff_vs_human.html
└── output/報告書_*.md   # 日语报告书（検出/補完/検証）
```
RPG 源码路径由 `config.paths.rpg_dir` 指定；java→RPG 文件名映射见 `config.rpg_mapping`。

## 5. 规则的两类与执行方式

mine 用"transform 能否重现人工"自动判类型（非人工猜）：

- **确定性（如 KEYED 注释类）**：执行时走 **python transform**，零 LLM，已验证跨文件泛化 ~94%。
- **复杂（如 EXFMT/5.9）**：走 **LLM + guardrails**。其中 EXFMT 这类"删画面块+写新逻辑"用 **del_add 契约**：LLM 只返回删除范围+新代码，python 拼精确的 `//ndz-del` 块，且**一律标记人工复核**（新业务逻辑不可信 LLM 自报置信）。

guardrails 客观校验（运算符/比较值不被改、括号配对、范围合理），不过则带反馈重试（上限 `complete.llm_retry.max_retries`），仍不过则跳过并标记人工。

## 6. 部署到客户环境（Windows）

1. 整个 `rpg2java-kit/` 拷过去，`pip install -r requirements.txt && pip install google-genai`。
2. 改 `config.yaml`：`llm.provider: gemini`、确认 `gemini.project/location`、设环境变量 `GEMINI_MODEL`；编码不确定留 `auto`，Shift-JIS 改 `cp932`。
3. 设 `.env`（或环境变量）指向客户认可的 LLM 端点。
4. 配 `paths`：half_dir/human_dir/rpg_dir。人工版放 human_dir。
5. 依次 `extract`(过目) → `detect` → `mine` → `complete` → `validate`。

跨平台：pathlib 路径、CRLF/LF 原样保留、编码自动探测。

## 7. 能力边界（诚实）

- **同已有形状的规则**（注释类、简单替换等，占大头）：加规则数据即可用，无需改代码。
- **新修改形状**（如悲観ロック插入参数）或**要写新业务逻辑**（EXFMT 的 ICS 替代）：每个第一次需加一个 handler/校验器（之后同形状复用）；写新逻辑的始终是"AI 起草 + 人把关"。
- 匹配率里的"覆盖率"取决于规则数量；规则越多覆盖越高。
