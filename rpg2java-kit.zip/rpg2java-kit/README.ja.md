# rpg2java-kit（日本語）

RPG→Java 自動変換ツールによる変換後、**残り約 20% の手動補完作業**を行う汎用 AI エンジン。

## 1. 基本思想：ルールはデータ、エンジンは不変

- エンジンは個別ルール（EXFMT/KEYED…）を**ハードコードしない**。ルールは `rules/*.yaml` の**データ**。
- **確定的にできるものは確定的に**（Python・無コスト・ハルシネーション無）。**判断が要る時のみ LLM**、かつ**客観検証(guardrails)+回数制限付き再試行**で担保。
- 複雑ルール（旧ロジック削除＋新ロジック記述、例: EXFMT）：AI は下書き、**必ず人手レビューへ回す**。

## 2. 5 つのモード / 全体フロー

```
rules_src/*.md ──extract──> rules/*.yaml ──┐
（設計書原文・LLM抽出・要人手確認）          │
                                          ├─ detect   各 java のヒットルール + 未整備マーカー
半完成 java + 人手版 + RPG ──mine──> skills/*.md（prompt+実例）
                                          │
                              skills ──complete──> 補完後 java + 報告書
                                          │   ・確定的 → Python
                                          │   ・複雑   → LLM + guardrails + 再試行
                                          │   ・削除+新ロジック(EXFMT) → del_add、人手レビューへ
                              AI出力 ──validate──> 人手版と意味的に分類 + 一致率
```

| モード | 役割 | 人手版が必要? |
|------|------|:-:|
| `extract`  | `rules_src/` 原文 → `rules/*.yaml`（LLM 抽出、**産物は要人手確認**） | 不要 |
| `detect`   | 各 java のヒットルール + ルール未整備マーカー一覧 | 不要 |
| `mine`     | `diff(半完成→人手版)` → 実例抽出 → 確定的/LLM 判定 → `skills/` 生成 | **必要** |
| `complete` | skill に従い補完（確定的 Python / LLM+検証+再試行 / del_add） | 不要 |
| `validate` | `diff(AI出力→人手版)` → 一致/等価/ロジック差 分類 → 一致率 | **必要** |

`mine`/`validate` は人手修正版が必要なため顧客環境のみ。`extract`/`detect`/`complete` はローカル可。

## 3. インストールと使い方

```bash
pip install -r requirements.txt          # ローカル; 顧客環境(gemini)は google-genai も
python run.py extract                     # ① 原文 → rules/*.yaml (後で人手確認)
python run.py detect                      # ② ヒット状況 + 未対応マーカー
python run.py mine                        # ③ 顧客環境: skills/ を学習生成
python run.py complete                    # ④ 補完 (確定的 + LLM)
python run.py complete --no-llm           #    確定的のみ
python run.py validate                    # ⑤ 顧客環境: 人手版との一致率
python run.py <mode> --config other.yaml
```

## 4. ディレクトリ構成

```
rpg2java-kit/
├── config.yaml          # 環境ごとに変える唯一の場所: llm.provider / 3パス / encoding
├── .env                 # LLM 認証情報(gitignore済)。ローカル DeepSeek; 顧客は Vertex
├── run.py
├── rules_src/*.md       # 設計書ルール原文（extract 入力）
├── rules/*.yaml         # ルール定義（extract 産出 / mine 入力）
├── skills/*.md          # mine が導出した skill：prompt + 実例（complete 入力）
├── input/               # 半完成 java
│   └── 人工/            # 人手修正版（mine/validate 用。補完対象にはならない）
├── output/<java名>/     # 補完後 java + changelog.json + diff_vs_original.html + diff_vs_human.html
└── output/報告書_*.md   # 日本語報告書（検出/補完/検証）
```
RPG ソースのパスは `config.paths.rpg_dir`、java→RPG ファイル名対応は `config.rpg_mapping`。

## 5. ルールの2種類と実行方式

mine は「transform で人手版を再現できるか」で種別を自動判定（人の当て推量ではない）：

- **確定的（KEYED 等のコメントアウト系）**：実行時は **Python transform**、LLM 不使用。ファイル横断の汎化 ~94% を実測。
- **複雑（EXFMT/5.9 等）**：**LLM + guardrails**。うち EXFMT のような「画面ブロック削除＋新ロジック記述」は **del_add 契約**：LLM は削除範囲＋新コードのみ返し、Python が正確な `//ndz-del` ブロックを生成。さらに**必ず人手レビューへ**（新業務ロジックは LLM の自己申告信頼度を信用しない）。

guardrails の客観検証（比較演算子/比較値を変えない、括弧整合、範囲妥当）に通らなければフィードバック付きで再試行（上限 `complete.llm_retry.max_retries`）、なお駄目ならスキップして人手へ。

## 6. 顧客環境（Windows）への配置

1. `rpg2java-kit/` 一式をコピー、`pip install -r requirements.txt && pip install google-genai`。
2. `config.yaml`：`llm.provider: gemini`、`gemini.project/location` 確認、環境変数 `GEMINI_MODEL` 設定；encoding は不明なら `auto`、Shift-JIS なら `cp932`。
3. `.env`（または環境変数）を顧客承認の LLM エンドポイントに向ける。
4. `paths` の half_dir/human_dir/rpg_dir を設定。人手版は human_dir へ。
5. `extract`(確認) → `detect` → `mine` → `complete` → `validate` の順。

クロスプラットフォーム：パスは pathlib、CRLF/LF 保持、エンコーディング自動判定。

## 7. 適用範囲（正直に）

- **既存の形と同じルール**（コメントアウト系・単純置換 等、大半）：ルールデータを足すだけで適用、コード変更不要。
- **新しい修正の形**（悲観ロックの引数追加 等）や**新業務ロジックの記述**（EXFMT の ICS 代替）：初回のみ handler/検証器の追加が必要（以後同形は再利用）。新ロジック記述は常に「AI 下書き＋人手確認」。
- 一致率の「カバレッジ」はルール数に依存。ルールを増やすほど向上。
